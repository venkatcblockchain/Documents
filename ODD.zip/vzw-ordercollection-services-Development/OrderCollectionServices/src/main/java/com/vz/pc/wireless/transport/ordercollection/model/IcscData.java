package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.ArrayList;

public class IcscData {

	private String icsc;

	
	private ArrayList<String> acna;
	
	private ArrayList<String> ccna;
	
	private String asogFlag;
	
	private String email;

	public String getIcsc() {
		return icsc;
	}

	public void setIcsc(String icsc) {
		this.icsc = icsc;
	}

	public ArrayList<String> getAcna() {
		return acna;
	}

	public void setAcna(ArrayList<String> acna) {
		this.acna = acna;
	}

	public ArrayList<String> getCcna() {
		return ccna;
	}

	public void setCcna(ArrayList<String> ccna) {
		this.ccna = ccna;
	}

	public String getAsogFlag() {
		return asogFlag;
	}

	public void setAsogFlag(String asogFlag) {
		this.asogFlag = asogFlag;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "IcscData [icsc=" + icsc + ", acna=" + acna.toString() + ", ccna=" + ccna.toString() + ", asogFlag=" + asogFlag + ", email="
				+ email + "]";
	}
	
	
	
}
