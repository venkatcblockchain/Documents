package com.vz.pc.wireless.transport.ordercollection.service.impl;

import static org.springframework.data.mongodb.core.FindAndModifyOptions.options;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.mongodb.BasicDBObject;
import com.mongodb.util.JSON;
import com.vz.pc.wireless.transport.ordercollection.Enumerators.OrderTypeEnum;
import com.vz.pc.wireless.transport.ordercollection.Enumerators.PcCEnum;
import com.vz.pc.wireless.transport.ordercollection.Enumerators.TaskStatus;
import com.vz.pc.wireless.transport.ordercollection.GroovyRules.GroovyRuleEvaluator;
import com.vz.pc.wireless.transport.ordercollection.model.Events;
import com.vz.pc.wireless.transport.ordercollection.model.MultiEC;
import com.vz.pc.wireless.transport.ordercollection.model.Order;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.PcOrderRequest;
import com.vz.pc.wireless.transport.ordercollection.model.Segment;
import com.vz.pc.wireless.transport.ordercollection.model.Site;
import com.vz.pc.wireless.transport.ordercollection.model.VzWirelessPVCDetails;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.AcnaCcnaData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.Counters;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.EventAudit;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.InEventStore;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.TaskInst;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.VendorData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.AcnaCcnaDataRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.EventAuditRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.InEventStoreRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.PcWirelessOrderRepository;
import com.vz.pc.wireless.transport.ordercollection.service.IOrderCollectionService;

@RefreshScope
@Component("iOrderCollectionService")
@Transactional
public class OrderCollectionServiceImpl implements IOrderCollectionService {

	private static Logger logger = LoggerFactory.getLogger(OrderCollectionServiceImpl.class);

	@Autowired
	PcWirelessOrderRepository pcOrderRepo;

	@Autowired
	private MongoOperations mongo;

	@Autowired
	GroovyRuleEvaluator RuleEvaluator;
	
	@Autowired
	InEventStoreRepository inEventStoreRepository;
	
	@Autowired
	AcnaCcnaDataRepository acnaCcnaDataRepository;
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	EventAuditRepository eventAuditRepository;
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Value("${url.loadtask}")
	private String  loadtask;		

	
	@Value("${url.updatetask}")
	private String  updatetask;		

	@Override
	@Async
	public Future<PcWirelessOrder> createPCOrder(PcOrderRequest pcOrderReq) {

		logger.debug("Create Order [" + pcOrderReq.toString() + "]");
		
		PcWirelessOrder pcWirelessOrder = new PcWirelessOrder();

		long orderid = getNextSequence("pcWirelessOrder");
		pcWirelessOrder.setId(orderid);

		Order order = new Order();
		order.setOrderNumber(orderid + "");
		order.setOrderSource(PcCEnum.OrderSource.VZW);
		order.setOrderStatus("A");
		order.setCreatedTime(new Timestamp(new Date().getTime()));
		order.setLastUpdatedTime(new Timestamp(new Date().getTime()));
		order.setWorkId(-11);
		order.setOrderVersion(" ");
		pcWirelessOrder.setOrder(order);

		OrderDetails orderDetails = new OrderDetails();
		logger.info("PcCEnum.OrderType.name(PcCEnum.OrderType.valueByName(pcOrderReq.getAction())) "+OrderTypeEnum.find(pcOrderReq.getAction()));
		orderDetails.setOrderType(OrderTypeEnum.find(pcOrderReq.getAction()).name());
		orderDetails.setAcna(pcOrderReq.getAcna());
		orderDetails.setActl(pcOrderReq.getActl());
		orderDetails.setAsog(pcOrderReq.getAsogFlag());
		orderDetails.setCcna(pcOrderReq.getCcna());

		orderDetails.setCno(pcOrderReq.getCno());

		orderDetails.setCustomerDesiredDueDate(stringToDate(pcOrderReq.getDueDate(), "MM/dd/yyyy"));

		if (!isBlank(pcOrderReq.getCopyFromPON())) {
			orderDetails.setCopyPon(pcOrderReq.getCopyFromPON());
		}
		if (!isBlank(pcOrderReq.getDisconnectCopyFromPON())) {
			orderDetails.setDisconnectCopyPon(pcOrderReq.getDisconnectCopyFromPON());
		}

		orderDetails.setDuplicateSegments(pcOrderReq.getDuplicateSegmentFlag());
		orderDetails.setEvcSP(pcOrderReq.getEVCSP());
		orderDetails.setExpedite(pcOrderReq.getExpenditeOrder());
		orderDetails.setHotcut(pcOrderReq.getHotCut());
		orderDetails.setMultiEC(pcOrderReq.getMultiEcFlag());
		orderDetails.setPon(pcOrderReq.getPonNumber());
		orderDetails.setProductCategory(pcOrderReq.getServiceType());
		orderDetails.setActlCoLocation(pcOrderReq.getActlCoLocation());
		orderDetails.setServiceType(pcOrderReq.getServiceType());
		RuleEvaluator.evaluateRules("changeReasonCode", pcOrderReq, orderDetails);

		RuleEvaluator.evaluateRules("productSubCategory", pcOrderReq, orderDetails);

		orderDetails.setProjectId(pcOrderReq.getProjectId());
		orderDetails.setRegion(pcOrderReq.getRegion());
		orderDetails.setRelatedPon(pcOrderReq.getRelatedPon());
		orderDetails.setTspCode(pcOrderReq.getTspCode());
		orderDetails.setSpec(pcOrderReq.getSpec());
		orderDetails.setUserId(pcOrderReq.getUserId());
		orderDetails.setFirstName(pcOrderReq.getFirstName());
		orderDetails.setLastName(pcOrderReq.getLastName());
		orderDetails.setUserEmail(pcOrderReq.getUserEmail());
		
		MultiEC multiEC[] = pcOrderReq.getMultiEC();
		VzWirelessPVCDetails[] pvcDetails = pcOrderReq.getPvcDetails();
		List<Segment> segmentList = new ArrayList<Segment>();
		List<Site> sitesList = new ArrayList<Site>();

		List<MultiEC> multiECList = Arrays.asList(Optional.ofNullable(multiEC).orElse(new MultiEC[0]));
		logger.info("multiECList ["+multiECList+"");
		List<VzWirelessPVCDetails> pvcList = Optional.ofNullable(pvcDetails).isPresent() ==true  ?Arrays.asList(Optional.ofNullable(pvcDetails).orElse(null)) :new ArrayList<>() ;

		multiECList.forEach(multiECObj -> {
			Segment e = new Segment();
			if (multiECObj.getSegmentId() != null) {
				e.setSegmentId(multiECObj.getSegmentId());
			}
			e.setSegmentName(multiECObj.getSegmentName());
			e.setBandwidth(pcOrderReq.getBandWidth());
			AcnaCcnaData acnaCcnaData = acnaCcnaDataRepository.findByBandwidthName(pcOrderReq.getBandWidth());
			if(acnaCcnaData != null && acnaCcnaData.getBandwidth() != null && acnaCcnaData.getBandwidth().size()>0){
				e.setBandwidthSpeed(String.valueOf(acnaCcnaData.getBandwidth().get(0).getValue()));
			}
			
			e.setBan(multiECObj.getBAN());
			e.setCfa(multiECObj.getCfa());
			e.setMrc(multiECObj.getMrc());
			e.setNewcfa(multiECObj.getNewCFA());
			e.setOriginalSegmentName(multiECObj.getSegmentName());
			e.setIcsc(multiECObj.getIcsc());
			e.setCircuitNumber(multiECObj.getCircuitNumber());
			e.setVendorCode(multiECObj.getVendorCode());
			e.setSegmentType(multiECObj.getType());
			e.setControlICSC(multiECObj.getControlICSC());
			e.setBtpSegmentId("");
			e.setVendorEmail(multiECObj.getVendorEmail());
			
			List<Site> siteList = Arrays.asList(multiECObj.getSite());
			siteList.forEach(site -> {
				//RuleEvaluator.evaluateRules("multiLECSegment", site, e);
				if("A".equals(site.getEndPointType())){
					e.setaSiteId(site.getSiteId());
				}
				if("Z".equals(site.getEndPointType())){
					e.setzSiteId(site.getSiteId());
				}
				//e.setzSiteId(site.getSiteId());
				Site siteVO = new Site();
				siteVO.setSiteId(site.getSiteId());
				siteVO.setSiteName(site.getSiteName());
				siteVO.setClli(site.getClli());
				siteVO.setCity(site.getCity());
				siteVO.setContactName(site.getContactName());
				siteVO.setElevation(site.getElevation());
				siteVO.setFloor(site.getFloor());
				siteVO.setPhone(site.getPhone());
				siteVO.setRoom(site.getRoom());
				siteVO.setState(site.getState());
				siteVO.setStreet(site.getStreet());
				siteVO.setZip(site.getZip());
				siteVO.setStructure(site.getStructure());
				siteVO.setUnit(site.getUnit());
				siteVO.setType(site.getType());
				sitesList.add(siteVO);
				segmentList.add(e);
			});

		});

		pvcList.forEach(pvcObj -> {
			Segment e = new Segment();
			long pvcId = 1;
			if (!isBlank(pvcObj.getEvcSequenceId())) {
				e.setSegmentId(pvcObj.getEvcSequenceId());
			} else {
				e.setSegmentId(String.valueOf(pvcId));
			}
			e.setSegmentName(pvcObj.getEvcId());
			e.setSegmentType("EVC");
			e.setBandwidth(pvcObj.getEvcbandwidth());
			AcnaCcnaData acnaCcnaData = acnaCcnaDataRepository.findByBandwidthName(pvcObj.getEvcbandwidth());
			if(acnaCcnaData != null && acnaCcnaData.getBandwidth() != null && acnaCcnaData.getBandwidth().size()>0){
				e.setBandwidthSpeed(acnaCcnaData.getBandwidth().get(0).getValue());
			}
			e.setCeVlan(pvcObj.getCeVlan());
			e.setRuid(pvcObj.getRuid());
			segmentList.add(e);

			pvcId++;
		});

		if (segmentList != null && segmentList.size() > 0) {
			orderDetails.setSegments(segmentList.toArray(new Segment[segmentList.size()]));
		}

		if (sitesList != null && sitesList.size() > 0) {
			orderDetails.setSites(sitesList.toArray(new Site[sitesList.size()]));
		}

		pcWirelessOrder.setOrderDetails(orderDetails);
		pcWirelessOrder.setAsrCreated(false);
		
		logger.info("Persit Order Collection Request [" + pcWirelessOrder.toString() + "]");
		pcOrderRepo.save(pcWirelessOrder);

		
		/** Persist In Event **/
		
		InEventStore eventStore = new InEventStore();
		eventStore.setPcOrderId(pcWirelessOrder.getId());
		eventStore.setActionType("PC_ORD_COLLECTION_RES");
		eventStore.setCreateTime(new DateTime());
		eventStore.setEventName("PC_Internal_OrderCollection_Request");
		eventStore.setSequence(0);
		eventStore.setDestSystem("VZW");
		eventStore.setSourceSystem("VZW");

		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		String jsonOnbj = "";
		try {
			jsonOnbj = ow.writeValueAsString(pcWirelessOrder);
			logger.info("input " + jsonOnbj.length());

			BasicDBObject dbObject = (BasicDBObject) JSON.parse(jsonOnbj);

			eventStore.setDbObject(dbObject);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		long id = getNextSequence("ineventstore");
		eventStore.setId(id);
		InEventStore inEventStore = inEventStoreRepository.save(eventStore);
		logger.info("Persisted in  InEventStore Collection ["+inEventStore.toString()+"]");
		
		TaskInst taskInstData = new TaskInst(new Long(0), "Internal-Order-Collection", order.getOrderNumber(), orderDetails.getPon(),
				"01", orderDetails.getSegments()[0].getIcsc(), new Date(), null, null, null,
				pcWirelessOrder.getOrderDetails().getUserId(), TaskStatus.NEW.toString(), "0000", "To Be Loaded", null, null,"GENERIC" , null);
		
		 if("Move".equals(pcWirelessOrder.getOrderDetails().getOrderType())){
				taskInstData.setMoveOrd("N");			 
		 }else{
			 taskInstData.setMoveOrd(null);		
		 }
		logger.info("Load All tasks for orderNumber ["+order.getOrderNumber()+"] ");
		restTemplate.postForObject(loadtask, taskInstData, String.class);
		
		logger.info("Invokes Update Task for OrderNumber ["+order.getOrderNumber() + " ] with url [" + updatetask + "]");
		
		auditEvents(order.getOrderNumber(), pcWirelessOrder.getOrderDetails().getUserId(),  orderDetails.getPon(), "01", "Internal-Order-Collection", "[SUCCESS ] VzW Transport order Created Succcessfully");
		
		taskInstData = new TaskInst(new Long(0), "Internal-Order-Collection", order.getOrderNumber(), orderDetails.getPon(),
				"01", orderDetails.getSegments()[0].getIcsc(), null, null, new Date(), inEventStore.getCreateTime().toDate(),
				pcWirelessOrder.getOrderDetails().getUserId(), TaskStatus.COMPLETE.toString(), "0000", "Internal-Order-Collection Task Completed Successfully ", null, null,"GENERIC" , null);
		if("Move".equals(pcWirelessOrder.getOrderDetails().getOrderType())){
			taskInstData.setMoveOrd("N");			 
		}else{
			 taskInstData.setMoveOrd(null);		
		}
		TaskInst taskInst  = restTemplate.postForObject(updatetask, taskInstData, TaskInst.class);
		eventStore.setTaskId(taskInst.getTaskid());
		 inEventStore = inEventStoreRepository.save(eventStore);
		 
		 
		 if("Move".equals(pcWirelessOrder.getOrderDetails().getOrderType())){
				TaskInst taskInstData1 = new TaskInst(new Long(0), "Internal-Order-Collection", order.getOrderNumber(), orderDetails.getRelatedPon(),
						"01", orderDetails.getSegments()[0].getIcsc(), new Date(), null, null, null,
						pcWirelessOrder.getOrderDetails().getUserId(), TaskStatus.NEW.toString(), "0000", "To Be Loaded", null, null,"GENERIC" , null);
				
				taskInstData1.setMoveOrd("D");
				logger.info("Load All tasks for orderNumber ["+order.getOrderNumber()+"] ");
				restTemplate.postForObject(loadtask, taskInstData1, String.class);
				
				logger.info("Invokes Update Task for OrderNumber ["+order.getOrderNumber() + " ] with url [" + updatetask + "]");
				
				auditEvents(order.getOrderNumber(), pcWirelessOrder.getOrderDetails().getUserId(),  orderDetails.getRelatedPon(), "01", "Internal-Order-Collection", "[SUCCESS ] VzW Transport order Created Succcessfully");
				
				taskInstData1 = new TaskInst(new Long(0), "Internal-Order-Collection", order.getOrderNumber(), orderDetails.getRelatedPon(),
						"01", orderDetails.getSegments()[0].getIcsc(), null, null, new Date(), inEventStore.getCreateTime().toDate(),
						pcWirelessOrder.getOrderDetails().getUserId(), TaskStatus.COMPLETE.toString(), "0000", "Internal-Order-Collection Task Completed Successfully ", null, null,"GENERIC" , null);
				
				taskInstData1.setMoveOrd("D");
				TaskInst taskInst1  = restTemplate.postForObject(updatetask, taskInstData1, TaskInst.class);
				eventStore.setTaskId(taskInst1.getTaskid());
				 inEventStore = inEventStoreRepository.save(eventStore);
		 }
		 
		return new AsyncResult<PcWirelessOrder>(pcWirelessOrder);
	}

	public static Date stringToDate(String date, String format) {
		Date d = null;

		try {
			d = new SimpleDateFormat(format).parse(date);
		} catch (ParseException e) {
			logger.error("",e);
		}
		return d;
	}

	public static boolean isBlank(String s) {
		return (s == null || s.trim().length() == 0);
	}

	public int getNextSequence(String collectionName) {
		Counters counter = (Counters) mongo.findAndModify(query(where("id").is(collectionName)), new Update().inc("seq", 1), options().returnNew(true),
				Counters.class);
		return counter.getSeq();
	}

	
	@Override
	public String updateOrderDetails(String orderNumber,String userId ,  String   firstName ,   String   lastName,   String   userEmail) {
		PcWirelessOrder pcOrder = pcOrderRepo.findByOrderOrderNumber(orderNumber);
		pcOrder.getOrderDetails().setUserId(userId);
		pcOrder.getOrderDetails().setFirstName(firstName);
		pcOrder.getOrderDetails().setLastName(lastName);
		pcOrder.getOrderDetails().setUserEmail(userEmail);
		mongo.save(pcOrder);
		return "{\"Status\":\"Success\"}";
	}
	
	
public void  auditEvents(String orderNumber , String userId , String pon , String ponVersion , String eventName , String notes){
	
	EventAudit  eventAudit = eventAuditRepository.findByOrderNumber(orderNumber);
	if(eventAudit != null ){
		Events events[] = new Events[1];
		events[0] = new Events();
		events[0].setEventCreationTime(new Date());
		events[0].setEventName(eventName);
		events[0].setNotes(notes);
		events[0].setPonVersion(ponVersion);
		events[0].setUserId(userId);
		events[0].setPon(pon);

		Update update = new Update();
		if(Optional.ofNullable(events).isPresent()){	
			update.pushAll("events", events);
		}
		Query query = new Query(
				new Criteria().andOperator(Criteria.where("orderNumber").is(orderNumber)));
		
		mongoTemplate.updateFirst(query, update, EventAudit.class);
	}else{
	
	EventAudit eventaudit = new EventAudit();
	eventaudit.setOrderNumber(orderNumber);
	Events events[] = new Events[1];
	events[0] = new Events();
	events[0].setPon(pon);
	events[0].setEventCreationTime(new Date());
	events[0].setEventName(eventName);
	events[0].setNotes(notes);
	events[0].setPonVersion(ponVersion);
	events[0].setUserId(userId);
	eventaudit.setEvents(events);
	eventAuditRepository.save(eventaudit);
	}
}
	
/*	@Override
	public void auditEvents(String logMsg , String userId , long pcOrderId) {
		RestTemplate restTemplate = new RestTemplate();
		AuditEventRequest auditEvents = new AuditEventRequest();
		auditEvents.setLogMsg(logMsg);
		auditEvents.setPcOrderId(pcOrderId);
		auditEvents.setUserId(userId);
		auditEvents.setTimeStamp(new Date());
		logger.info("Invokes AuditEvents ["+auditEvents+"]");
		try{
			restTemplate.postForObject(auditserviceurl, auditEvents, AuditEventRequest.class);
		}catch(Exception e ){
			logger.error("Exception while auditing " , e);
		}
	}*/
	

}
