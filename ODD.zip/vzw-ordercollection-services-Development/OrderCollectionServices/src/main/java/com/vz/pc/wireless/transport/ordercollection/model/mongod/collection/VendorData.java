package com.vz.pc.wireless.transport.ordercollection.model.mongod.collection;

import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.vz.pc.wireless.transport.ordercollection.model.IcscData;

@Document(collection = "vendorData")
public class VendorData {

	@Id
	private String vendor;

	private ArrayList<IcscData> icscList;

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public ArrayList<IcscData> getIcscList() {
		return icscList;
	}

	public void setIcscList(ArrayList<IcscData> icscList) {
		this.icscList = icscList;
	}

	@Override
	public String toString() {
		return "VendorData [vendor=" + vendor + ", icscList=" + icscList + "]";
	}

}
