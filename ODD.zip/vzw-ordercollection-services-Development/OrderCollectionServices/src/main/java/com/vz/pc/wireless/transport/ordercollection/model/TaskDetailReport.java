package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Date;

public class TaskDetailReport {

	   private String REGION;
	   
	   private String ORDERNUMBER;
	   
	   private String TASKNAME;
	   
	   private String ORDERSTATUS;
	   
	   private Date FALLOUTDATE;
	   
	   private String VZID;
	   
	   private String FIRSTNAME;
	   
	   public String getREGION() {
		return REGION;
	}

	public void setREGION(String rEGION) {
		REGION = rEGION;
	}

	public String getORDERNUMBER() {
		return ORDERNUMBER;
	}

	public void setORDERNUMBER(String oRDERNUMBER) {
		ORDERNUMBER = oRDERNUMBER;
	}

	public String getTASKNAME() {
		return TASKNAME;
	}

	public void setTASKNAME(String tASKNAME) {
		TASKNAME = tASKNAME;
	}

	public String getORDERSTATUS() {
		return ORDERSTATUS;
	}

	public void setORDERSTATUS(String oRDERSTATUS) {
		ORDERSTATUS = oRDERSTATUS;
	}

	public Date getFALLOUTDATE() {
		return FALLOUTDATE;
	}

	public void setFALLOUTDATE(Date fALLOUTDATE) {
		FALLOUTDATE = fALLOUTDATE;
	}

	public String getVZID() {
		return VZID;
	}

	public void setVZID(String vZID) {
		VZID = vZID;
	}

	public String getFIRSTNAME() {
		return FIRSTNAME;
	}

	public void setFIRSTNAME(String fIRSTNAME) {
		FIRSTNAME = fIRSTNAME;
	}

	public String getLASTNAME() {
		return LASTNAME;
	}

	public void setLASTNAME(String lASTNAME) {
		LASTNAME = lASTNAME;
	}

	private String LASTNAME;

	@Override
	public String toString() {
		return "TaskDetailReport [REGION=" + REGION + ", ORDERNUMBER=" + ORDERNUMBER + ", TASKNAME=" + TASKNAME
				+ ", ORDERSTATUS=" + ORDERSTATUS + ", FALLOUTDATE=" + FALLOUTDATE + ", VZID=" + VZID + ", FIRSTNAME="
				+ FIRSTNAME + ", LASTNAME=" + LASTNAME + "]";
	}

	public TaskDetailReport(String rEGION, String oRDERNUMBER, String tASKNAME, String oRDERSTATUS, Date fALLOUTDATE,
			String vZID, String fIRSTNAME, String lASTNAME) {
		REGION = rEGION;
		ORDERNUMBER = oRDERNUMBER;
		TASKNAME = tASKNAME;
		ORDERSTATUS = oRDERSTATUS;
		FALLOUTDATE = fALLOUTDATE;
		VZID = vZID;
		FIRSTNAME = fIRSTNAME;
		LASTNAME = lASTNAME;
	}
	
	
	
}
