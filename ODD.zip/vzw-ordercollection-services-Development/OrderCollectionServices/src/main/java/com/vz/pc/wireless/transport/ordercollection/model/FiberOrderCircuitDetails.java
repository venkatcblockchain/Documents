package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.List;
import java.util.Map;

public class FiberOrderCircuitDetails{
	
	List<SegmentDetails> segmentDetails;
	
	Map circuitDetrails;

	public List<SegmentDetails> getSegmentDetails() {
		return segmentDetails;
	}

	public void setSegmentDetails(List<SegmentDetails> segmentDetails) {
		this.segmentDetails = segmentDetails;
	}

	public Map getCircuitDetrails() {
		return circuitDetrails;
	}

	public void setCircuitDetrails(Map circuitDetrails) {
		this.circuitDetrails = circuitDetrails;
	}
}
