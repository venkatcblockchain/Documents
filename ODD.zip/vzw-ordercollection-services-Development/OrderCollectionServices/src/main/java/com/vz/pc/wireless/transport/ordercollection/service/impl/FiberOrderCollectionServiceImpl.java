package com.vz.pc.wireless.transport.ordercollection.service.impl;

import static org.springframework.data.mongodb.core.FindAndModifyOptions.options;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.Future;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.mongodb.BasicDBObject;
import com.mongodb.util.JSON;
import com.vz.pc.wireless.transport.ordercollection.Enumerators.PcCEnum;
import com.vz.pc.wireless.transport.ordercollection.Enumerators.TaskStatus;
import com.vz.pc.wireless.transport.ordercollection.GroovyRules.GroovyRuleEvaluator;
import com.vz.pc.wireless.transport.ordercollection.exception.DataNotFoundException;
import com.vz.pc.wireless.transport.ordercollection.model.Events;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrder;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderRequest;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderSegment;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderSite;
import com.vz.pc.wireless.transport.ordercollection.model.LossAttributes;
import com.vz.pc.wireless.transport.ordercollection.model.UIOrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.User;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.CoEMilestone;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.Counters;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.EventAudit;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.InEventStore;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OneFiberOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.TaskInst;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.CoEMilestoneRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.EventAuditRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.InEventStoreRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.OneFiberOrderRepository;
import com.vz.pc.wireless.transport.ordercollection.service.FiberOrderCollectionService;
import com.vz.pc.wireless.transport.ordercollection.util.FiberOrderUtils;

@RefreshScope
@Component("FiberOrderCollectionService")
@Transactional
public class FiberOrderCollectionServiceImpl implements FiberOrderCollectionService {

	private static Logger logger = LoggerFactory.getLogger(FiberOrderCollectionServiceImpl.class);

	@Autowired
	OneFiberOrderRepository fiberOrderRepo;

	@Autowired
	private MongoOperations mongo;

	@Autowired
	GroovyRuleEvaluator RuleEvaluator;

	@Autowired
	InEventStoreRepository inEventStoreRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	EventAuditRepository eventAuditRepository;

	@Autowired
	MongoTemplate mongoTemplate;

	@Value("${url.loadtask}")
	private String loadtask;

	@Value("${url.updatetask}")
	private String updatetask;
	
	@Value("${url.cranConsumptionNotificationUrl}")
	private String cranConsumptionNotificationUrl;

	@Autowired
	CoEMilestoneRepository coEMilestoneRepository;

	@Override
	@Async
	public Future<OneFiberOrder> createFiberOrder(FiberOrderRequest fiberOrderReq) {

		logger.debug("Create Order [" + fiberOrderReq.toString() + "]");

		OneFiberOrder oneFiberOrder = new OneFiberOrder();

		long orderid = getNextSequence("pcWirelessOrder");
		oneFiberOrder = FiberOrderUtils.prepareOneFiberOrder(fiberOrderReq, orderid);

		/*
		 * RuleEvaluator.evaluateRules("changeReasonCode", pcOrderReq,
		 * orderDetails);
		 * 
		 * RuleEvaluator.evaluateRules("productSubCategory", pcOrderReq,
		 * orderDetails);
		 */

		logger.info("Persit One Fiber Order Collection Request [" + oneFiberOrder.toString() + "]");
		fiberOrderRepo.save(oneFiberOrder);

		FiberOrder fiberOrd = oneFiberOrder.getOrder();
		FiberOrderDetails fiberOrdDetails = oneFiberOrder.getOrderDetails();

		/** Persist In Event **/

		InEventStore eventStore = new InEventStore();
		eventStore.setPcOrderId(oneFiberOrder.getId());
		eventStore.setActionType("FIBER_ORD_CREATE_RES");
		eventStore.setCreateTime(new DateTime());
		eventStore.setEventName("Fiber_Internal_OrderCreation_Request");
		eventStore.setSequence(0);
		eventStore.setDestSystem("VZW");
		eventStore.setSourceSystem("VZW");
		String templateName = "ONEFIBER";
		String taskName = "Internal-Order-Collection";
		String source = oneFiberOrder.getSource();
		if (null != source && source.equalsIgnoreCase("CRAN")) {
			eventStore.setSourceSystem("CRAN");
			templateName = "ONEFIBER_CRAN";
		}
		if (null != fiberOrdDetails.getOrderType() && fiberOrdDetails.getOrderType().equalsIgnoreCase("DISCONNECT")) {
			templateName = "ONEFIBER_DISCONNECT";
			taskName = "Internal-Disconnect-Order-Collection";
		}

		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		String jsonOnbj = "";
		try {
			jsonOnbj = ow.writeValueAsString(oneFiberOrder);
			logger.info("input " + jsonOnbj.length());

			BasicDBObject dbObject = (BasicDBObject) JSON.parse(jsonOnbj);

			eventStore.setDbObject(dbObject);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// COEOrder coeOrder = FiberOrderUtils.prepareCOEOrder(fiberOrderReq,
		// orderid);
		// COEOrderResponse coeOrderResponse =
		// restTemplate.postForObject(loadtask, coeOrder,
		// COEOrderResponse.class);

		long id = getNextSequence("ineventstore");
		eventStore.setId(id);
		InEventStore inEventStore = inEventStoreRepository.save(eventStore);

		logger.info("Persisted in  InEventStore Collection [" + inEventStore.toString() + "]");

		TaskInst taskInstData = new TaskInst(new Long(0), taskName, fiberOrd.getOrderNumber(), "", "01", "", new Date(),
				null, null, null, fiberOrdDetails.getUserId(), TaskStatus.NEW.toString(), "0000", "To Be Loaded", null,
				null, templateName, null);

		if ("Move".equals(fiberOrdDetails.getOrderType())) {
			taskInstData.setMoveOrd("N");
		} else {
			taskInstData.setMoveOrd(null);
		}
		logger.info("Load All tasks for orderNumber [" + fiberOrd.getOrderNumber() + "] ");
		restTemplate.postForObject(loadtask, taskInstData, String.class);

		logger.info("Invokes Update Task for OrderNumber [" + fiberOrd.getOrderNumber() + " ] with url [" + updatetask
				+ "]");

		auditEvents(fiberOrd.getOrderNumber(), fiberOrdDetails.getUserId(), "", "01", taskName,
				"[SUCCESS ] One Fiber order Created Succcessfully");

		taskInstData = new TaskInst(new Long(0), taskName, fiberOrd.getOrderNumber(), "", "01", "", null, null,
				new Date(), inEventStore.getCreateTime().toDate(), fiberOrdDetails.getUserId(),
				TaskStatus.COMPLETE.toString(), "0000", "Internal-Order-Collection Task Completed Successfully ", null,
				null, templateName, null);
		if ("Move".equals(fiberOrdDetails.getOrderType())) {
			taskInstData.setMoveOrd("N");
		} else {
			taskInstData.setMoveOrd(null);
		}
		TaskInst taskInst = restTemplate.postForObject(updatetask, taskInstData, TaskInst.class);
		eventStore.setTaskId(taskInst.getTaskid());
		inEventStore = inEventStoreRepository.save(eventStore);

		/*
		 * if("Move".equals(fiberOrdDetails.getOrderType())){ TaskInst
		 * taskInstData1 = new TaskInst(new Long(0),
		 * "Internal-Order-Collection", fiberOrd.getOrderNumber(), "", "01", "",
		 * new Date(), null, null, null, fiberOrdDetails.getUserId(),
		 * TaskStatus.NEW.toString(), "0000", "To Be Loaded", null,
		 * null,"GENERIC" , null);
		 * 
		 * taskInstData1.setMoveOrd("D");
		 * logger.info("Load All tasks for orderNumber ["+fiberOrd.
		 * getOrderNumber()+"] "); restTemplate.postForObject(loadtask,
		 * taskInstData1, String.class);
		 * 
		 * logger.info("Invokes Update Task for OrderNumber ["+fiberOrd.
		 * getOrderNumber() + " ] with url [" + updatetask + "]");
		 * 
		 * auditEvents(fiberOrd.getOrderNumber(), fiberOrdDetails.getUserId(),
		 * "", "01", "Internal-Order-Collection",
		 * "[SUCCESS ] VzW Transport order Created Succcessfully");
		 * 
		 * taskInstData1 = new TaskInst(new Long(0),
		 * "Internal-Order-Collection", fiberOrd.getOrderNumber(), "", "01", "",
		 * null, null, new Date(), inEventStore.getCreateTime().toDate(),
		 * fiberOrdDetails.getUserId(), TaskStatus.COMPLETE.toString(), "0000",
		 * "Internal-Order-Collection Task Completed Successfully ", null,
		 * null,"GENERIC" , null);
		 * 
		 * taskInstData1.setMoveOrd("D"); TaskInst taskInst1 =
		 * restTemplate.postForObject(updatetask, taskInstData1,
		 * TaskInst.class); eventStore.setTaskId(taskInst1.getTaskid());
		 * inEventStore = inEventStoreRepository.save(eventStore); }
		 */

		if ("install".equalsIgnoreCase(fiberOrderReq.getOrderType())
				&& !"CRAN".equalsIgnoreCase(fiberOrderReq.getSource()) && "DF".equalsIgnoreCase(fiberOrderReq.getRequestType())) {
			sendNotificationToCRAN(oneFiberOrder);
		}
		return new AsyncResult<OneFiberOrder>(oneFiberOrder);
	}

	private void sendNotificationToCRAN(OneFiberOrder oneFiberOrder) {
		
		logger.info("Sending manual consuption order created notification to CRAN for order [{}] started"
				+ oneFiberOrder.getOrder().getOrderNumber());
		final HttpHeaders headers = new HttpHeaders();
		try {
			User user = new User();
			user.setUserId(oneFiberOrder.getOrderDetails().getUserId());
			final ObjectMapper objectMapper = new ObjectMapper();
			headers.set("user", objectMapper.writeValueAsString(user));
			final HttpEntity<OneFiberOrder> cranRequest = new HttpEntity<>(oneFiberOrder, headers);
			
			logger.info("URL:{} Request: {}",cranConsumptionNotificationUrl,new ObjectMapper().writeValueAsString(oneFiberOrder));
			final ResponseEntity<String> response = restTemplate.exchange(cranConsumptionNotificationUrl, HttpMethod.POST, cranRequest, String.class);
			logger.info("URL:{} Response: {}",cranConsumptionNotificationUrl, response);
		} catch (Exception e) {
			logger.info("Sending manual consuption order created notification to CRAN for order [{}] failed"
					+ oneFiberOrder.getOrder().getOrderNumber(), e);
		}

		logger.info("Sending manual consuption order created notification to CRAN for order [{}] completed"
				+ oneFiberOrder.getOrder().getOrderNumber());
	}

	@Override
	@Async
	public UIOrderDetails getFiberOrderDetails(String orderNumber) {

		logger.debug("Order Detail  [" + orderNumber + "]");

		OneFiberOrder oneFiberOrder = fiberOrderRepo.findByOrderOrderNumber(orderNumber);

		UIOrderDetails orderDetails = new UIOrderDetails();

		FiberOrderDetails fiberOrderDetail = Optional.ofNullable(oneFiberOrder.getOrderDetails())
				.orElseThrow(() -> new DataNotFoundException(null, null,
						"  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

		FiberOrder fiberOrder = Optional.ofNullable(oneFiberOrder.getOrder())
				.orElseThrow(() -> new DataNotFoundException(null, null,
						"  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

		List<FiberOrderSegment> segmentList = Arrays
				.asList(Optional.ofNullable(fiberOrderDetail.getSegments()).orElse(null));

		int segSize = 1;

		if (segmentList != null) {

			segSize = segmentList.size();
		}

		String orderStatus = null;

		orderStatus = PcCEnum.OrderStatus.name(PcCEnum.OrderStatus.getValueBygetFieldName(fiberOrder.getOrderStatus()));
		orderDetails.setOrderStatus(orderStatus);
		orderDetails.setOrderVersion(fiberOrder.getOrderVersion());
		orderDetails.setOrderNumber(orderNumber);

		if (Optional.ofNullable(fiberOrderDetail.getCustomerDesiredDueDate()).isPresent())
			orderDetails.setCustomerDesiredDueDate(new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault())
					.format(fiberOrderDetail.getCustomerDesiredDueDate()));

		if (Optional.ofNullable(fiberOrderDetail.getCustomerMustHaveDueDate()).isPresent())
			orderDetails.setCustomerMustHaveDueDate(new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault())
					.format(fiberOrderDetail.getCustomerMustHaveDueDate()));

		orderDetails.setRegion(fiberOrderDetail.getRegion());

		Optional<FiberOrderSegment> fiberOrdSegment = segmentList.stream().findFirst();

		orderDetails.setBandwidth(fiberOrdSegment.get().getBandwidth());
		orderDetails.setConnectionPoint(fiberOrdSegment.get().getConnectionPoint());
		orderDetails.setDistanceLimitation(fiberOrdSegment.get().getDistanceLimitation());
		orderDetails.setLossLimitation(fiberOrdSegment.get().getLossLimitation());
		
		orderDetails.setOrderType(fiberOrderDetail.getOrderType());
		
		FiberOrderSite aSite = fiberOrderDetail.getSites()[0];
		FiberOrderSite zSite = fiberOrderDetail.getSites()[1];
		
		//ASite details
		orderDetails.setSiteAId(aSite.getSiteId());
		orderDetails.setaSiteName(aSite.getSiteName());
		orderDetails.setSiteTypeA(aSite.getType());
		orderDetails.setLatitudeA(aSite.getLatitude());
		orderDetails.setLongitudeA(aSite.getLongitude());
		orderDetails.setStreetA(aSite.getStreet());
		orderDetails.setCityA(aSite.getCity());
		orderDetails.setStateA(aSite.getState());
		orderDetails.setZipA(aSite.getZip());
		orderDetails.setCountryA(aSite.getCountry());
		orderDetails.setSiterraSiteIdA(aSite.getSiterraSiteId());
		orderDetails.setPeopleSoftLocCdA(aSite.getPeoplesoftLocationCode());
		orderDetails.setaSiteClli(aSite.getClli());
		
		//ZSite details
		orderDetails.setSiteZId(zSite.getSiteId());
		orderDetails.setzSiteName(zSite.getSiteName());
		orderDetails.setSiteTypeZ(zSite.getType());
		orderDetails.setSiteSubType(zSite.getSiteSubType());
		orderDetails.setLatitudeZ(zSite.getLatitude());
		orderDetails.setLongitudeZ(zSite.getLongitude());
		orderDetails.setStreetZ(zSite.getStreet());
		orderDetails.setCityZ(zSite.getCity());
		orderDetails.setStateZ(zSite.getState());
		orderDetails.setZipZ(zSite.getZip());
		orderDetails.setCountryZ(zSite.getCountry());
		orderDetails.setSiterraSiteIdZ(zSite.getSiterraSiteId());
		orderDetails.setPeopleSoftLocCdZ(zSite.getPeoplesoftLocationCode());
		orderDetails.setzNfid(zSite.getSiteNFID());
		orderDetails.setzSiteClli(zSite.getClli());
		
		if (segSize > 1) {
			orderDetails.setMultiCkt("Y");
		} else {
			orderDetails.setMultiCkt("N");
		}
		orderDetails.setProjectId(fiberOrderDetail.getProjectId());
		orderDetails.setNumberOfCircuits(fiberOrderDetail.getNumberOfCircuits());
		orderDetails.setMsc(fiberOrderDetail.getMsc());
		orderDetails.setCranHub(fiberOrderDetail.getCranHub());
		orderDetails.setServiceType(fiberOrderDetail.getServiceType());
		orderDetails.setAction(fiberOrderDetail.getOrderType());
		orderDetails.setVzid(fiberOrderDetail.getUserId());
		orderDetails.setDiversityType(
				(fiberOrderDetail.getDiversityType() != null ? fiberOrderDetail.getDiversityType() : ""));
		orderDetails.setRelatedOrderNumber(
				(fiberOrderDetail.getRelatedOrderNumber() != null ? fiberOrderDetail.getRelatedOrderNumber() : ""));
		orderDetails.setRelatedCircuitId(
				(fiberOrderDetail.getRelatedCircuitId() != null ? fiberOrderDetail.getRelatedCircuitId() : ""));

		PageRequest pageRequest = new PageRequest(0, 1, new Sort(Sort.Direction.DESC, "orderVersion"));
		List<CoEMilestone> coeMilestoneList = coEMilestoneRepository
				.findByOrderNumberOldest(orderNumber + "", pageRequest).getContent();
		if (null != coeMilestoneList && coeMilestoneList.size() > 0) {
			CoEMilestone coEMilestone = coeMilestoneList.get(0);
			if (null != coEMilestone && coEMilestone.getLossAttributes() != null) {
				List<LossAttributes> lossAttributes = Arrays.asList(coEMilestone.getLossAttributes());
				if (lossAttributes != null && lossAttributes.size() > 0) {
					// logger.info("dateRecorded for orderNumber {} is {} ",
					// orderNumber,
					// coEMilestone.getLossAttributes()[0].getDateRecorded());
					String dateRecorded = null;
					if (null != coEMilestone.getLossAttributes()[0]
							&& null != coEMilestone.getLossAttributes()[0].getDateRecorded()) {
						dateRecorded = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault())
								.format(coEMilestone.getLossAttributes()[0].getDateRecorded());
					}
					orderDetails.setDateRecorded(dateRecorded);
				}
			}
		} else {
			logger.info("COEMilestone document is not yet created for Order Number {}", orderNumber);
		}

		logger.info("Persit Order Detail  Request [" + orderNumber + "]");
		return orderDetails;
	}

	public static Date stringToDate(String date, String format) {
		Date d = null;

		try {
			d = new SimpleDateFormat(format).parse(date);
		} catch (ParseException e) {
			logger.error("", e);
		}
		return d;
	}

	public static boolean isBlank(String s) {
		return (s == null || s.trim().length() == 0);
	}

	public int getNextSequence(String collectionName) {
		Counters counter = (Counters) mongo.findAndModify(query(where("id").is(collectionName)),
				new Update().inc("seq", 1), options().returnNew(true), Counters.class);

		return counter.getSeq();
	}

	public void auditEvents(String orderNumber, String userId, String pon, String ponVersion, String eventName,
			String notes) {

		EventAudit eventAudit = eventAuditRepository.findByOrderNumber(orderNumber);
		if (eventAudit != null) {
			Events events[] = new Events[1];
			events[0] = new Events();
			events[0].setEventCreationTime(new Date());
			events[0].setEventName(eventName);
			events[0].setNotes(notes);
			events[0].setPonVersion(ponVersion);
			events[0].setUserId(userId);
			events[0].setPon(pon);

			Update update = new Update();
			if (Optional.ofNullable(events).isPresent()) {
				update.pushAll("events", events);
			}
			Query query = new Query(new Criteria().andOperator(Criteria.where("orderNumber").is(orderNumber)));

			mongoTemplate.updateFirst(query, update, EventAudit.class);
		} else {

			EventAudit eventaudit = new EventAudit();
			eventaudit.setOrderNumber(orderNumber);
			Events events[] = new Events[1];
			events[0] = new Events();
			events[0].setPon(pon);
			events[0].setEventCreationTime(new Date());
			events[0].setEventName(eventName);
			events[0].setNotes(notes);
			events[0].setPonVersion(ponVersion);
			events[0].setUserId(userId);
			eventaudit.setEvents(events);
			eventAuditRepository.save(eventaudit);
		}
	}
}
