package com.vz.pc.wireless.transport.ordercollection.model;

public class COEOrderResponse {

	@Override
	public String toString() {
		return "FiberOrderDetails [requestID=" + requestID + ", statusCode=" + statusCode + ", statusInfo=" + statusInfo
				+  NFID + ", NFID=" + ", alocClli=" + alocClli + ", ZlocClli=" + ZlocClli + "]";
	}

	private String requestID;

	private String statusCode;
	
	private String statusInfo;

	private String NFID;
	
	private String alocClli;
	
	private String ZlocClli;

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusInfo() {
		return statusInfo;
	}

	public void setStatusInfo(String statusInfo) {
		this.statusInfo = statusInfo;
	}

	public String getNFID() {
		return NFID;
	}

	public void setNFID(String nFID) {
		NFID = nFID;
	}

	public String getAlocClli() {
		return alocClli;
	}

	public void setAlocClli(String alocClli) {
		this.alocClli = alocClli;
	}

	public String getZlocClli() {
		return ZlocClli;
	}

	public void setZlocClli(String zlocClli) {
		ZlocClli = zlocClli;
	}
}
