package com.vz.pc.wireless.transport.ordercollection.filter;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.pc.wireless.transport.ordercollection.model.User;
import com.vz.pc.wireless.transport.ordercollection.service.UserInfoService;

@Component
public class RequestFilter implements Filter {

	private static Logger logger = Logger.getLogger(RequestFilter.class.getName());

	@Autowired
	private UserInfoService userInfoService;
	
	@Override
	public void destroy() {
	}
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		
		final HttpServletRequest request = (HttpServletRequest) req;
		final HttpServletResponse response = (HttpServletResponse) res;
		final String uri = request.getRequestURI();

		logger.log(Level.INFO, "Order Collection-Service : Intercepted the URI : {} ", new Object[]{uri});
		logger.log(Level.FINE, "Order Collection-Service : Intercepted the URI : {} ", new Object[]{request.getHeader(User.HEADER_KEY)});

		ObjectMapper objectMapper = new ObjectMapper();
		if(request.getHeader(User.HEADER_KEY) != null ){
		User user =objectMapper.readValue(request.getHeader(User.HEADER_KEY), User.class);
		userInfoService.setUserInfo(user);
		}

		chain.doFilter(req, res);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}

}