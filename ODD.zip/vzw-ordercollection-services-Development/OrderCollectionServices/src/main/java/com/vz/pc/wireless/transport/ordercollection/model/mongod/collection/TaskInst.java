package com.vz.pc.wireless.transport.ordercollection.model.mongod.collection;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "taskinst")
public class TaskInst {
	

	@Id
	private Long taskid;
	
	private String taskName;
	
	private String pcORderNumber;
	
	private String pon;
	
	private String ponVersion;
	
	private String icsc;
	
	private Date taskCreatedTime;
	
	private Date expectedTimeOFArrival;
	
	private Date taskCompletionTime;
	
	private Date eventCreationTime;
	
	private String userId;
	
	private String taskStatus;
	
	private String statusCode;

	private String statusMesaage;
	
	private String uteResponsecode;
	
	private String uteResponseMsg;

	private String source;	
	
	private String inEventName;
	
	private String outEventName;

	public HashMap<String,String> preCheck ;
	
	private String uteTaskId ;
	
	private String retry;
	
	private String rebuild;

	private Map<String , Object> orderOutResponseMap;

	 @Transient
	private List<String> dynamicWorklistTasks;
	 

	 private String dynamciTaskId;
	 
	 
		private boolean createFallOut;
		
		private long retryCount;
		
		
		private String  moveOrd;
		
		
	 public String getMoveOrd() {
			return moveOrd;
		}



		public void setMoveOrd(String moveOrd) {
			this.moveOrd = moveOrd;
		}



	public boolean isCreateFallOut() {
			return createFallOut;
		}



		public void setCreateFallOut(boolean createFallOut) {
			this.createFallOut = createFallOut;
		}



		public long getRetryCount() {
			return retryCount;
		}



		public void setRetryCount(long retryCount) {
			this.retryCount = retryCount;
		}



	public List<String> getDynamicWorklistTasks() {
		return dynamicWorklistTasks;
	}



	public void setDynamicWorklistTasks(List<String> dynamicWorklistTasks) {
		this.dynamicWorklistTasks = dynamicWorklistTasks;
	}



	@Transient
	private List<TaskInst> subtaskInstList;
	
	public List<TaskInst> getSubtaskInstList() {
		return subtaskInstList;
	}



	public void setSubtaskInstList(List<TaskInst> subtaskInstList) {
		this.subtaskInstList = subtaskInstList;
	}



	public TaskInst(){
	}



	public TaskInst(Long taskid, String taskName, String pcORderNumber, String pon, String ponVersion, String icsc, Date taskCreatedTime,
			Date expectedTimeOFArrival, Date taskCompletionTime, Date eventCreationTime, String userId, String taskStatus, String statusCode,
			String statusMesaage, String uteResponsecode, String uteResponseMsg  , String source , HashMap< String , String > preCheck ) {
		this.taskid = taskid;
		this.taskName = taskName;
		this.pcORderNumber = pcORderNumber;
		this.pon = pon;
		this.ponVersion = ponVersion;
		this.icsc = icsc;
		this.taskCreatedTime = taskCreatedTime;
		this.expectedTimeOFArrival = expectedTimeOFArrival;
		this.taskCompletionTime = taskCompletionTime;
		this.eventCreationTime = eventCreationTime;
		this.userId = userId;
		this.taskStatus = taskStatus;
		this.statusCode = statusCode;
		this.statusMesaage = statusMesaage;
		this.uteResponsecode = uteResponsecode;
		this.uteResponseMsg = uteResponseMsg;
		this.source = source;
		this.preCheck = preCheck;
		
	}


	public String getRetry() {
		return retry;
	}



	public void setRetry(String retry) {
		this.retry = retry;
	}



	public String getRebuild() {
		return rebuild;
	}



	public void setRebuild(String rebuild) {
		this.rebuild = rebuild;
	}



	public Map<String, Object> getOrderOutResponseMap() {
		return orderOutResponseMap;
	}



	public void setOrderOutResponseMap(Map<String, Object> orderOutResponseMap) {
		this.orderOutResponseMap = orderOutResponseMap;
	}



	public String getInEventName() {
		return inEventName;
	}



	public void setInEventName(String inEventName) {
		this.inEventName = inEventName;
	}



	public String getOutEventName() {
		return outEventName;
	}



	public void setOutEventName(String outEventName) {
		this.outEventName = outEventName;
	}



	public String getUteTaskId() {
		return uteTaskId;
	}



	public void setUteTaskId(String uteTaskId) {
		this.uteTaskId = uteTaskId;
	}



	public String getSource() {
		return source;
	}



	public void setSource(String source) {
		this.source = source;
	}



	public Date getTaskCreatedTime() {
		return taskCreatedTime;
	}


	public Date getExpectedTimeOFArrival() {
		return expectedTimeOFArrival;
	}


	public Date getTaskCompletionTime() {
		return taskCompletionTime;
	}


	public Date getEventCreationTime() {
		return eventCreationTime;
	}


	public void setTaskCreatedTime(Date taskCreatedTime) {
		this.taskCreatedTime = taskCreatedTime;
	}


	public void setExpectedTimeOFArrival(Date expectedTimeOFArrival) {
		this.expectedTimeOFArrival = expectedTimeOFArrival;
	}


	public void setTaskCompletionTime(Date taskCompletionTime) {
		this.taskCompletionTime = taskCompletionTime;
	}


	public void setEventCreationTime(Date eventCreationTime) {
		this.eventCreationTime = eventCreationTime;
	}


	public Long getTaskid() {
		return taskid;
	}


	public void setTaskid(Long taskid) {
		this.taskid = taskid;
	}


	public String getTaskName() {
		return taskName;
	}


	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}


	public String getPcORderNumber() {
		return pcORderNumber;
	}


	public void setPcORderNumber(String pcORderNumber) {
		this.pcORderNumber = pcORderNumber;
	}


	public String getPon() {
		return pon;
	}


	public void setPon(String pon) {
		this.pon = pon;
	}


	public String getPonVersion() {
		return ponVersion;
	}


	public void setPonVersion(String ponVersion) {
		this.ponVersion = ponVersion;
	}


	public String getIcsc() {
		return icsc;
	}


	public void setIcsc(String icsc) {
		this.icsc = icsc;
	}


/*	public DateTime getTaskCreatedTime() {
		return taskCreatedTime;
	}


	public void setTaskCreatedTime(DateTime taskCreatedTime) {
		this.taskCreatedTime = taskCreatedTime;
	}


	public DateTime getExpectedTimeOFCompletion() {
		return expectedTimeOFCompletion;
	}


	public void setExpectedTimeOFCompletion(DateTime expectedTimeOFCompletion) {
		this.expectedTimeOFCompletion = expectedTimeOFCompletion;
	}


	public DateTime getEventCreationtime() {
		return eventCreationtime;
	}


	public void setEventCreationtime(DateTime eventCreationtime) {
		this.eventCreationtime = eventCreationtime;
	}


	public DateTime getEventCompletedTime() {
		return eventCompletedTime;
	}


	public void setEventCompletedTime(DateTime eventCompletedTime) {
		this.eventCompletedTime = eventCompletedTime;
	}*/


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getTaskStatus() {
		return taskStatus;
	}


	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}


	public String getStatusCode() {
		return statusCode;
	}


	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}


	public String getStatusMesaage() {
		return statusMesaage;
	}


	public void setStatusMesaage(String statusMesaage) {
		this.statusMesaage = statusMesaage;
	}


	public String getUteResponsecode() {
		return uteResponsecode;
	}


	public void setUteResponsecode(String uteResponsecode) {
		this.uteResponsecode = uteResponsecode;
	}


	public String getUteResponseMsg() {
		return uteResponseMsg;
	}


	public void setUteResponseMsg(String uteResponseMsg) {
		this.uteResponseMsg = uteResponseMsg;
	}



	public HashMap<String, String> getPreCheck() {
		return preCheck;
	}



	public void setPreCheck(HashMap<String, String> preCheck) {
		this.preCheck = preCheck;
	}



	public String getDynamciTaskId() {
		return dynamciTaskId;
	}



	public void setDynamciTaskId(String dynamciTaskId) {
		this.dynamciTaskId = dynamciTaskId;
	}



	@Override
	public String toString() {
		return "TaskInst [taskid=" + taskid + ", taskName=" + taskName + ", pcORderNumber=" + pcORderNumber + ", pon="
				+ pon + ", ponVersion=" + ponVersion + ", icsc=" + icsc + ", taskCreatedTime=" + taskCreatedTime
				+ ", expectedTimeOFArrival=" + expectedTimeOFArrival + ", taskCompletionTime=" + taskCompletionTime
				+ ", eventCreationTime=" + eventCreationTime + ", userId=" + userId + ", taskStatus=" + taskStatus
				+ ", statusCode=" + statusCode + ", statusMesaage=" + statusMesaage + ", uteResponsecode="
				+ uteResponsecode + ", uteResponseMsg=" + uteResponseMsg + ", source=" + source + ", inEventName="
				+ inEventName + ", outEventName=" + outEventName + ", preCheck=" + preCheck + ", uteTaskId=" + uteTaskId
				+ ", retry=" + retry + ", rebuild=" + rebuild + ", orderOutResponseMap=" + orderOutResponseMap
				+ ", dynamicWorklistTasks=" + dynamicWorklistTasks + ", dynamciTaskId=" + dynamciTaskId
				+ ", createFallOut=" + createFallOut + ", retryCount=" + retryCount + ", moveOrd=" + moveOrd
				+ ", subtaskInstList=" + subtaskInstList + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventCreationTime == null) ? 0 : eventCreationTime.hashCode());
		result = prime * result + ((expectedTimeOFArrival == null) ? 0 : expectedTimeOFArrival.hashCode());
		result = prime * result + ((icsc == null) ? 0 : icsc.hashCode());
		result = prime * result + ((inEventName == null) ? 0 : inEventName.hashCode());
		result = prime * result + ((orderOutResponseMap == null) ? 0 : orderOutResponseMap.hashCode());
		result = prime * result + ((outEventName == null) ? 0 : outEventName.hashCode());
		result = prime * result + ((pcORderNumber == null) ? 0 : pcORderNumber.hashCode());
		result = prime * result + ((pon == null) ? 0 : pon.hashCode());
		result = prime * result + ((ponVersion == null) ? 0 : ponVersion.hashCode());
		result = prime * result + ((preCheck == null) ? 0 : preCheck.hashCode());
		result = prime * result + ((rebuild == null) ? 0 : rebuild.hashCode());
		result = prime * result + ((retry == null) ? 0 : retry.hashCode());
		result = prime * result + ((source == null) ? 0 : source.hashCode());
		result = prime * result + ((statusCode == null) ? 0 : statusCode.hashCode());
		result = prime * result + ((statusMesaage == null) ? 0 : statusMesaage.hashCode());
		result = prime * result + ((taskCompletionTime == null) ? 0 : taskCompletionTime.hashCode());
		result = prime * result + ((taskCreatedTime == null) ? 0 : taskCreatedTime.hashCode());
		result = prime * result + ((taskName == null) ? 0 : taskName.hashCode());
		result = prime * result + ((taskStatus == null) ? 0 : taskStatus.hashCode());
		result = prime * result + ((taskid == null) ? 0 : taskid.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((uteResponseMsg == null) ? 0 : uteResponseMsg.hashCode());
		result = prime * result + ((uteResponsecode == null) ? 0 : uteResponsecode.hashCode());
		result = prime * result + ((uteTaskId == null) ? 0 : uteTaskId.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaskInst other = (TaskInst) obj;
		if (eventCreationTime == null) {
			if (other.eventCreationTime != null)
				return false;
		} else if (!eventCreationTime.equals(other.eventCreationTime))
			return false;
		if (expectedTimeOFArrival == null) {
			if (other.expectedTimeOFArrival != null)
				return false;
		} else if (!expectedTimeOFArrival.equals(other.expectedTimeOFArrival))
			return false;
		if (icsc == null) {
			if (other.icsc != null)
				return false;
		} else if (!icsc.equals(other.icsc))
			return false;
		if (inEventName == null) {
			if (other.inEventName != null)
				return false;
		} else if (!inEventName.equals(other.inEventName))
			return false;
		if (orderOutResponseMap == null) {
			if (other.orderOutResponseMap != null)
				return false;
		} else if (!orderOutResponseMap.equals(other.orderOutResponseMap))
			return false;
		if (outEventName == null) {
			if (other.outEventName != null)
				return false;
		} else if (!outEventName.equals(other.outEventName))
			return false;
		if (pcORderNumber == null) {
			if (other.pcORderNumber != null)
				return false;
		} else if (!pcORderNumber.equals(other.pcORderNumber))
			return false;
		if (pon == null) {
			if (other.pon != null)
				return false;
		} else if (!pon.equals(other.pon))
			return false;
		if (ponVersion == null) {
			if (other.ponVersion != null)
				return false;
		} else if (!ponVersion.equals(other.ponVersion))
			return false;
		if (preCheck == null) {
			if (other.preCheck != null)
				return false;
		} else if (!preCheck.equals(other.preCheck))
			return false;
		if (rebuild == null) {
			if (other.rebuild != null)
				return false;
		} else if (!rebuild.equals(other.rebuild))
			return false;
		if (retry == null) {
			if (other.retry != null)
				return false;
		} else if (!retry.equals(other.retry))
			return false;
		if (source == null) {
			if (other.source != null)
				return false;
		} else if (!source.equals(other.source))
			return false;
		if (statusCode == null) {
			if (other.statusCode != null)
				return false;
		} else if (!statusCode.equals(other.statusCode))
			return false;
		if (statusMesaage == null) {
			if (other.statusMesaage != null)
				return false;
		} else if (!statusMesaage.equals(other.statusMesaage))
			return false;
		if (taskCompletionTime == null) {
			if (other.taskCompletionTime != null)
				return false;
		} else if (!taskCompletionTime.equals(other.taskCompletionTime))
			return false;
		if (taskCreatedTime == null) {
			if (other.taskCreatedTime != null)
				return false;
		} else if (!taskCreatedTime.equals(other.taskCreatedTime))
			return false;
		if (taskName == null) {
			if (other.taskName != null)
				return false;
		} else if (!taskName.equals(other.taskName))
			return false;
		if (taskStatus == null) {
			if (other.taskStatus != null)
				return false;
		} else if (!taskStatus.equals(other.taskStatus))
			return false;
		if (taskid == null) {
			if (other.taskid != null)
				return false;
		} else if (!taskid.equals(other.taskid))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		if (uteResponseMsg == null) {
			if (other.uteResponseMsg != null)
				return false;
		} else if (!uteResponseMsg.equals(other.uteResponseMsg))
			return false;
		if (uteResponsecode == null) {
			if (other.uteResponsecode != null)
				return false;
		} else if (!uteResponsecode.equals(other.uteResponsecode))
			return false;
		if (uteTaskId == null) {
			if (other.uteTaskId != null)
				return false;
		} else if (!uteTaskId.equals(other.uteTaskId))
			return false;
		return true;
	}









}
