package com.vz.pc.wireless.transport.ordercollection.GroovyRules.scripts

import com.vz.pc.wireless.transport.ordercollection.model.OrderDetails
import com.vz.pc.wireless.transport.ordercollection.model.PcOrderRequest
import com.vz.pc.wireless.transport.ordercollection.model.Segment
import com.vz.pc.wireless.transport.ordercollection.model.Site
import com.vz.pc.wireless.transport.ordercollection.service.GroovyRuleEngine

class MultiLecSegment implements GroovyRuleEngine {
	@Override
	public Object execute(Object obj, Object obj1) {
		Site siteObj = new Site();
		Segment segment = new Segment();
		if (obj != null && obj instanceof Site) {
			try {
				siteObj= (Site) Class.forName("com.vz.pc.wireless.transport.ordercollection.model.Site").cast(obj);
				segment = (Segment) Class.forName("com.vz.pc.wireless.transport.ordercollection.model.Segment").cast(obj1);
				System.out.println("siteObj"+siteObj.toString());
				System.out.println("segment"+ segment);
				if(siteObj != null){
						switch  (siteObj.type)  {
							case "CELL":
							segment.zSiteId = siteObj.siteId							
							break
							default:
								segment.aSiteId = siteObj.siteId
						}
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		return segment;
	}
}
