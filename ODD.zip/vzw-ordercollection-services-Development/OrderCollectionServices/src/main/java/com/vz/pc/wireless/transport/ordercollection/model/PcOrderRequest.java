package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Arrays;

public class PcOrderRequest {
	
	//Order level Info
	private String action;
	
	private String expenditeOrder;
	
	
	private String dueDate;
	
	private String projectId;
	
	private String region;
	
	private String serviceType;
	
	private String tspCode;
	
	//	private String segmentID;
		
	//	private String ban;
	
	private String disconnectCopyFromPON;
	
	private String copyFromPON;
	
	private String cno;
	
	private String multiEcFlag;
	
	private Long orderId;
	
    private String userId;
    
    private String actlCoLocation;

	private String bandWidth;
	
	private Long bandWidthSpeed;
	
	private MultiEC[] multiEC;
	
	private String ccna; 
	
	private String actl ;
	
	private String disconnectOrdReason ;
	
	private String ponNumber ;
	
	private String changeReason ;
	
	private String relatedPon; 
	
	private String hotCut; 
	
	private String asogFlag;
	
	private String firstName;
	
	private String lastName;
	
	private String userEmail;
	

	public String getDisconnectOrdReason() {
		return disconnectOrdReason;
	} 

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public void setDisconnectOrdReason(String disconnectOrdReason) {
		this.disconnectOrdReason = disconnectOrdReason;
	}


	public String getActl() {
		return actl;
	}

	public void setActl(String actl) {
		this.actl = actl;
	}

	public String getCcna() {
		return ccna;
	}

	public void setCcna(String ccna) {
		this.ccna = ccna;
	}

 	private VzWirelessPVCDetails[] pvcDetails;

	//PC_PVC 
	
	//19th june
	
	private String spec;
	
	private String EVCSP;
	
	private String multiDiscoFlag;
	
/*	private MultiDisco[] multiDisco ;
*/	
	private String category;
	
	private String duplicateSegmentFlag;
	
	private String acna;

	
	public String getAcna() {
		return acna;
	}

	public void setAcna(String acna) {
		this.acna = acna;
	}

	public String getDuplicateSegmentFlag() {
		return duplicateSegmentFlag;
	}

	public void setDuplicateSegmentFlag(String duplicateSegmentFlag) {
		this.duplicateSegmentFlag = duplicateSegmentFlag;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getActlCoLocation() {
		return actlCoLocation;
	}

	public void setActlCoLocation(String actlCoLocation) {
		this.actlCoLocation = actlCoLocation;
	}

	public String getBandWidth() {
		return bandWidth;
	}

	public void setBandWidth(String bandWidth) {
		this.bandWidth = bandWidth;
	}

	public Long getBandWidthSpeed() {
		return bandWidthSpeed;
	}

	public void setBandWidthSpeed(Long bandWidthSpeed) {
		this.bandWidthSpeed = bandWidthSpeed;
	}

	public String getCno() {
		return cno;
	}

	public void setCno(String cno) {
		this.cno = cno;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}



	public String getDisconnectCopyFromPON() {
		return disconnectCopyFromPON;
	}

	public void setDisconnectCopyFromPON(String disconnectCopyFromPON) {
		this.disconnectCopyFromPON = disconnectCopyFromPON;
	}

	public String getCopyFromPON() {
		return copyFromPON;
	}

	public void setCopyFromPON(String copyFromPON) {
		this.copyFromPON = copyFromPON;
	}

	public String getExpenditeOrder() {
		return expenditeOrder;
	}

	public void setExpenditeOrder(String expenditeOrder) {
		this.expenditeOrder = expenditeOrder;
	}

	public String getMultiEcFlag() {
		return multiEcFlag;
	}

	public void setMultiEcFlag(String multiEcFlag) {
		this.multiEcFlag = multiEcFlag;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public MultiEC[] getMultiEC() {
		return multiEC;
	}

	public void setMultiEC(MultiEC[] multiEC) {
		this.multiEC = multiEC;
	}



	public VzWirelessPVCDetails[] getPvcDetails() {
		return pvcDetails;
	}

	public void setPvcDetails(VzWirelessPVCDetails[] pvcDetails) {
		this.pvcDetails = pvcDetails;
	}

	public String getTspCode() {
		return tspCode;
	}

	public void setTspCode(String tspCode) {
		this.tspCode = tspCode;
	}

	
	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public String getEVCSP() {
		return EVCSP;
	}

	public void setEVCSP(String eVCSP) {
		EVCSP = eVCSP;
	}

/*	public MultiDisco[] getMultiDisco() {
		return multiDisco;
	}

	public void setMultiDisco(MultiDisco[] multiDisco) {
		this.multiDisco = multiDisco;
	}*/

	public String getMultiDiscoFlag() {
		return multiDiscoFlag;
	}

	public void setMultiDiscoFlag(String multiDiscoFlag) {
		this.multiDiscoFlag = multiDiscoFlag;
	}

	public String getPonNumber() {
		return ponNumber;
	}

	public void setPonNumber(String ponNumber) {
		this.ponNumber = ponNumber;
	}

	public String getChangeReason() {
		return changeReason;
	}

	public void setChangeReason(String changeReason) {
		this.changeReason = changeReason;
	}


	public String getRelatedPon() {
		return relatedPon;
	}

	public void setRelatedPon(String relatedPon) {
		this.relatedPon = relatedPon;
	}

	public String getHotCut() {
		return hotCut;
	}

	public void setHotCut(String hotCut) {
		this.hotCut = hotCut;
	}
	
	public String getAsogFlag() {
		return asogFlag;
	}

	public void setAsogFlag(String asogFlag) {
		this.asogFlag = asogFlag;
	}

	@Override
	public String toString() {
		return "PcOrderRequest [action=" + action + ", expenditeOrder=" + expenditeOrder + ", dueDate=" + dueDate
				+ ", projectId=" + projectId + ", region=" + region + ", serviceType=" + serviceType + ", tspCode="
				+ tspCode + ", disconnectCopyFromPON=" + disconnectCopyFromPON + ", copyFromPON=" + copyFromPON
				+ ", cno=" + cno + ", multiEcFlag=" + multiEcFlag + ", orderId=" + orderId + ", userId=" + userId
				+ ", actlCoLocation=" + actlCoLocation + ", bandWidth=" + bandWidth + ", bandWidthSpeed="
				+ bandWidthSpeed + ", multiEC=" + Arrays.toString(multiEC) + ", ccna=" + ccna + ", actl=" + actl
				+ ", disconnectOrdReason=" + disconnectOrdReason + ", ponNumber=" + ponNumber + ", changeReason="
				+ changeReason + ", relatedPon=" + relatedPon + ", hotCut=" + hotCut + ", asogFlag=" + asogFlag
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", userEmail=" + userEmail + ", pvcDetails="
				+ Arrays.toString(pvcDetails) + ", spec=" + spec + ", EVCSP=" + EVCSP + ", multiDiscoFlag="
				+ multiDiscoFlag + ", category=" + category + ", duplicateSegmentFlag=" + duplicateSegmentFlag
				+ ", acna=" + acna + "]";
	}

}
