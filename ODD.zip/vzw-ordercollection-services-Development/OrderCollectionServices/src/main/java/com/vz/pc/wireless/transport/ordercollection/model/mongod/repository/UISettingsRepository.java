package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vz.pc.wireless.transport.ordercollection.model.UISettings;

public interface UISettingsRepository extends MongoRepository<UISettings, Long> {


/*    @Query(value="{'orderDetails.region': { '$in' : ?0} ,'orderDetails.customerDesiredDueDate': { '$lte' : ?1 , '$gte' : ?2 } }")
	public Page<PcWirelessOrder>  findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDateBetween(List<String> regions , Date custDate , Date custsDate , Pageable pageable );
    
    @Query(value="{'orderDetails.region': { '$in' : ?0} ,'orderDetails.customerDesiredDueDate': { '$lte' : ?1 , '$gte' : ?2 } }")
 	public List<PcWirelessOrder>  findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDateBetween(List<String> regions , Date custDate , Date custsDate  );
     
    @Query(value="{'orderDetails.customerDesiredDueDate': { '$lte' : ?0 , '$gte' : ?1 } }")
  	public List<PcWirelessOrder>  findByOrderDetailsCustomerDesiredDueDateBetween( Date custDate , Date custsDate  );
      
    @Query(value="{'orderDetails.region': { '$in' : ?0} ,'orderDetails.customerDesiredDueDate' : ?1 } }")
	public Page<PcWirelessOrder>  findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDate(List<String> regions ,Date custDate ,  Pageable pageable );
    
    
    @Query(value="{'orderDetails.region': { '$in' : ?0} ,'orderDetails.customerDesiredDueDate' : ?1 } }")
	public List<PcWirelessOrder>  findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDate(List<String> regions ,Date custDate );
*/

	public UISettings findByUserIdAndObjectName(String userId , String ojectName);
  

	public List<UISettings> findByUserId(String userId);

}
