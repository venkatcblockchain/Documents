package com.vz.pc.wireless.transport.ordercollection.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.vz.pc.wireless.transport.ordercollection.model.PcWirelessRemarkRequest;

@Configuration
public class StrikeRemarksValidator implements Validator{

	private static Logger logger = LoggerFactory.getLogger(StrikeRemarksValidator.class);
	
	@Override
	public boolean supports(Class<?> clazz) {
		return PcWirelessRemarkRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
	
		PcWirelessRemarkRequest request = (PcWirelessRemarkRequest) target;
		

		if (request == null) {
			logger.info("Validating If Strike Remarks Request is Empty", request);
			errors.rejectValue("StrikeRemarksRequest", "StrikeRemarksRequest", "Empty request");
		}
		
		if(request.getPcOrderId() != null && request.getPcOrderId() ==  0){
			logger.info("Requested pc orderid should be greater than :", 0);
			errors.rejectValue("pc orderid", "pc orderid.invalid", new Object[] { request.getPcOrderId() },
					"[ " + request.getPcOrderId() + " ] should be greater than 0");
		}
		
		if(request.getNotesRemarksId() != null && request.getNotesRemarksId() ==  0){
			logger.info("Requested Notes Remarks Id should be greater than :", 0);
			errors.rejectValue("NotesRemarksId", "Notes Remarks Id.invalid", new Object[] { request.getNotesRemarksId() },
					"[ " + request.getNotesRemarksId() + " ] should be greater than 0");
		}
		
	}

}
