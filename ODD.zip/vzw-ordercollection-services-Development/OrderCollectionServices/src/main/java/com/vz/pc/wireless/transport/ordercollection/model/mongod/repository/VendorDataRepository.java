package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.VendorData;

public interface VendorDataRepository extends MongoRepository<VendorData, String> {

	
	
}
