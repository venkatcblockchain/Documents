package com.vz.pc.wireless.transport.ordercollection.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LocationEnd {

	private String type;
	
	private String vendor;
	
	private String relayRack;
	
	private String panel_or_mountngPosition;
	
	private String shelf_or_logical_shelf;
	
	private String tx_jack;
	
	private String Rcv_jack;
	
	private String floor;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getRelayRack() {
		return relayRack;
	}

	public void setRelayRack(String relayRack) {
		this.relayRack = relayRack;
	}

	public String getPanel_or_mountngPosition() {
		return panel_or_mountngPosition;
	}

	public void setPanel_or_mountngPosition(String panel_or_mountngPosition) {
		this.panel_or_mountngPosition = panel_or_mountngPosition;
	}

	public String getShelf_or_logical_shelf() {
		return shelf_or_logical_shelf;
	}

	public void setShelf_or_logical_shelf(String shelf_or_logical_shelf) {
		this.shelf_or_logical_shelf = shelf_or_logical_shelf;
	}

	public String getTx_jack() {
		return tx_jack;
	}

	public void setTx_jack(String tx_jack) {
		this.tx_jack = tx_jack;
	}
	@JsonProperty(value ="Rcv_jack")

	public String getRcv_jack() {
		return Rcv_jack;
	}
	@JsonProperty(value ="Rcv_jack")

	public void setRcv_jack(String rcv_jack) {
		Rcv_jack = rcv_jack;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	@Override
	public String toString() {
		return "LocationEnd [type=" + type + ", vendor=" + vendor + ", relayRack=" + relayRack
				+ ", panel_or_mountngPosition=" + panel_or_mountngPosition + ", shelf_or_logical_shelf="
				+ shelf_or_logical_shelf + ", tx_jack=" + tx_jack + ", Rcv_jack=" + Rcv_jack + ", floor=" + floor + "]";
	}


	
	
}
