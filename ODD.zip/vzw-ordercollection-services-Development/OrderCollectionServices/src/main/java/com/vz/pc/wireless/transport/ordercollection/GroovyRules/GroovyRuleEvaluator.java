package com.vz.pc.wireless.transport.ordercollection.GroovyRules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.GroovyRules;
import com.vz.pc.wireless.transport.ordercollection.service.GroovyRuleEngine;
import com.vz.pc.wireless.transport.ordercollection.service.GroovyRuleService;

import groovy.lang.GroovyClassLoader;

public class GroovyRuleEvaluator {

	@Autowired
	GroovyRuleService groovyRuleService;

	public Object evaluateRules(String scriptName, Object fromObj, Object toObj) {
	
		GroovyRules desc = groovyRuleService.getGroovyRule(scriptName);
		
		List<String> descList = desc != null ?desc.getScriptDesc() : null;
		StringBuilder  ddd  =new StringBuilder();
		if (descList != null) {
			descList.forEach(e -> {
				ddd.append(e);
				ddd.append("\n");
			});
		}
		String script= "";
		System.out.println("groovyRules**  "+ddd.toString());
			
		GroovyClassLoader classLoader = new GroovyClassLoader();
		Class clazz = classLoader.parseClass(ddd.toString());
		try {

			GroovyRuleEngine groovyRuleEngine = (GroovyRuleEngine) clazz.newInstance();
			toObj = groovyRuleEngine.execute(fromObj, toObj);

		} catch (InstantiationException e) { // TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {

		}

		return toObj;
	}

}