package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;

public class PcWirlessTaskCollection {

	private Long taskid;
	
	private String taskName;
	
	private String pcORderNumber;
	
	private String pon;
	
	private String ponVersion;
	
	private String icsc;
	
	private Date taskCreatedTime;
	
	private Date expectedTimeOFArrival;
	
	private Date taskCompletionTime;
	
	private Date eventCreationTime;
	
	private String userId;
	
	private String taskStatus;
	
	private String statusCode;

	private String statusMesaage;
	
	private String uteResponsecode;
	
	private String uteResponseMsg;

	private String source;	
	
	private String inEventName;
	
	private String outEventName;

	public HashMap<String,String> preCheck ;
	
	private String uteTaskId ;
	
	private String retry;
	
	private String rebuild;

	private Map<String , Object> orderOutResponseMap;


	List<PcWirelessOrder> pcWirelessOrder;


	public Long getTaskid() {
		return taskid;
	}


	public void setTaskid(Long taskid) {
		this.taskid = taskid;
	}


	public String getTaskName() {
		return taskName;
	}


	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}


	public String getPcORderNumber() {
		return pcORderNumber;
	}


	public void setPcORderNumber(String pcORderNumber) {
		this.pcORderNumber = pcORderNumber;
	}


	public String getPon() {
		return pon;
	}


	public void setPon(String pon) {
		this.pon = pon;
	}


	public String getPonVersion() {
		return ponVersion;
	}


	public void setPonVersion(String ponVersion) {
		this.ponVersion = ponVersion;
	}


	public String getIcsc() {
		return icsc;
	}


	public void setIcsc(String icsc) {
		this.icsc = icsc;
	}


	public Date getTaskCreatedTime() {
		return taskCreatedTime;
	}


	public void setTaskCreatedTime(Date taskCreatedTime) {
		this.taskCreatedTime = taskCreatedTime;
	}


	public Date getExpectedTimeOFArrival() {
		return expectedTimeOFArrival;
	}


	public void setExpectedTimeOFArrival(Date expectedTimeOFArrival) {
		this.expectedTimeOFArrival = expectedTimeOFArrival;
	}


	public Date getTaskCompletionTime() {
		return taskCompletionTime;
	}


	public void setTaskCompletionTime(Date taskCompletionTime) {
		this.taskCompletionTime = taskCompletionTime;
	}


	public Date getEventCreationTime() {
		return eventCreationTime;
	}


	public void setEventCreationTime(Date eventCreationTime) {
		this.eventCreationTime = eventCreationTime;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getTaskStatus() {
		return taskStatus;
	}


	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}


	public String getStatusCode() {
		return statusCode;
	}


	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}


	public String getStatusMesaage() {
		return statusMesaage;
	}


	public void setStatusMesaage(String statusMesaage) {
		this.statusMesaage = statusMesaage;
	}


	public String getUteResponsecode() {
		return uteResponsecode;
	}


	public void setUteResponsecode(String uteResponsecode) {
		this.uteResponsecode = uteResponsecode;
	}


	public String getUteResponseMsg() {
		return uteResponseMsg;
	}


	public void setUteResponseMsg(String uteResponseMsg) {
		this.uteResponseMsg = uteResponseMsg;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getInEventName() {
		return inEventName;
	}


	public void setInEventName(String inEventName) {
		this.inEventName = inEventName;
	}


	public String getOutEventName() {
		return outEventName;
	}


	public void setOutEventName(String outEventName) {
		this.outEventName = outEventName;
	}


	public HashMap<String, String> getPreCheck() {
		return preCheck;
	}


	public void setPreCheck(HashMap<String, String> preCheck) {
		this.preCheck = preCheck;
	}


	public String getUteTaskId() {
		return uteTaskId;
	}


	public void setUteTaskId(String uteTaskId) {
		this.uteTaskId = uteTaskId;
	}


	public String getRetry() {
		return retry;
	}


	public void setRetry(String retry) {
		this.retry = retry;
	}


	public String getRebuild() {
		return rebuild;
	}


	public void setRebuild(String rebuild) {
		this.rebuild = rebuild;
	}


	public Map<String, Object> getOrderOutResponseMap() {
		return orderOutResponseMap;
	}


	public void setOrderOutResponseMap(Map<String, Object> orderOutResponseMap) {
		this.orderOutResponseMap = orderOutResponseMap;
	}


	public List<PcWirelessOrder> getPcWirelessOrder() {
		return pcWirelessOrder;
	}


	public void setPcWirelessOrder(List<PcWirelessOrder> pcWirelessOrder) {
		this.pcWirelessOrder = pcWirelessOrder;
	}


	@Override
	public String toString() {
		return "PcWirlessTaskCollection [taskid=" + taskid + ", taskName=" + taskName + ", pcORderNumber="
				+ pcORderNumber + ", pon=" + pon + ", ponVersion=" + ponVersion + ", icsc=" + icsc
				+ ", taskCreatedTime=" + taskCreatedTime + ", expectedTimeOFArrival=" + expectedTimeOFArrival
				+ ", taskCompletionTime=" + taskCompletionTime + ", eventCreationTime=" + eventCreationTime
				+ ", userId=" + userId + ", taskStatus=" + taskStatus + ", statusCode=" + statusCode
				+ ", statusMesaage=" + statusMesaage + ", uteResponsecode=" + uteResponsecode + ", uteResponseMsg="
				+ uteResponseMsg + ", source=" + source + ", inEventName=" + inEventName + ", outEventName="
				+ outEventName + ", preCheck=" + preCheck + ", uteTaskId=" + uteTaskId + ", retry=" + retry
				+ ", rebuild=" + rebuild + ", orderOutResponseMap=" + orderOutResponseMap + ", pcWirelessOrder="
				+ pcWirelessOrder + "]";
	}


	
	
}
