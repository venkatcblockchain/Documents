package com.vz.pc.wireless.transport.ordercollection.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.vz.pc.wireless.transport.ordercollection.config.SwaggerConfig;
import com.vz.pc.wireless.transport.ordercollection.model.IcscData;
import com.vz.pc.wireless.transport.ordercollection.model.MongoParams;
import com.vz.pc.wireless.transport.ordercollection.model.VendorDataSet;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.AcnaCcnaData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.VendorData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.AcnaCcnaDataRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.VendorDataRepository;
import com.vz.pc.wireless.transport.ordercollection.service.IVendorIcscDetails;

@Component("iVendorIcscDetails")
@EnableAutoConfiguration(exclude = { SwaggerConfig.class })
@Transactional
public class VendorIcscDetailServiceImpl implements IVendorIcscDetails {

	private static Logger logger = LoggerFactory.getLogger(VendorIcscDetailServiceImpl.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	VendorDataRepository vendorDataRepository;

	@Autowired
	AcnaCcnaDataRepository acnaCcnaDataRepository;
	
	
	@Override
	public void addVendorIcscDetail(VendorData vendorData) {
		
		vendorDataRepository.save(vendorData);
		logger.info("Vendor Info Added Successfully");
	}

	@Override
	public void updateVendorDetail(VendorDataSet updVendorData) {
		logger.info("Update Vendor Data for [" + updVendorData + "]");
		Update update = new Update();
		VendorData vendorData = vendorDataRepository.findOne(updVendorData.getVendor());
		if (Optional.ofNullable(vendorData).isPresent()) {
			logger.info("Vendor Data exists to update[" + vendorData.toString() + "]");
			updVendorData.getIcscList().forEach(icsc -> {
				Query query = new Query(
						new Criteria().andOperator(Criteria.where("_id").is(updVendorData.getVendor())));
				IcscData IcscData = vendorData.getIcscList().stream()
						.filter(e -> e.getIcsc().equalsIgnoreCase(icsc.getIcsc())).findAny().orElse(null);
				if (Optional.ofNullable(IcscData).isPresent()) {

					logger.info("If the Icsc Name is Already Present - Go for Next level / Acna /Ccna ");
					String[] ancna = icsc.getAddAcnaList().stream().toArray(size -> new String[size]);
					String[] acnaDel = icsc.getDelAcnaList().stream().toArray(sized -> new String[sized]);
					String[] ccna = icsc.getAddCcnaList().stream().toArray(sizec -> new String[sizec]);
					String[] ccnaDel = icsc.getDelCcnaList().stream().toArray(sized -> new String[sized]);

					query.addCriteria(Criteria.where("icscList.icsc").is(icsc.getIcsc()));
					update.pushAll("icscList.$.acna", ancna);
					update.pushAll("icscList.$.ccna", ccna);
					update.set("icscList.$.email", icsc.getEmail());
					update.set("icscList.$.asogFlag", icsc.getAsogFlag());
					logger.info("query " + query.toString());
					mongoTemplate.updateFirst(query, update, VendorData.class);
					Update updatePull = new Update().pullAll("icscList.$.ccna", ccnaDel);
					updatePull.pullAll("icscList.$.acna", acnaDel);
					mongoTemplate.updateFirst(query, updatePull, VendorData.class);
				} else {
					logger.info("Add New he Icsc to the esisting vendor ");

					IcscData newIcscData = new IcscData();
					logger.info("If the Icsc Name is Already Present - Go for Next level / Acna /Ccna ");
					newIcscData.setAcna(icsc.getAddAcnaList());
					newIcscData.setCcna(icsc.getAddCcnaList());
					newIcscData.setIcsc(icsc.getIcsc());
					newIcscData.setAsogFlag(icsc.getAsogFlag());
					newIcscData.setEmail(icsc.getEmail());

					Update updateNewIcsc = new Update().push("icscList", newIcscData);
					logger.info("query " + query.toString());
					mongoTemplate.updateFirst(query, updateNewIcsc, VendorData.class);
				}

			});

		}

		/*
		 * Query query = new Query(new
		 * Criteria().andOperator(Criteria.where("_id").is(vendorData.getVendor(
		 * )),
		 * Criteria.where("icscList.icsc").is(vendorData.getIcscList().get(0).
		 * getIcsc())
		 * 
		 * , Criteria.where("contacts.collection._class").is("SubClass2")
		 * 
		 * )); String[] ancna =
		 * vendorData.getIcscList().get(0).getAcna().stream().toArray(size ->
		 * new String[size]); String[] ccna =
		 * vendorData.getIcscList().get(0).getCcna().stream().toArray(sizec ->
		 * new String[sizec]);
		 * Arrays.stream(ancna).forEach(System.out::println);
		 * 
		 * Update update = new Update().pushAll("icscList.$.acna", ancna);
		 * update.pushAll("icscList.$.ccna", ccna); update.pushAll("icscList.$",
		 * ancna); mongoTemplate.updateFirst(query, update, VendorData.class);
		 */
	}

	@Override
	public void updateVendorDetail(VendorData updVendorData) {
		logger.info("Update Vendor Data for [" + updVendorData + "]");
		VendorData vendorData = vendorDataRepository.findOne(updVendorData.getVendor());
		if (Optional.ofNullable(vendorData).isPresent()) {
			logger.info("Vendor Data exists to update[" + vendorData.toString() + "]");
			vendorDataRepository.save(updVendorData);
		}
	}

	@Override
	public void removeVendorDetail(VendorData delVendorData) {
		logger.info("Delete Vendor Data for [" + delVendorData + "]");
		VendorData vendorData = vendorDataRepository.findOne(delVendorData.getVendor());
		if (Optional.ofNullable(vendorData).isPresent()) {
			logger.info("Vendor Data exists to update[" + vendorData.toString() + "]");

			if (!Optional.ofNullable(delVendorData.getIcscList()).isPresent() ||  delVendorData.getIcscList().size() == 0) {
				logger.info("Delete entire Data for Vendor [" + delVendorData.toString() + "]");
				vendorDataRepository.delete(vendorData);
			} else {
				IcscData[] iscsArray = delVendorData.getIcscList().stream().toArray(size -> new IcscData[size]);
				Query query = new Query(
						new Criteria().andOperator(Criteria.where("_id").is(delVendorData.getVendor())));
				logger.info("iscsArray " + iscsArray.toString());
				Update update = new Update();
				delVendorData.getIcscList().stream().forEach(icscData -> {
					update.pull("icscList", icscData);
					logger.info("Delete Vendor  Data for Icsc [" + update.toString() + "]");
				});
				mongoTemplate.updateFirst(query, update, VendorData.class);
			}
		}
	}

	@Override
	public List<VendorData> fetchVendorIcscDetail() {
		logger.info("VendorISCFetch");
		return vendorDataRepository.findAll();
	}

	
	public void addAcnaccnaData(AcnaCcnaData acnaCcnaData){
		
		Update update = new Update();
	if(Optional.ofNullable(acnaCcnaData.getAcna()).isPresent()){	
		String[] acnaArray = acnaCcnaData.getAcna().stream().toArray(size -> new String[size]);
		update.pushAll("acna", acnaArray);
	}
	if(Optional.ofNullable(acnaCcnaData.getCcna()).isPresent()){
		String[] ccnaArray = acnaCcnaData.getCcna().stream().toArray(size -> new String[size]);
		update.pushAll("ccna", ccnaArray);
	}
	
	if(Optional.ofNullable(acnaCcnaData.getBandwidth()).isPresent()){
				
		MongoParams[] bandwidthArray = acnaCcnaData.getBandwidth().stream().toArray(size -> new MongoParams[size]);
		update.pushAll("bandwidth", bandwidthArray);
	}
	
	if(Optional.ofNullable(acnaCcnaData.getRegions()).isPresent()){
				MongoParams[] regionsArray = acnaCcnaData.getRegions().stream().toArray(size -> new MongoParams[size]);
				update.pushAll("regions", regionsArray);
	}
	//TODO  To add bandwidth
	mongoTemplate.updateFirst(null, update, AcnaCcnaData.class);	
	
	}
	
	public void removeAcnaCcnaData(AcnaCcnaData acnaCcnaData){
		
	Update update = new Update();
	Update updateVenodracna = null;
	Update updateVenodrccna = null;
	Query queryAcna = new Query();
	Query queryCcna = new Query();

	if(Optional.ofNullable(acnaCcnaData.getAcna()).isPresent()){	
		String[] acnaArray = acnaCcnaData.getAcna().stream().toArray(size -> new String[size]);
		update.pullAll("acna", acnaArray);
		updateVenodracna = new Update();
		updateVenodracna.pullAll("icscList.$.acna", acnaArray);
		queryAcna = new Query(new Criteria().andOperator(Criteria.where("icscList.acna").in(acnaCcnaData.getAcna())	
				)
				);
	}
	if(Optional.ofNullable(acnaCcnaData.getCcna()).isPresent()){
		String[] ccnaArray = acnaCcnaData.getCcna().stream().toArray(size -> new String[size]);
		update.pullAll("ccna", ccnaArray);
		updateVenodrccna = new Update();
		updateVenodrccna.pullAll("icscList.$.ccna", ccnaArray);
		queryCcna = new Query(new Criteria().andOperator(Criteria.where("icscList.ccna").in(acnaCcnaData.getCcna())	
				)
				);
	}
	
	if(Optional.ofNullable(acnaCcnaData.getBandwidth()).isPresent()){
		MongoParams[] bandwidthArray = acnaCcnaData.getBandwidth().stream().toArray(size -> new MongoParams[size]);
		update.pullAll("bandwidth", bandwidthArray);
	}
	
	if(Optional.ofNullable(acnaCcnaData.getRegions()).isPresent()){
				MongoParams[] regionsArray = acnaCcnaData.getRegions().stream().toArray(size -> new MongoParams[size]);
				update.pullAll("regions", regionsArray);
	}
	
	//TODO  To add bandwidth	
	logger.info("update "+update.toString());
	mongoTemplate.updateMulti(null, update, AcnaCcnaData.class);	
	
	if(updateVenodracna != null){
		mongoTemplate.updateMulti(queryAcna, updateVenodracna, VendorData.class);	

	} if(updateVenodrccna != null){
		mongoTemplate.updateMulti(queryCcna, updateVenodrccna, VendorData.class);	

	}
	

	
	}

	@Override
	public AcnaCcnaData fetchAcnaCcnaDetail() {
	return	acnaCcnaDataRepository.findAll().get(0);
	}
	
	
}
