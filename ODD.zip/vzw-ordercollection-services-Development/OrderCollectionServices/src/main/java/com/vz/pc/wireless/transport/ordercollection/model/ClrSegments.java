package com.vz.pc.wireless.transport.ordercollection.model;

public class ClrSegments {
	
	private String segmentInstId;

	private String circuitId;
	
	private LocationEnd aEnd;
	
	private LocationEnd zEnd;


	public ClrSegments( String segmentInstId,
			String circuitId, LocationEnd aEnd, LocationEnd zEnd) {
		this.segmentInstId = segmentInstId;
		this.circuitId = circuitId;
		this.aEnd = aEnd;
		this.zEnd = zEnd;
	}


	public String getSegmentInstId() {
		return segmentInstId;
	}


	public void setSegmentInstId(String segmentInstId) {
		this.segmentInstId = segmentInstId;
	}


	public String getCircuitId() {
		return circuitId;
	}


	public void setCircuitId(String circuitId) {
		this.circuitId = circuitId;
	}


	public LocationEnd getaEnd() {
		return aEnd;
	}


	public void setaEnd(LocationEnd aEnd) {
		this.aEnd = aEnd;
	}


	public LocationEnd getzEnd() {
		return zEnd;
	}


	public void setzEnd(LocationEnd zEnd) {
		this.zEnd = zEnd;
	}


	@Override
	public String toString() {
		return "ClrSegments [segmentInstId=" + segmentInstId + ", circuitId=" + circuitId + ", aEnd=" + aEnd + ", zEnd="
				+ zEnd + "]";
	}

	
	
}
