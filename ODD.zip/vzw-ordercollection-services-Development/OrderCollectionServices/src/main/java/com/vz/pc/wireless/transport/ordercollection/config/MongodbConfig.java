package com.vz.pc.wireless.transport.ordercollection.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.WriteConcern;

@RefreshScope
@Configuration
@EnableMongoRepositories(basePackages = "com.vz.pc.wireless.transport.ordercollection.model.mongod.repository")
public class MongodbConfig extends AbstractMongoConfiguration {

	@Value("${spring.data.mongodb.host}")
	private String mongohost;
	
	
	@Value("${spring.data.mongodb.port}")
	private String port;

	@Value("${spring.data.mongodb.database}")
	private String databaseName;

	@Value("${spring.data.mongodb.username}")
	private String username;
	
	@Value("${spring.data.mongodb.password}")
	private String password;

	@Value("${spring.profiles.active}")
	private String activeProfile;
	
	@Value("${spring.cloud.config.uri}")
	private String cloudconfiguri;
	
	@Value("${spring.application.name}")
	private String applicationname;
	@Override
	protected String getDatabaseName() {
		return databaseName;
	}
	
	@Override
	@Bean
	public MongoClient mongo() throws Exception {
		ServerAddress serverAddress = new ServerAddress(mongohost);
		
		System.out.println("databaseName "+databaseName +"username"+username + "activeProfile  "+activeProfile + "password" + password);
		
		MongoCredential mongocreds = MongoCredential.createScramSha1Credential(username, databaseName, getSecurePassword().toCharArray());
		List<MongoCredential> auths = new ArrayList<MongoCredential>();
		auths.add(mongocreds);
		MongoClient mongo = new MongoClient(serverAddress, auths);
		mongo.setWriteConcern(WriteConcern.SAFE);
		return mongo;
		
	}
	
	@Bean
	public MongoTemplate mongoTemplate() throws Exception {	
		return new MongoTemplate(mongo(), getDatabaseName());
	}
	
	private final StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();

	private String getSecurePassword() throws IOException {
	    getPasswordFromEnvAndSystemProperties();
	    encryptor.setPassword(getPasswordFromEnvAndSystemProperties());

	    Properties props = new EncryptableProperties(encryptor);
	    props.setProperty("password", password);
	 
	    return props.getProperty("password");
	    
	}
	
	
	private static final String ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_UNDERSCORE = "PROPERTY_ENCRYPTION_PASSWORD";
    private static final String ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_DOT = "property_encryption_password";
    private static final String ENCRYPTION_PASSWORD_NOT_SET = "mongopwd";

    private String getPasswordFromEnvAndSystemProperties() {
        String password = System.getenv(ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_UNDERSCORE);
        if (password == null) {
            password = System.getenv(ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_DOT);
            if (password == null) {
                password = System.getProperty(ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_UNDERSCORE);
                if (password == null) {
                    password = System.getProperty(ENCRYPTION_PASSWORD_ENVIRONMENT_VAR_NAME_DOT);
                    if (password == null) {
                        password = ENCRYPTION_PASSWORD_NOT_SET;
                    }
                }
            }
        }
        return password;
    }

}
