package com.vz.pc.wireless.transport.ordercollection.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.vz.pc.wireless.transport.ordercollection.model.OrderDetailReport;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetailRequest;
import com.vz.pc.wireless.transport.ordercollection.model.TaskDetailReport;

@Service
public interface IReportService {
	
	public List<OrderDetailReport> getOrderDetailsReport(OrderDetailRequest OrderReq) ;
	
	public List<TaskDetailReport> getTaskDetailsReport(OrderDetailRequest orderReq);
}
