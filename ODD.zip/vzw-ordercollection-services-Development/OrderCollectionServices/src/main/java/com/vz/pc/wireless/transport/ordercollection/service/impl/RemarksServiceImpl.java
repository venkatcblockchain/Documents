package com.vz.pc.wireless.transport.ordercollection.service.impl;

import static org.springframework.data.mongodb.core.FindAndModifyOptions.options;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import org.codehaus.jettison.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.vz.pc.wireless.transport.ordercollection.Enumerators.RemarksEnum;
import com.vz.pc.wireless.transport.ordercollection.model.PcWirelessRemarkRequest;
import com.vz.pc.wireless.transport.ordercollection.model.RemarksResponse;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.Counters;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessRemark;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.PcWirelessRemarkRepository;
import com.vz.pc.wireless.transport.ordercollection.service.RemarksService;

@Component("RemarksService")
@Transactional
public class RemarksServiceImpl implements RemarksService,RemarksEnum{
	
	
	private static Logger logger = LoggerFactory.getLogger(RemarksServiceImpl.class);
	
	@Autowired
	private PcWirelessRemarkRepository remarksRepo;
	
	@Autowired
	private MongoOperations mongo;

	@Async
	@Override
	public Future<PcWirelessRemark> InsertRemarksInfo(PcWirelessRemarkRequest remarks) {
		PcWirelessRemark remarksSave = new PcWirelessRemark();
		try{
			
		logger.info("Entering into InsertRemarksInfo Method");		
		
		logger.info("Remarks Request [" + remarks.toString() + "] is being Initiated");
		
		remarksSave.setModifiedDate(new Date());
		logger.info("Remarks Request ModifiedDate value [" + new Date() + "]");
		remarksSave.setModifiedBy(remarks.getModifiedBy());
		logger.info("Remarks Request ModifiedBy value [" + remarks.getModifiedBy() + "]");
		remarksSave.setNotesRemarksId(this.getNextSequence("pcWirelessRemark"));
		logger.info("Remarks Request NotesRemarksId value [" + remarksSave.getNotesRemarksId() + "]");
		remarksSave.setRemarksId(remarksSave.getNotesRemarksId());
		logger.info("Remarks Request RemarksId value [" + remarksSave.getNotesRemarksId() + "]");
		remarksSave.setNotesRemarksText(remarks.getNotesRemarksText());
		logger.info("Remarks Request NotesRemarksText value [" + remarks.getNotesRemarksText() + "]");
		remarksSave.setPcOrderId(remarks.getPcOrderId());
		logger.info("Remarks Request PcOrderId value [" + remarks.getPcOrderId() + "]");
		remarksSave.setFiberOrderNumber(remarks.getFiberOrderNumber());
		logger.info("Remarks Request FiberOrderNumber value [" + remarks.getFiberOrderNumber() + "]");
		remarksSave.setStrikeFlag(remarks.getStrikeFlag());
		logger.info("Remarks Request StrikeFlag value [" + remarks.getStrikeFlag() + "]");
		remarksSave.setTaskName(remarks.getTaskName());
		logger.info("Remarks Request TaskName value [" + remarks.getTaskName() + "]");
		remarksRepo.save(remarksSave);
		}
		catch(Exception e){
			e.printStackTrace();
			logger.info("Remarks Insert Error[" + e.toString() + "]");
			throw e;
		}
		logger.info("Remarks Response Object[" + remarksSave.toString() + "]");
		return new AsyncResult<PcWirelessRemark>(remarksSave);
	}

	@Async
	@Override
	public RemarksResponse strikeRemark(PcWirelessRemarkRequest remarks) throws JSONException {
		
		logger.info("Entering into strikeRemark Method");	
		
		PcWirelessRemark remarksObj = new PcWirelessRemark();
		RemarksResponse resp = new RemarksResponse();
		
		
		logger.info("Remarks Request Object["+remarks.toString()+"]");
		try{
		logger.info("Entering into strikeRemark Method");	
		remarksObj.setNotesRemarksId(remarks.getNotesRemarksId());
		logger.info("NotesRemarksId value is["+remarks.getNotesRemarksId()+"]");
		remarksObj.setRemarksId(remarks.getNotesRemarksId());
		logger.info("RemarksId value is["+remarks.getNotesRemarksId()+"]");
		remarksObj.setPcOrderId(remarks.getPcOrderId());
		logger.info("PcOrderId value is["+remarks.getPcOrderId()+"]");
		remarksObj.setFiberOrderNumber(remarks.getFiberOrderNumber());
		logger.info("Remarks Request FiberOrderNumber value [" + remarks.getFiberOrderNumber() + "]");
	//	PcWirelessRemark pcTest = remarksRepo.findOne(Long.parseLong("20"));
	//	PcWirelessRemark pcTest	= remarksRepo.findByremarksIdAndPcOrderId(remarksObj.getRemarksId(),remarksObj.getPcOrderId());
		Query remarksQuery = new Query();
		if (Optional.ofNullable(remarksObj.getPcOrderId()).isPresent()) {
			logger.info("Building query for pcOrderId");
			remarksQuery.addCriteria(Criteria.where("_id").is(remarksObj.getNotesRemarksId()).and("pcOrderId").is(remarksObj.getPcOrderId()));
		} else {
			logger.info("Building query for FiberOrderNumber");
			remarksQuery.addCriteria(Criteria.where("_id").is(remarksObj.getNotesRemarksId()).and("fiberOrderNumber").is(remarksObj.getFiberOrderNumber()));
		}
		logger.info("remarksQuery Object is["+remarksQuery.toString()+"]");
		PcWirelessRemark pcObj = mongo.findOne(remarksQuery, PcWirelessRemark.class);
		logger.info("remarks Object is["+pcObj.toString()+"]");
		System.out.println("pcObj - " + pcObj);

		pcObj.setStrikeFlag("true");
		pcObj.setModifiedDate(new Date());
		logger.info("Strike flag value is["+pcObj.getStrikeFlag()+"]");
		mongo.save(pcObj);
		}
		catch(Exception strikeRemarks){
			strikeRemarks.printStackTrace();
			logger.info("strikeRemarks Error Info["+strikeRemarks.getMessage()+"]");
			resp.setFailure(RemarksEnum.failure);
			return resp;
		}
		logger.info("strikeRemarks Success Info["+resp.getSuccess()+"]");
		resp.setModifiedDate(new Date());
		resp.setSuccess(RemarksEnum.success);
		
		return resp;
	}

	@Async
	@Override
	public RemarksResponse unStrikeRemark(PcWirelessRemarkRequest remarks) {
		
		logger.info("Entering into unStrikeRemark Method");
		
		PcWirelessRemark document = new PcWirelessRemark();
		RemarksResponse remarksResp = new RemarksResponse();
		try{
		document.setNotesRemarksId(remarks.getNotesRemarksId());
		logger.info("NotesRemarksId value is["+remarks.getNotesRemarksId()+"]");
		document.setRemarksId(remarks.getNotesRemarksId());
		logger.info("RemarksId value is["+remarks.getNotesRemarksId()+"]");
		document.setPcOrderId(remarks.getPcOrderId());
		logger.info("PcOrderId value is["+remarks.getPcOrderId()+"]");
		document.setFiberOrderNumber(remarks.getFiberOrderNumber());
		logger.info("FiberOrderNumber value is["+remarks.getFiberOrderNumber()+"]");
		Query remarksQuery = new Query();

		if (Optional.ofNullable(document.getPcOrderId()).isPresent()) {
			logger.info("Building query for pcOrderId");
			remarksQuery.addCriteria(Criteria.where("_id").is(document.getNotesRemarksId()).and("pcOrderId").is(document.getPcOrderId()));
		} else {
			logger.info("Building query for FiberOrderNumber");
			remarksQuery.addCriteria(Criteria.where("_id").is(document.getNotesRemarksId()).and("fiberOrderNumber").is(document.getFiberOrderNumber()));
		}
		//remarksQuery.addCriteria(Criteria.where("_id").is(document.getNotesRemarksId()).and("pcOrderId").is(document.getPcOrderId()));
		PcWirelessRemark pcObj = mongo.findOne(remarksQuery, PcWirelessRemark.class);
		logger.info("remarksQuery Object is["+remarksQuery.toString()+"]");
		pcObj.setStrikeFlag("false");
		logger.info("Strike flag value is["+pcObj.getStrikeFlag()+"]");
		mongo.save(pcObj);
		}
		catch(Exception unStrikeException){
			unStrikeException.getMessage();
			logger.info("strikeRemarks Error Info["+unStrikeException.getMessage()+"]");
			remarksResp.setFailure(RemarksEnum.failure);
			return remarksResp;
		}
		
		logger.info("strikeRemarks Success Info["+remarksResp.getSuccess()+"]");
		remarksResp.setSuccess(RemarksEnum.success);
		return remarksResp;
	}
	
	public long getNextSequence(String collectionName) {
		Counters counter = (Counters) mongo.findAndModify(query(where("id").is(collectionName)), new Update().inc("seq", 1), options().returnNew(true),
				Counters.class);
		return counter.getSeq();
	}
	
	public static Date stringToDate(String date, String format) {
		Date d = null;

		try {
			d = new SimpleDateFormat(format).parse(date);
		} catch (ParseException e) {
			// Do Nothing. Return null
		}
		return d;
	}

	@Async
	@Override
	public List<PcWirelessRemark> getRemarksInfoList(String pcOrderId) {
		
		logger.info("Entering into getRemarksInfoList Method");	
		List<PcWirelessRemark> remarksList = null;
		
		try{
			
		long pcId = Long.parseLong(pcOrderId);	
		
		logger.info("pcorderid is["+pcId+"]");	
		
		remarksList = remarksRepo.findByPcOrderId(pcId);
		
/*		for(int i = 0 ; i < remarksList.size()  ; i++){
			
			  SimpleDateFormat mdyFormat = new SimpleDateFormat("dd-MM-YYYY' 'HH:mm:ss:S");
			  if(remarksList.get(i).getModifiedDate() != null){
			  String strDate = mdyFormat.format(remarksList.get(i).getModifiedDate());
			  System.out.println(strDate);
			  }
			
		}*/
		}
		catch(Exception e){
			e.printStackTrace();
			logger.info("Fetching Remarks List failed due to Error["+e.toString()+"]");	
			throw e;
		}
		
		logger.info("Remarks Response for pcOrderId["+pcOrderId+"] is ["+remarksList.toString()+"]");	
		
		return remarksList;
	}

	@Async
	@Override
	public List<PcWirelessRemark> getFiberOrderRemarksInfoList(String fiberOrderNumber) {

		logger.info("Entering into getRemarksInfoList Method");	
		List<PcWirelessRemark> remarksList = null;

		try {
			long fiberOrderNum = Long.parseLong(fiberOrderNumber);
			logger.info("pcorderid is[" + fiberOrderNum + "]");
			remarksList = remarksRepo.findByFiberOrderNumber(fiberOrderNum);
		}
		catch(Exception e) {
			e.printStackTrace();
			logger.info("Fetching Remarks List failed due to Error["+e.toString()+"]");	
			throw e;
		}

		logger.info("Remarks Response for pcOrderId[" + fiberOrderNumber + "] is [" + remarksList.toString() + "]" );

		return remarksList;
	}
	
/*	public static void main(String args[]){
		
		org.joda.time.format.DateTimeFormatter parser=ISODateTimeFormat.dateHourMinuteSecond();      
		DateTime result=parser.parseDateTime("2014-07-29T07:23:06");
		System.out.println(result.toDate());
		
		
		Hashtable<String,String> map = new Hashtable<String,String>();
		map.put("sidhu","sidhu");
		
		HashMap<String,String> map1 = new HashMap<String,String>();
		map1.put(null,null);
		map1.put(null,"");
		map1.put("",null);
		
		Set<String> a = new HashSet<String>();
		a.add("sidhu");
		a.add("a");
		a.add("sidhu");
		
		List<String> a1 = new ArrayList<String>();
		a1.add("a");
		a1.add("b");
		a1.add("a");
		a1.add("e");
		
		NavigableMap<String,Integer> navigableMap=new TreeMap<String, Integer>();
		
		navigableMap.put("X", 500);
		navigableMap.put("B", 600);
		navigableMap.put("A", 700);
		navigableMap.put("T", 800);
		navigableMap.put("Y", 900);
		navigableMap.put("Z", 200);
			
		System.out.printf("Descending Set  : %s%n",navigableMap.descendingKeySet());
			
		System.out.printf("Floor Entry  : %s%n",navigableMap.floorKey("L"));
			
		System.out.printf("First Entry  : %s%n",navigableMap.firstEntry());
			
		System.out.printf("Last Key : %s%n",navigableMap.lastKey());
			
		System.out.printf("First Key : %s%n",navigableMap.firstKey());
			
		System.out.printf("Original Map : %s%n",navigableMap);
			
		System.out.printf("Reverse Map : %s%n",navigableMap.descendingMap());
		
		System.out.println(a);
		
		System.out.println(a1);
				
		
		System.out.println((new Date()));
	}*/

}
