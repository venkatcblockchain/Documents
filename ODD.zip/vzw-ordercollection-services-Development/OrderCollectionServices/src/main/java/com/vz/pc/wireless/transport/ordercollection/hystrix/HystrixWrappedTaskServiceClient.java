package com.vz.pc.wireless.transport.ordercollection.hystrix;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.vz.pc.wireless.transport.ordercollection.feign.TaskServiceClient;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.TaskInst;


@Service("hystrixTaskServiceClient")
public class HystrixWrappedTaskServiceClient implements TaskServiceClient {

    @Autowired
    @Qualifier("ribbonTaskServiceClient")
    private TaskServiceClient feignTaskServiceClient;

    @Override
    @HystrixCommand(groupKey = "taskServiceGroup", fallbackMethod = "fallBackCall")
    public String create(TaskInst taskInst) {
        return this.feignTaskServiceClient.create(taskInst);
    }

    public TaskInst fallBackCall(TaskInst taskInst) {
    	TaskInst fallback = new TaskInst(taskInst.getTaskid(), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
        return fallback;
    }

	@Override
	@HystrixCommand(groupKey = "taskServiceGroup", fallbackMethod = "fallBackCallUpdate")
	public TaskInst update(TaskInst taskInst) {
	    return this.feignTaskServiceClient.update(taskInst);
	}
	
    public TaskInst fallBackCallUpdate(TaskInst taskInst) {
    	TaskInst fallback = new TaskInst(taskInst.getTaskid(), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
        return fallback;
    }
    
}
