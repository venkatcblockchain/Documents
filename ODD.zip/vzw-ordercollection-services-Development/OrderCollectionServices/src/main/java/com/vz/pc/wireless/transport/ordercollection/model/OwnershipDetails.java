package com.vz.pc.wireless.transport.ordercollection.model;

public class OwnershipDetails {

	
	private String orderNumber;
	private String category;
	private String subCategory;
	private String workGroup;
	private String workPool;
	private String userId;
	private String userName;
	private String lob;
	private String orderSource;
	/**
	 * @return the orderNumber
	 */
	public String getOrderNumber() {
		return orderNumber;
	}
	/**
	 * @param orderNumber the orderNumber to set
	 */
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	/**
	 * @return the subCategory
	 */
	public String getSubCategory() {
		return subCategory;
	}
	/**
	 * @param subCategory the subCategory to set
	 */
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	/**
	 * @return the workGroup
	 */
	public String getWorkGroup() {
		return workGroup;
	}
	/**
	 * @param workGroup the workGroup to set
	 */
	public void setWorkGroup(String workGroup) {
		this.workGroup = workGroup;
	}
	/**
	 * @return the workPool
	 */
	public String getWorkPool() {
		return workPool;
	}
	/**
	 * @param workPool the workPool to set
	 */
	public void setWorkPool(String workPool) {
		this.workPool = workPool;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}
	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}
	/**
	 * @return the orderSource
	 */
	public String getOrderSource() {
		return orderSource;
	}
	/**
	 * @param orderSource the orderSource to set
	 */
	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}
	
	
}
