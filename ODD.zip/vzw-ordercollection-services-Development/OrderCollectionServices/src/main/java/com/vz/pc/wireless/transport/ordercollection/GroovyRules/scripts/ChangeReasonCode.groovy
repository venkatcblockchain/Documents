 package com.vz.pc.wireless.transport.ordercollection.GroovyRules.scripts;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.PcOrderRequest;
import com.vz.pc.wireless.transport.ordercollection.service.GroovyRuleEngine;
class ChangeReasonCode implements GroovyRuleEngine {
	@Override
	public Object execute(Object obj, Object obj1) {
		PcOrderRequest pcOrderReq  = new PcOrderRequest();
		OrderDetails orderDetails = new OrderDetails();
		if (obj != null && obj instanceof PcOrderRequest) {
			try {
				pcOrderReq= (PcOrderRequest) Class.forName("com.vz.pc.wireless.transport.ordercollection.model.PcOrderRequest").cast(obj);
				orderDetails = (OrderDetails) Class.forName("com.vz.pc.wireless.transport.ordercollection.model.OrderDetails").cast(obj1);
				System.out.println("pcOrderReq"+pcOrderReq.toString());
				System.out.println("pcWiteLessOrder"+ orderDetails);
				if(pcOrderReq != null){
					if(pcOrderReq.action != null && !"".equals(pcOrderReq.action)){
						switch  (pcOrderReq.action)  {
							case "N" :
								orderDetails.changeReasion = pcOrderReq.disconnectOrdReason
							case "D":
								orderDetails.changeReasion = pcOrderReq.disconnectOrdReason
							case "C":
								orderDetails.changeReasion = pcOrderReq.changeReason
								break
							default:
								orderDetails.changeReasion = null
						}
					}
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		return orderDetails;
	}
}