package com.vz.pc.wireless.transport.ordercollection.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.vz.pc.wireless.transport.ordercollection.GroovyRules.GroovyRuleEvaluator;
import com.vz.pc.wireless.transport.ordercollection.filter.RequestFilter;
import com.vz.pc.wireless.transport.ordercollection.model.User;

@Configuration
public class AppConfig {
	
	@Autowired
	RequestFilter requestFilter;
	
	@Bean
	public FilterRegistrationBean filterRegistrationBean() {
		final FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		registrationBean.setFilter(requestFilter);
		registrationBean.addUrlPatterns("/order-processing/*");
		return registrationBean;
	}
	
@Bean
	public GroovyRuleEvaluator ruleEvaluator(){
		GroovyRuleEvaluator ruleEvaluator = new GroovyRuleEvaluator();
		return ruleEvaluator;
	}

/** For JODA DateTime Jackson Parsing**/
@Bean
public ObjectMapper objectMapper(){
	ObjectMapper objectMapper = new ObjectMapper();
	objectMapper.registerModule(new JodaModule());
	objectMapper.configure(com.fasterxml.jackson.databind.SerializationFeature.
	    WRITE_DATES_AS_TIMESTAMPS , false);
	return  objectMapper;
}

@Bean
public User user(){
	return new User();
}

@LoadBalanced
@Bean
RestTemplate loadBalanced() {
    return new RestTemplate();
}

@Primary
@Bean
RestTemplate restTemplate() {
    return new RestTemplate();
}
}
