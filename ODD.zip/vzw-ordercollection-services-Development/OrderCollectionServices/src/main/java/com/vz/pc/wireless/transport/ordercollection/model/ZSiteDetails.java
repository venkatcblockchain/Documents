package com.vz.pc.wireless.transport.ordercollection.model;

public class ZSiteDetails {
	
private String siteId;
	
	private String siteName;
	
	private String contact;
	
	private String phone;
	
	private String street;
	
	private String city;
	
	private String state;
	
	private String zip;
	
	private String clli;
	
	private String floor;
	
	private String room;
	
	private String structure;
	
	private String elevation;
	
	private String unit;
	
	private String type;
	
	private String latitude;
	
	private String longitude;
	
	private String siterraSiteId;
	
	private String peoplesoftLocationCode;

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getClli() {
		return clli;
	}

	public void setClli(String clli) {
		this.clli = clli;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public String getStructure() {
		return structure;
	}

	public void setStructure(String structure) {
		this.structure = structure;
	}

	public String getElevation() {
		return elevation;
	}

	public void setElevation(String elevation) {
		this.elevation = elevation;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getSiterraSiteId() {
		return siterraSiteId;
	}

	public void setSiterraSiteId(String siterraSiteId) {
		this.siterraSiteId = siterraSiteId;
	}

	public String getPeoplesoftLocationCode() {
		return peoplesoftLocationCode;
	}

	public void setPeoplesoftLocationCode(String peoplesoftLocationCode) {
		this.peoplesoftLocationCode = peoplesoftLocationCode;
	}

	@Override
	public String toString() {
		return "ZSiteDetails [siteId=" + siteId + ", siteName=" + siteName + ", contact=" + contact + ", phone=" + phone + ", street=" + street + ", city="
				+ city + ", state=" + state + ", zip=" + zip + ", clli=" + clli + ", floor=" + floor + ", room=" + room + ", structure=" + structure
				+ ", elevation=" + elevation + ", unit=" + unit  + ", type=" + type + "]";
	}

}
