package com.vz.pc.wireless.transport.ordercollection;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.ribbon.RibbonClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@EnableHystrix
@RibbonClients
public class OrderCollectionServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderCollectionServicesApplication.class, args);
	}

	@Bean
	public CorsFilter corsFilter() {
	    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	        CorsConfiguration corsConfiguration = new CorsConfiguration();
	        corsConfiguration.setAllowCredentials(true);
	       
	            corsConfiguration.setAllowedHeaders(Arrays.asList("X-Requested-With"  , "Origin", "Content-Type", "Accept" , "Authorization"));	        
	            corsConfiguration.setAllowedMethods(Arrays.asList("GET" , "POST" , "OPTIONS", "DELETE"));
	        
	            corsConfiguration.addAllowedOrigin("*");

	        source.registerCorsConfiguration("/**", corsConfiguration);
	    return new CorsFilter(source);
	}
}
