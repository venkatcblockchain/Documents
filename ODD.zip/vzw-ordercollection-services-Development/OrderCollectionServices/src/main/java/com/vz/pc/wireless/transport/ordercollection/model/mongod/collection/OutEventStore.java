package com.vz.pc.wireless.transport.ordercollection.model.mongod.collection;

import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.mongodb.BasicDBObject;

@Document(collection = "outeventstore")
@CompoundIndexes({
    @CompoundIndex(name = "out_eventstore_idx", def = "{'pcOrderId' : 1, 'eventName' : 1}")
})
public  class OutEventStore {

	@Indexed(unique = true)
	private long id;

	@Indexed
	@CreatedDate
	private DateTime createTime;

	private long pcOrderId;
	
	private String eventName;
	
	private long sequence;

	private String sourceSystem;

	private String destSystem;

	private String actionType;
	
	private long taskId;

	@Indexed
	private String intfMsg;
	
	private BasicDBObject dbObject;
	
	public BasicDBObject getDbObject() {
		return dbObject;
	}

	public void setDbObject(BasicDBObject dbObject) {
		this.dbObject = dbObject;
	}

	private String objectType;
	
	private String connectionString;
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public DateTime getCreateTime() {
		return createTime;
	}

	public void setCreateTime(DateTime createTime) {
		this.createTime = createTime;
	}

	public long getPcOrderId() {
		return pcOrderId;
	}

	public void setPcOrderId(long pcOrderId) {
		this.pcOrderId = pcOrderId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getDestSystem() {
		return destSystem;
	}

	public void setDestSystem(String destSystem) {
		this.destSystem = destSystem;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getIntfMsg() {
		return intfMsg;
	}

	public void setIntfMsg(String intfMsg) {
		this.intfMsg = intfMsg;
	}

	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public long getSequence() {
		return sequence;
	}

	public void setSequence(long sequence) {
		this.sequence = sequence;
	}

	public String getConnectionString() {
		return connectionString;
	}

	public void setConnectionString(String connectionString) {
		this.connectionString = connectionString;
	}

	public long getTaskId() {
		return taskId;
	}

	public void setTaskId(long taskId) {
		this.taskId = taskId;
	}

	@Override
	public String toString() {
		return "OutEventStore [id=" + id + ", createTime=" + createTime + ", pcOrderId=" + pcOrderId + ", eventName=" + eventName + ", sequence=" + sequence
				+ ", sourceSystem=" + sourceSystem + ", destSystem=" + destSystem + ", actionType=" + actionType + ", taskId=" + taskId + ", intfMsg="
				+ intfMsg + ", dbObject=" + dbObject + ", objectType=" + objectType + ", connectionString=" + connectionString + "]";
	}
	
}
