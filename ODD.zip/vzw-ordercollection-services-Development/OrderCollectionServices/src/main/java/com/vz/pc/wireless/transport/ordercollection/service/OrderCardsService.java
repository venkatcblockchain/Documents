package com.vz.pc.wireless.transport.ordercollection.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.vz.pc.wireless.transport.ordercollection.model.OrderCardsResponse;
import com.vz.pc.wireless.transport.ordercollection.model.UISettings;

@Service
public interface OrderCardsService {
	List<OrderCardsResponse> getOrderCardsInfo();
	List<OrderCardsResponse> getFiberOrderCardsInfo();
	
	List<UISettings> mergeUserSettings(String UserId, String orderNumber) throws Exception;	
	List<UISettings> getUserSettings(String UserId) throws Exception;

}
