package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;

public interface PcWirelessOrderRepository extends MongoRepository<PcWirelessOrder, Long> {

	public PcWirelessOrder findByOrderOrderNumber(String orderNumber);

    @Query(value="{'orderDetails.region': { '$in' : ?0} ,'orderDetails.customerDesiredDueDate': { '$lte' : ?1 , '$gte' : ?2 } }")
	public Page<PcWirelessOrder>  findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDateBetween(List<String> regions , Date custDate , Date custsDate , Pageable pageable );
    
    @Query(value="{'orderDetails.region': { '$in' : ?0} ,'orderDetails.customerDesiredDueDate': { '$lte' : ?1 , '$gte' : ?2 } }")
 	public List<PcWirelessOrder>  findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDateBetween(List<String> regions , Date custDate , Date custsDate  );
     
    @Query(value="{'orderDetails.customerDesiredDueDate': { '$lte' : ?0 , '$gte' : ?1 } }")
  	public List<PcWirelessOrder>  findByOrderDetailsCustomerDesiredDueDateBetween( Date custDate , Date custsDate  );
      
    @Query(value="{'orderDetails.region': { '$in' : ?0} ,'orderDetails.customerDesiredDueDate' : ?1 } }")
	public Page<PcWirelessOrder>  findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDate(List<String> regions ,Date custDate ,  Pageable pageable );
    
    
    @Query(value="{'orderDetails.region': { '$in' : ?0} ,'orderDetails.customerDesiredDueDate' : ?1 } }")
	public List<PcWirelessOrder>  findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDate(List<String> regions ,Date custDate );

    @Query(value="{'orderDetails.customerDesiredDueDate' : ?0 } }")
  	public List<PcWirelessOrder>  findByOrderDetailsCustomerDesiredDueDate(Date custDate );

}
