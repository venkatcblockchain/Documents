package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Arrays;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FiberOrderDetails {

	@Override
	public String toString() {
		return "FiberOrderDetails [orderType=" + orderType + ", customerDesiredDueDate=" + customerDesiredDueDate + ", customerMustHaveDueDate=" 
				+ customerMustHaveDueDate + ", projectId=" + projectId + ", region=" + region + ", domain=" + domain + ", serviceType="
				+ serviceType + ", userId=" + userId + ", segments=" + Arrays.toString(segments) + ", sites=" + Arrays.toString(sites)
				+ ", comments=" + comments + ", firstName=" + firstName + ", lastName=" + lastName + ", userEmail=" + userEmail
				 + ", userPhone=" + userPhone  + ", cktRows=" + cktRows +", siteCategory="+siteCategory+ "]";
	}

	private String orderType;
	
	private Date customerDesiredDueDate;
	
	private Date customerMustHaveDueDate;
	
	private String domain;

	private String firstName;
	
	private String lastName;
	
	private String projectId;
	
	private String region;	
	
	private String subMarket;

	private String serviceType;
	
	private String userId;
	
	private String userEmail;
	
	private String comments;
	
	private String userPhone;
	
	private String cktRows;
	
	private String numberOfCircuits;
	
	private String cranHub;
	
	private String msc;
	
	private String requestSubType;
	
	private String diversityType;
	
	private String relatedOrderNumber;
	
	private String relatedCircuitId;
	
	private String reason;

	private FiberOrderSegment segments[];
	
	private FiberOrderSite sites[];
	
	private String siteCategory;
	
	private String technologyType;
	
	public String getTechnologyType() {
		return technologyType;
	}

	public void setTechnologyType(String technologyType) {
		this.technologyType = technologyType;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}


	public Date getCustomerDesiredDueDate() {
		return customerDesiredDueDate;
	}

	public void setCustomerDesiredDueDate(Date customerDesiredDueDate) {
		this.customerDesiredDueDate = customerDesiredDueDate;
	}

	public Date getCustomerMustHaveDueDate() {
		return customerMustHaveDueDate;
	}

	public void setCustomerMustHaveDueDate(Date customerMustHaveDueDate) {
		this.customerMustHaveDueDate = customerMustHaveDueDate;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public FiberOrderSegment[] getSegments() {
		return segments;
	}

	public void setSegments(FiberOrderSegment[] segments) {
		this.segments = segments;
	}

	public FiberOrderSite[] getSites() {
		return sites;
	}

	public void setSites(FiberOrderSite[] sites) {
		this.sites = sites;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}



	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public String getCktRows() {
		return cktRows;
	}

	public void setCktRows(String cktRows) {
		this.cktRows = cktRows;
	}

	public String getNumberOfCircuits() {
		return numberOfCircuits;
	}

	public void setNumberOfCircuits(String numberOfCircuits) {
		this.numberOfCircuits = numberOfCircuits;
	}

	public String getCranHub() {
		return cranHub;
	}

	public void setCranHub(String cranHub) {
		this.cranHub = cranHub;
	}

	public String getMsc() {
		return msc;
	}

	public void setMsc(String msc) {
		this.msc = msc;
	}

	public String getRequestSubType() {
		return requestSubType;
	}

	public void setRequestSubType(String requestSubType) {
		this.requestSubType = requestSubType;
	}

	public String getDiversityType() {
		return diversityType;
	}

	public void setDiversityType(String diversityType) {
		this.diversityType = diversityType;
	}

	public String getRelatedOrderNumber() {
		return relatedOrderNumber;
	}

	public void setRelatedOrderNumber(String relatedOrderNumber) {
		this.relatedOrderNumber = relatedOrderNumber;
	}

	public String getRelatedCircuitId() {
		return relatedCircuitId;
	}

	public void setRelatedCircuitId(String relatedCircuitId) {
		this.relatedCircuitId = relatedCircuitId;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getSiteCategory() {
		return siteCategory;
	}

	public void setSiteCategory(String siteCategory) {
		this.siteCategory = siteCategory;
	}

	public String getSubMarket() {
		return subMarket;
	}

	public void setSubMarket(String subMarket) {
		this.subMarket = subMarket;
	}

}
