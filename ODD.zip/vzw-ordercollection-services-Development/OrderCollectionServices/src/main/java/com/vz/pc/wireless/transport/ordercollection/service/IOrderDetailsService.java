package com.vz.pc.wireless.transport.ordercollection.service;

import java.util.List;

import org.json.simple.JSONObject;

import com.vz.pc.wireless.transport.ordercollection.model.OrderReport;
import com.vz.pc.wireless.transport.ordercollection.model.OrderSearchRequest;
import com.vz.pc.wireless.transport.ordercollection.model.OwnershipDetails;
import com.vz.pc.wireless.transport.ordercollection.model.UIOrderDetails;

public interface IOrderDetailsService {

	UIOrderDetails getOrderDetails(String  orderNumber);

	List<UIOrderDetails> getOrderSearchData(OrderSearchRequest orderSearchRequest);

	OwnershipDetails getOwnershipDetails(String orderNumber);
	
    public List<OrderReport> getOrderTypeCount() throws Exception;
    
    public List<OrderReport> getRegionCount() throws Exception;
    
    public List<OrderReport> getOrderStatusAndDueDateCount(String regions, String statusAndDueDate) throws Exception;

	List<UIOrderDetails> getOneFiberOrderSearchData(OrderSearchRequest orderSearchRequest);

	JSONObject getSiteNFID(String siteInstId);
}

