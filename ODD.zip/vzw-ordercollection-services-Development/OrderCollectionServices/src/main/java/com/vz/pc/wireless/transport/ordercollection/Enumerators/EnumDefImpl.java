package com.vz.pc.wireless.transport.ordercollection.Enumerators;

import java.util.Enumeration;
import java.util.Vector;

public class EnumDefImpl implements EnumDef
{

  private Vector   mEnumDefTokens;
  private Object[] mValues;     // for backward compat...
  private String[] mNames;     // for backward compat...
  private String[] mAcronyms;  // ditto

  private static final EnumDefToken UNDEF=new EnumDefToken(EnumDef.INVALID, EnumDef.UNDEFINED, EnumDef.INVALIDSTR);

  public EnumDefImpl()
  {
    mEnumDefTokens = new Vector(0);
  }

  public EnumDefImpl(Vector keys, Vector names, Vector acronyms)
  {
    this();

    if(keys==null || names==null || acronyms==null ||
       keys.size() != names.size() || keys.size() != acronyms.size())
      return;

    for(int i=0; i<keys.size(); i++)
      addElement(new EnumDefToken(keys.elementAt(i),
                                  (String)names.elementAt(i),
                                  (String)acronyms.elementAt(i)));
  }

  public EnumDefImpl(Object [] keys, String [] names, String [] acronyms)
  {
    this();

    if(keys==null || names==null || acronyms==null ||
       keys.length != names.length || keys.length != acronyms.length)
      return;

    for(int i=0; i<keys.length; i++)
      addElement(new EnumDefToken(keys[i],
                                  names[i],
                                  acronyms[i]));
  }

  public EnumDefImpl(EnumDefToken[] keys)
  {
    this();

    for(int i=0; i<keys.length; i++)
      addElement(keys[i]);
  }

  public void addElement(EnumDefToken v)
  {
    // make sure the upward link is set
    v.aggregator = this;
    mEnumDefTokens.addElement(v);
  }

  public Enumeration elements()
  {
    return mEnumDefTokens.elements();
  }

  //lookup functions
  public Object[] getKeys()
  {
    if(mValues == null) {
      mValues = new Object[mEnumDefTokens.size()];
      for(int i=0; i<mEnumDefTokens.size(); i++)
        mValues[i] = ((EnumDefToken)mEnumDefTokens.elementAt(i)).value;
    }
    return mValues;
  }

  public String[] getAcronyms()
  {
    if(mAcronyms == null) {
      mAcronyms = new String[mEnumDefTokens.size()];
      for(int i=0; i<mEnumDefTokens.size(); i++)
        mAcronyms[i] = ((EnumDefToken)mEnumDefTokens.elementAt(i)).acronym;
    }
    return mAcronyms;
  }

  public String[] getNames()
  {
    if(mNames == null) {
      mNames = new String[mEnumDefTokens.size()];
      for(int i=0; i<mEnumDefTokens.size(); i++)
        mNames[i] = ((EnumDefToken)mEnumDefTokens.elementAt(i)).name;
    }
    return mNames;
  }

  public String   getAcronym(Object val)
  {
    for(int i=0; i<mEnumDefTokens.size(); i++) {
      EnumDefToken e=(EnumDefToken)mEnumDefTokens.elementAt(i);
      if(e.value.equals(val))
        return e.acronym;
    }
    return UNDEF.acronym;
  }

  public String   getAcronym(int val)
  {
    for(int i=0; i<mEnumDefTokens.size(); i++) {
      EnumDefToken e=(EnumDefToken)mEnumDefTokens.elementAt(i);
      if(e.hashCode()==val)
        return e.acronym;
    }
    return UNDEF.acronym;
  }

  public EnumDefToken getToken(Object val)
  {
    for(int i=0; i<mEnumDefTokens.size(); i++) {
      EnumDefToken e=(EnumDefToken)mEnumDefTokens.elementAt(i);
      if(e.value.equals(val))
        return e;
    }
    return UNDEF;
  }

  public String   getName(Object val)
  {
    return getToken(val).name;
  }

  public EnumDefToken getToken(int val)
  {
    for(int i=0; i<mEnumDefTokens.size(); i++) {
      EnumDefToken e=(EnumDefToken)mEnumDefTokens.elementAt(i);
      if(e.hashCode()==val)
        return e;
    }
    return UNDEF;
  }

  public String   getName(int val)
  {
    return getToken(val).name;
  }

  public Object getValueByAcronym(String acronym)
  {
    for(int i=0; i<mEnumDefTokens.size(); i++) {
      EnumDefToken e=(EnumDefToken)mEnumDefTokens.elementAt(i);
      if(e.acronym.equals(acronym))
        return e.value;
    }
    return UNDEF.value;
  }

  public int  getIntValueByAcronym(String acronym)
  {
    return getValueByAcronym(acronym).hashCode();
  }

  public Object getValueByName(String name)
  {
    for(int i=0; i<mEnumDefTokens.size(); i++) {
      EnumDefToken e=(EnumDefToken)mEnumDefTokens.elementAt(i);
      if(e.name.equals(name))
        return e.value;
    }
    return UNDEF.value;
  }

  public int  getIntValueByName(String name)
  {
    return getValueByName(name).hashCode();
  }

  public int getLength()
  {
    return mEnumDefTokens.size();
  }
}

// -EOF-

