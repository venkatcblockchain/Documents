package com.vz.pc.wireless.transport.ordercollection.model;

public class OrderCardsResponse {
	
	private String orderNumber;
	
	private int OrderSource;
	
	private String orderStatus;

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public int getOrderSource() {
		return OrderSource;
	}

	public void setOrderSource(int orderSource) {
		OrderSource = orderSource;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	
	 @Override
	  public String toString() {
	    return "OrderCardsResponse [orderNumber=" + orderNumber + ", OrderSource=" + OrderSource + ", orderStatus=" + orderStatus+ "]";
	  }

}
