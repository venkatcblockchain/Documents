package com.vz.pc.wireless.transport.ordercollection.service;

import java.util.List;
import java.util.concurrent.Future;

import org.springframework.stereotype.Service;

import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderRequest;
import com.vz.pc.wireless.transport.ordercollection.model.OrderSearchRequest;
import com.vz.pc.wireless.transport.ordercollection.model.UIOrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OneFiberOrder;

@Service
public interface FiberOrderCollectionService {

	public Future<OneFiberOrder> createFiberOrder(FiberOrderRequest fiberOrderReq);

	public UIOrderDetails getFiberOrderDetails(String  orderNumber);
}
