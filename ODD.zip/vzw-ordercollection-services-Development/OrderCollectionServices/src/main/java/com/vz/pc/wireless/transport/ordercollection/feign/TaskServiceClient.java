package com.vz.pc.wireless.transport.ordercollection.feign;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.TaskInst;

@Service
@FeignClient("taskservice")
public interface TaskServiceClient {

    @RequestMapping(method = RequestMethod.POST, value = "/service/load/task",
            produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    String create(TaskInst taskInst);
    
    
    @RequestMapping(method = RequestMethod.POST, value = "/service/update/task",
            produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    TaskInst update(TaskInst taskInst);
    
}