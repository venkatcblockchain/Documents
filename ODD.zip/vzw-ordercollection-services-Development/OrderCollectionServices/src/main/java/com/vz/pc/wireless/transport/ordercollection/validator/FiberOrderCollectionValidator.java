package com.vz.pc.wireless.transport.ordercollection.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderRequest;

@Configuration
public class FiberOrderCollectionValidator implements Validator {

	private static Logger logger = LoggerFactory.getLogger(FiberOrderCollectionValidator.class);

	//private MultiECValidator multilecValidator;

	@Override
	public boolean supports(Class<?> clazz) {

		return FiberOrderRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		FiberOrderRequest request = (FiberOrderRequest) target;
		//multilecValidator = new MultiECValidator();

		if (request == null) {
			errors.rejectValue("fiberOrderRequest", "fiberOrderRequest", "Empty request");
		}
	}

}