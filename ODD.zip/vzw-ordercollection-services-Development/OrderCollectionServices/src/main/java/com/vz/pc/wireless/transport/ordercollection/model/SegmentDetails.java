package com.vz.pc.wireless.transport.ordercollection.model;

public class SegmentDetails {
	


	private String segmentName;
	
	private String segmentId;
	
	private String cfa;
	
	private String bandwidth;
	
	private String vendor;
	
	private String icsc;
	
	private String ban;
	
	private ASiteDetails aSiteDetail;
	
	private ZSiteDetails zSiteDetail;
	
	private String ceVlan;
	
	private String ruid;
	
	
	public String getCeVlan() {
		return ceVlan;
	}

	public void setCeVlan(String ceVlan) {
		this.ceVlan = ceVlan;
	}

	public String getRuid() {
		return ruid;
	}

	public void setRuid(String ruid) {
		this.ruid = ruid;
	}

	public ASiteDetails getaSiteDetail() {
		return aSiteDetail;
	}

	public void setaSiteDetail(ASiteDetails aSiteDetail) {
		this.aSiteDetail = aSiteDetail;
	}

	public ZSiteDetails getzSiteDetail() {
		return zSiteDetail;
	}

	public void setzSiteDetail(ZSiteDetails zSiteDetail) {
		this.zSiteDetail = zSiteDetail;
	}

	public String getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(String segmentId) {
		this.segmentId = segmentId;
	}

	private String type;

	public String getSegmentName() {
		return segmentName;
	}

	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}

	public String getCfa() {
		return cfa;
	}

	public void setCfa(String cfa) {
		this.cfa = cfa;
	}

	public String getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getIcsc() {
		return icsc;
	}

	public void setIcsc(String icsc) {
		this.icsc = icsc;
	}

	public String getBan() {
		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "SegmentDetails [segmentName=" + segmentName + ", segmentId=" + segmentId + ", cfa=" + cfa + ", bandwidth=" + bandwidth + ", vendor=" + vendor
				+ ", icsc=" + icsc + ", ban=" + ban + ", aSiteDetail=" + aSiteDetail + ", zSiteDetail=" + zSiteDetail + ", type=" + type + "]";
	}
}
