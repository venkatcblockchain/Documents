package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Date;

public class RemarksResponse{
	
public String success;

public String failure;

public Date modifiedDate;


public String getSuccess() {
	return success;
}

public Date getModifiedDate() {
	return modifiedDate;
}

public void setModifiedDate(Date modifiedDate) {
	this.modifiedDate = modifiedDate;
}

public void setSuccess(String success) {
	this.success = success;
}

public String getFailure() {
	return failure;
}

public void setFailure(String failure) {
	this.failure = failure;
}

}
