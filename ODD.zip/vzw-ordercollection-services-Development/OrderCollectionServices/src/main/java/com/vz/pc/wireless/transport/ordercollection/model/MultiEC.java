package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Arrays;

public class MultiEC {
	
	private String segmentId;
	
	private String segmentName;
	
	private String BAN;
	
	private String vendorCode;
	
	private String icsc;
	
	private String type;
	
	private String cfa;

	private String NewCFA;

	private Site[] site;
	
	private String controlICSC ; 
	
	private String circuitNumber;
	
	private String mrc;
	
	private String vendorEmail ; 



	public String getSegmentId() {
		return segmentId;
	}



	public void setSegmentId(String segmentId) {
		this.segmentId = segmentId;
	}



	public String getSegmentName() {
		return segmentName;
	}



	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}



	public String getBAN() {
		return BAN;
	}



	public void setBAN(String bAN) {
		this.BAN = bAN;
	}



	public String getVendorCode() {
		return vendorCode;
	}



	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}



	


	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}





	public String getIcsc() {
		return icsc;
	}



	public void setIcsc(String icsc) {
		this.icsc = icsc;
	}



	public String getCfa() {
		return cfa;
	}



	public void setCfa(String cfa) {
		this.cfa = cfa;
	}



	public String getNewCFA() {
		return NewCFA;
	}



	public void setNewCFA(String newCFA) {
		this.NewCFA = newCFA;
	}



	public Site[] getSite() {
		return site;
	}



	public void setSite(Site[] site) {
		this.site = site;
	}



	public String getControlICSC() {
		return controlICSC;
	}



	public void setControlICSC(String controlICSC) {
		this.controlICSC = controlICSC;
	}



	public String getCircuitNumber() {
		return circuitNumber;
	}



	public void setCircuitNumber(String circuitNumber) {
		this.circuitNumber = circuitNumber;
	}



	public String getMrc() {
		return mrc;
	}



	public void setMrc(String mrc) {
		this.mrc = mrc;
	}



	public String getVendorEmail() {
		return vendorEmail;
	}



	public void setVendorEmail(String vendorEmail) {
		this.vendorEmail = vendorEmail;
	}



	@Override
	public String toString() {
		return "MultiEC [segmentId=" + segmentId + ", segmentName=" + segmentName + ", BAN=" + BAN + ", vendorCode=" + vendorCode + ", icsc=" + icsc + ", type="
				+ type + ", cfa=" + cfa + ", NewCFA=" + NewCFA + ", site=" + Arrays.toString(site) + ", controlICSC=" + controlICSC + ", circuitNumber="
				+ circuitNumber + ", mrc=" + mrc + ", vendorEmail=" + vendorEmail + "]";
	}





	
}
