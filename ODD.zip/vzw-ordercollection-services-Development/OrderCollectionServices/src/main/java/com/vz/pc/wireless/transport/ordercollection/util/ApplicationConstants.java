package com.vz.pc.wireless.transport.ordercollection.util;

public interface ApplicationConstants {
	
	String CELL_SITE_TYPE_MICRO = "Micro";
	
	String CELL_SITE_TYPE_MACRO = "Macro";
	
	String CELL_SITE_TYPE_MICRO_5G = "Small Cell+5G";
	
	String CELL_SITE_TYPE_MACRO_5G = "Macro Cell+5G";
}
