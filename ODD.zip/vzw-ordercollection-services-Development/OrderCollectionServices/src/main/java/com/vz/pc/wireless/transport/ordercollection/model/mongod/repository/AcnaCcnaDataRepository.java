package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
/*import org.springframework.security.access.prepost.PreAuthorize;
*/
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.AcnaCcnaData;

public interface AcnaCcnaDataRepository extends MongoRepository<AcnaCcnaData, String> {

	/*  @PreAuthorize("hasRole('ROLE_ADMIN')")*/
	  //@Query(value="{ bandwidth: { '$elemMatch': {name: 0 } } }", fields="{ 'bandwidth.$' : 1 , '_id': 0}")
	  @Query(value= "{ 'bandwidth': { $elemMatch: { 'name' :  ?0 } } }" ,  fields="{ 'bandwidth.$' : 1 , '_id': 0}")
	  public AcnaCcnaData findByBandwidthName(String name);
	  @Query(value= "{ 'regions': { $elemMatch: { 'name' :  ?0 } } }" ,  fields="{ 'regions.$' : 1 , '_id': 0}")
	  public AcnaCcnaData findByRegionsName(String name);
}
