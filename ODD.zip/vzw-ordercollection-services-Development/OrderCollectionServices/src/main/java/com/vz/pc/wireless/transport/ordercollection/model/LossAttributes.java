package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Date;

public class LossAttributes {

	
	private String circuitId;
	
	private String opticalLength;

	private Date dateRecorded;
	
	private FiberTestResultLocation aEnd;
	
	private FiberTestResultLocation zEnd;

	public String getCircuitId() {
		return circuitId;
	}

	public void setCircuitId(String circuitId) {
		this.circuitId = circuitId;
	}

	public String getOpticalLength() {
		return opticalLength;
	}

	public void setOpticalLength(String opticalLength) {
		this.opticalLength = opticalLength;
	}

	public FiberTestResultLocation getaEnd() {
		return aEnd;
	}

	public void setaEnd(FiberTestResultLocation aEnd) {
		this.aEnd = aEnd;
	}

	public FiberTestResultLocation getzEnd() {
		return zEnd;
	}

	public void setzEnd(FiberTestResultLocation zEnd) {
		this.zEnd = zEnd;
	}

	public Date getDateRecorded() {
		return dateRecorded;
	}

	public void setDateRecorded(Date dateRecorded) {
		this.dateRecorded = dateRecorded;
	}

	@Override
	public String toString() {
		return "LossAttributes [circuitId=" + circuitId + ", opticalLength=" + opticalLength + ", aEnd=" + aEnd
				+ ", zEnd=" + zEnd + ", dateRecorded=" + dateRecorded + "]";
	}

	
}
