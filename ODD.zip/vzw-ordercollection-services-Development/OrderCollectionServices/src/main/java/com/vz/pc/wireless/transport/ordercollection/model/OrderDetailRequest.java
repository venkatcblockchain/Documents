package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.List;

public class OrderDetailRequest {
	
	String dateOne;	
	String dateRadios;	
	String dateRange;	
	String formSubmitFlag;	
	String reportType;
	String dateTwo;
	List<String> region;
	
	int page;	
	String qtype;	
	String query;	
	int rp;
	String sortname;	
	String sortorder;	
	String vzid;
	
	
	public String getDateTwo() {
		return dateTwo;
	}
	public List<String> getRegion() {
		return region;
	}
	public void setRegion(List<String> region) {
		this.region = region;
	}
	public void setDateTwo(String dateTwo) {
		this.dateTwo = dateTwo;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getDateOne() {
		return dateOne;
	}
	public void setDateOne(String dateOne) {
		this.dateOne = dateOne;
	}
	public String getDateRadios() {
		return dateRadios;
	}
	public void setDateRadios(String dateRadios) {
		this.dateRadios = dateRadios;
	}

	public String getDateRange() {
		return dateRange;
	}
	public void setDateRange(String dateRange) {
		this.dateRange = dateRange;
	}
	public String getFormSubmitFlag() {
		return formSubmitFlag;
	}
	public void setFormSubmitFlag(String formSubmitFlag) {
		this.formSubmitFlag = formSubmitFlag;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public String getQtype() {
		return qtype;
	}
	public void setQtype(String qtype) {
		this.qtype = qtype;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public int getRp() {
		return rp;
	}
	public void setRp(int rp) {
		this.rp = rp;
	}
	public String getSortname() {
		return sortname;
	}
	public void setSortname(String sortname) {
		this.sortname = sortname;
	}
	public String getSortorder() {
		return sortorder;
	}
	public void setSortorder(String sortorder) {
		this.sortorder = sortorder;
	}
	public String getVzid() {
		return vzid;
	}
	public void setVzid(String vzid) {
		this.vzid = vzid;
	}	

}
