package com.vz.pc.wireless.transport.ordercollection.model.mongod.collection;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.vz.pc.wireless.transport.ordercollection.model.ClrSegments;
import com.vz.pc.wireless.transport.ordercollection.model.LossAttributes;
/**
 * 
 * @author PEACJA7
 *
 */
@Document(collection = "coemilestone")
public class CoEMilestone {

	@Id
	private long id;
	
	private String orderNumber;
	
	private String nfid;

	private String statusCode;
	
	private String statusMsg;
	
	private String orderVersion;
	
	private Date createdTime;

	private Date sentDate;
	
	private Date focReceivedDate;
	
	private Date focDate;
	
	private Date facilityCheckDate;
	
	private Date cktIdCreatedNotifDate;
	
	private Date inEffectNotifDate;
	
	private boolean segmentsCreated;
	
	private boolean notifyGraniteRequired;
	
	private ClrSegments[] clrSegments;
	
	private LossAttributes[] lossAttributes;
	
	private String suppType;

	public Date getCktIdCreatedNotifDate() {
		return cktIdCreatedNotifDate;
	}

	public void setCktIdCreatedNotifDate(Date cktIdCreatedNotifDate) {
		this.cktIdCreatedNotifDate = cktIdCreatedNotifDate;
	}

	public Date getInEffectNotifDate() {
		return inEffectNotifDate;
	}

	public void setInEffectNotifDate(Date inEffectNotifDate) {
		this.inEffectNotifDate = inEffectNotifDate;
	}

	public String getNfid() {
		return nfid;
	}

	public void setNfid(String nfid) {
		this.nfid = nfid;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMsg() {
		return statusMsg;
	}

	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getOrderVersion() {
		return orderVersion;
	}

	public void setOrderVersion(String orderVersion) {
		this.orderVersion = orderVersion;
	}
	
	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	public Date getFacilityCheckDate() {
		return facilityCheckDate;
	}

	public void setFacilityCheckDate(Date facilityCheckDate) {
		this.facilityCheckDate = facilityCheckDate;
	}

	public Date getFocReceivedDate() {
		return focReceivedDate;
	}

	public void setFocReceivedDate(Date focReceivedDate) {
		this.focReceivedDate = focReceivedDate;
	}

	public boolean isSegmentsCreated() {
		return segmentsCreated;
	}

	public void setSegmentsCreated(boolean segmentsCreated) {
		this.segmentsCreated = segmentsCreated;
	}

	public boolean isNotifyGraniteRequired() {
		return notifyGraniteRequired;
	}

	public void setNotifyGraniteRequired(boolean notifyGraniteRequired) {
		this.notifyGraniteRequired = notifyGraniteRequired;
	}

	public ClrSegments[] getClrSegments() {
		return clrSegments;
	}

	public void setClrSegments(ClrSegments[] clrSegments) {
		this.clrSegments = clrSegments;
	}

	public String getSuppType() {
		return suppType;
	}

	public void setSuppType(String suppType) {
		this.suppType = suppType;
	}

	public LossAttributes[] getLossAttributes() {
		return lossAttributes;
	}

	public void setLossAttributes(LossAttributes[] lossAttributes) {
		this.lossAttributes = lossAttributes;
	}

	public Date getFocDate() {
		return focDate;
	}

	public void setFocDate(Date focDate) {
		this.focDate = focDate;
	}

	@Override
	public String toString() {
		return "CoEMilestone [id=" + id + ", orderNumber=" + orderNumber + ", nfid=" + nfid + ", statusCode="
				+ statusCode + ", statusMsg=" + statusMsg + ", orderVersion=" + orderVersion + ", createdTime="
				+ createdTime + ", sentDate=" + sentDate + ", focReceivedDate=" + focReceivedDate
				+ ", facilityCheckDate=" + facilityCheckDate + ", cktIdCreatedNotifDate=" + cktIdCreatedNotifDate
				+ ", inEffectNotifDate=" + inEffectNotifDate + ", segmentsCreated=" + segmentsCreated
				+ ", notifyGraniteRequired=" + notifyGraniteRequired + "]";
	}

}
