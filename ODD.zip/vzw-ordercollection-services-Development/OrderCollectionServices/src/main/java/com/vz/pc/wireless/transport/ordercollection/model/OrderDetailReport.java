package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Date;

public class OrderDetailReport {
	
	String REGION;
	
	String ORDERNUMBER;
	
	String ORDERTYPE;
	
	String ORDERSTATUS;

	public OrderDetailReport(String rEGION, String oRDERNUMBER, String oRDERTYPE, String oRDERSTATUS, String sITENAME,
			String tSPCODE, String sEGMENTNAME, String sEGMENTINSTAID, String bANDWIDTH, String mRC, String pON,
			String pONVERSION, String pRODUCT, String pROJECT, String iCSC, String vENDORCODE, Date cREATEDATE,
			Date dESIREDDUEDATE, Date sENTDATE, String lECORDERNUMBER, String cCNA, Date lECDUEDATE,
			Date aCKRECEIVEDDATE, Date fOCRECEIVEDDATE, Date fOCDUEDATE, String vZID, String fIRSTNAME,
			String lASTNAME) {
		REGION = rEGION;
		ORDERNUMBER = oRDERNUMBER;
		ORDERTYPE = oRDERTYPE;
		ORDERSTATUS = oRDERSTATUS;
		SITENAME = sITENAME;
		TSPCODE = tSPCODE;
		SEGMENTNAME = sEGMENTNAME;
		SEGMENTINSTAID = sEGMENTINSTAID;
		BANDWIDTH = bANDWIDTH;
		MRC = mRC;
		PON = pON;
		PONVERSION = pONVERSION;
		PRODUCT = pRODUCT;
		PROJECT = pROJECT;
		ICSC = iCSC;
		VENDORCODE = vENDORCODE;
		CREATEDATE = cREATEDATE;
		DESIREDDUEDATE = dESIREDDUEDATE;
		SENTDATE = sENTDATE;
		LECORDERNUMBER = lECORDERNUMBER;
		CCNA = cCNA;
		LECDUEDATE = lECDUEDATE;
		ACKRECEIVEDDATE = aCKRECEIVEDDATE;
		FOCRECEIVEDDATE = fOCRECEIVEDDATE;
		FOCDUEDATE = fOCDUEDATE;
		VZID = vZID;
		FIRSTNAME = fIRSTNAME;
		LASTNAME = lASTNAME;
	}

	@Override
	public String toString() {
		return "OrderDetailReport [REGION=" + REGION + ", ORDERNUMBER=" + ORDERNUMBER + ", ORDERTYPE=" + ORDERTYPE
				+ ", ORDERSTATUS=" + ORDERSTATUS + ", SITENAME=" + SITENAME + ", TSPCODE=" + TSPCODE + ", SEGMENTNAME="
				+ SEGMENTNAME + ", SEGMENTINSTAID=" + SEGMENTINSTAID + ", BANDWIDTH=" + BANDWIDTH + ", MRC=" + MRC
				+ ", PON=" + PON + ", PONVERSION=" + PONVERSION + ", PRODUCT=" + PRODUCT + ", PROJECT=" + PROJECT
				+ ", ICSC=" + ICSC + ", VENDORCODE=" + VENDORCODE + ", CREATEDATE=" + CREATEDATE + ", DESIREDDUEDATE="
				+ DESIREDDUEDATE + ", SENTDATE=" + SENTDATE + ", LECORDERNUMBER=" + LECORDERNUMBER + ", CCNA=" + CCNA
				+ ", LECDUEDATE=" + LECDUEDATE + ", ACKRECEIVEDDATE=" + ACKRECEIVEDDATE + ", FOCRECEIVEDDATE="
				+ FOCRECEIVEDDATE + ", FOCDUEDATE=" + FOCDUEDATE + ", VZID=" + VZID + ", FIRSTNAME=" + FIRSTNAME
				+ ", LASTNAME=" + LASTNAME + "]";
	}

	public String getREGION() {
		return REGION;
	}

	public void setREGION(String rEGION) {
		REGION = rEGION;
	}

	public String getORDERNUMBER() {
		return ORDERNUMBER;
	}

	public void setORDERNUMBER(String oRDERNUMBER) {
		ORDERNUMBER = oRDERNUMBER;
	}

	public String getORDERTYPE() {
		return ORDERTYPE;
	}

	public void setORDERTYPE(String oRDERTYPE) {
		ORDERTYPE = oRDERTYPE;
	}

	public String getORDERSTATUS() {
		return ORDERSTATUS;
	}

	public void setORDERSTATUS(String oRDERSTATUS) {
		ORDERSTATUS = oRDERSTATUS;
	}

	public String getSITENAME() {
		return SITENAME;
	}

	public void setSITENAME(String sITENAME) {
		SITENAME = sITENAME;
	}

	public String getTSPCODE() {
		return TSPCODE;
	}

	public void setTSPCODE(String tSPCODE) {
		TSPCODE = tSPCODE;
	}

	public String getSEGMENTNAME() {
		return SEGMENTNAME;
	}

	public void setSEGMENTNAME(String sEGMENTNAME) {
		SEGMENTNAME = sEGMENTNAME;
	}

	public String getSEGMENTINSTAID() {
		return SEGMENTINSTAID;
	}

	public void setSEGMENTINSTAID(String sEGMENTINSTAID) {
		SEGMENTINSTAID = sEGMENTINSTAID;
	}

	public String getBANDWIDTH() {
		return BANDWIDTH;
	}

	public void setBANDWIDTH(String bANDWIDTH) {
		BANDWIDTH = bANDWIDTH;
	}

	public String getMRC() {
		return MRC;
	}

	public void setMRC(String mRC) {
		MRC = mRC;
	}

	public String getPON() {
		return PON;
	}

	public void setPON(String pON) {
		PON = pON;
	}

	public String getPONVERSION() {
		return PONVERSION;
	}

	public void setPONVERSION(String pONVERSION) {
		PONVERSION = pONVERSION;
	}

	public String getPRODUCT() {
		return PRODUCT;
	}

	public void setPRODUCT(String pRODUCT) {
		PRODUCT = pRODUCT;
	}

	public String getPROJECT() {
		return PROJECT;
	}

	public void setPROJECT(String pROJECT) {
		PROJECT = pROJECT;
	}

	public String getICSC() {
		return ICSC;
	}

	public void setICSC(String iCSC) {
		ICSC = iCSC;
	}

	public String getVENDORCODE() {
		return VENDORCODE;
	}

	public void setVENDORCODE(String vENDORCODE) {
		VENDORCODE = vENDORCODE;
	}

	public Date getCREATEDATE() {
		return CREATEDATE;
	}

	public void setCREATEDATE(Date cREATEDATE) {
		CREATEDATE = cREATEDATE;
	}

	public Date getDESIREDDUEDATE() {
		return DESIREDDUEDATE;
	}

	public void setDESIREDDUEDATE(Date dESIREDDUEDATE) {
		DESIREDDUEDATE = dESIREDDUEDATE;
	}

	public Date getSENTDATE() {
		return SENTDATE;
	}

	public void setSENTDATE(Date sENTDATE) {
		SENTDATE = sENTDATE;
	}

	public String getLECORDERNUMBER() {
		return LECORDERNUMBER;
	}

	public void setLECORDERNUMBER(String lECORDERNUMBER) {
		LECORDERNUMBER = lECORDERNUMBER;
	}

	public String getCCNA() {
		return CCNA;
	}

	public void setCCNA(String cCNA) {
		CCNA = cCNA;
	}

	public Date getLECDUEDATE() {
		return LECDUEDATE;
	}

	public void setLECDUEDATE(Date lECDUEDATE) {
		LECDUEDATE = lECDUEDATE;
	}

	public Date getACKRECEIVEDDATE() {
		return ACKRECEIVEDDATE;
	}

	public void setACKRECEIVEDDATE(Date aCKRECEIVEDDATE) {
		ACKRECEIVEDDATE = aCKRECEIVEDDATE;
	}

	public Date getFOCRECEIVEDDATE() {
		return FOCRECEIVEDDATE;
	}

	public void setFOCRECEIVEDDATE(Date fOCRECEIVEDDATE) {
		FOCRECEIVEDDATE = fOCRECEIVEDDATE;
	}

	public Date getFOCDUEDATE() {
		return FOCDUEDATE;
	}

	public void setFOCDUEDATE(Date fOCDUEDATE) {
		FOCDUEDATE = fOCDUEDATE;
	}

	public String getVZID() {
		return VZID;
	}

	public void setVZID(String vZID) {
		VZID = vZID;
	}

	public String getFIRSTNAME() {
		return FIRSTNAME;
	}

	public void setFIRSTNAME(String fIRSTNAME) {
		FIRSTNAME = fIRSTNAME;
	}

	public String getLASTNAME() {
		return LASTNAME;
	}

	public void setLASTNAME(String lASTNAME) {
		LASTNAME = lASTNAME;
	}

	String SITENAME;
	
	String TSPCODE;

	String SEGMENTNAME;
	
	String SEGMENTINSTAID;
	
	String BANDWIDTH;
	
	String MRC;

	String PON;

	String PONVERSION;
	
	String PRODUCT;
	
	String PROJECT;
	
	String ICSC;
	
	String VENDORCODE;
	
	Date CREATEDATE;
	
	Date DESIREDDUEDATE;
	
	Date SENTDATE;
	
	String LECORDERNUMBER;
	
	String CCNA;
	
	Date LECDUEDATE;
	
	Date ACKRECEIVEDDATE;
	
	Date FOCRECEIVEDDATE;
	
	Date FOCDUEDATE;
	
	String VZID;
	
	String FIRSTNAME;
	
	String LASTNAME;
	


}
