package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.EventAudit;

public interface EventAuditRepository  extends MongoRepository<EventAudit, String>{

	public EventAudit findByOrderNumber(String orderNumber);
	
	
}
