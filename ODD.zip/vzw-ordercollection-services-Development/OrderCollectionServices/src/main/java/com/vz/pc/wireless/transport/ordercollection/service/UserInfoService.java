package com.vz.pc.wireless.transport.ordercollection.service;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;

import com.vz.pc.wireless.transport.ordercollection.model.User;

@Service("userInfoService")
@Scope(value = "request", proxyMode = ScopedProxyMode.INTERFACES)
public interface UserInfoService {

	  public void setUserInfo(User user);
	  
	  public User getUserInfo();
	  
}
