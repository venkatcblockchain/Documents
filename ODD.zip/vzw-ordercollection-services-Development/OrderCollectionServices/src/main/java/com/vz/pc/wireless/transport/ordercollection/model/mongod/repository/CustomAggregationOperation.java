package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperationContext;

import com.mongodb.DBObject;

public class CustomAggregationOperation  implements AggregationOperation {
	  
	private DBObject operation;
	  
	  public CustomAggregationOperation (DBObject operation) {
	        this.operation = operation;
	    }
	  
	@Override
	public DBObject toDBObject(AggregationOperationContext arg0) {
		// TODO Auto-generated method stub
		return arg0.getMappedObject(operation);
	}

}
