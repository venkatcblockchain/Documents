package com.vz.pc.wireless.transport.ordercollection.model;

public class FiberOrderRequest {
	
	//Order level Info
	private String requestType;

	private String source;
	
	private String requestSubType;
	
	private String diversityType;
	
	private String relatedOrderNumber;
	
	private String relatedCircuitId;
	
	private String orderType;

	private String requestedDate;
	
	private String region;
	
	private String subMarket;
	
	private String market;
	
	private String projectId;
	
	private String circuitNumber;
	
	private String mustHaveDate;
	
	//	private String segmentID;
		
	//	private String ban;
	
	private String bandWidth;
	
	private String strands;
	
	private String connectionPoint;
	
	private String distance;
	
    private String loss;
	
	private String comments;
	
	private String name;
	
	private String phone;
	
	private String userEmail;
	
	private String userId;
	
	private String cranHub;
	
	private String msc;
	
	private String vendor;
	
	private String segmentName;
	
	private String segmentId;
	
	private String disconnectReason;
	
	private FiberOrderSite siteA;
	
	private FiberOrderSite siteZ;

	private String siteCategory;
	
	private String technologyType;
	
	public String getTechnologyType() {
		return technologyType;
	}

	public void setTechnologyType(String technologyType) {
		this.technologyType = technologyType;
	}

	public String getRequestSubType() {
		return requestSubType;
	}

	public void setRequestSubType(String requestSubType) {
		this.requestSubType = requestSubType;
	}

	public String getDiversityType() {
		return diversityType;
	}

	public void setDiversityType(String diversityType) {
		this.diversityType = diversityType;
	}

	public String getRelatedOrderNumber() {
		return relatedOrderNumber;
	}

	public void setRelatedOrderNumber(String relatedOrderNumber) {
		this.relatedOrderNumber = relatedOrderNumber;
	}

	public String getRelatedCircuitId() {
		return relatedCircuitId;
	}

	public void setRelatedCircuitId(String relatedCircuitId) {
		this.relatedCircuitId = relatedCircuitId;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getBandWidth() {
		return bandWidth;
	}

	public void setBandWidth(String bandWidth) {
		this.bandWidth = bandWidth;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}



	public String getRequestedDate() {
		return requestedDate;
	}

	public void setRequestedDate(String requestedDate) {
		this.requestedDate = requestedDate;
	}

	public String getMustHaveDate() {
		return mustHaveDate;
	}

	public void setMustHaveDate(String mustHaveDate) {
		this.mustHaveDate = mustHaveDate;
	}

	public String getStrands() {
		return strands;
	}

	public void setStrands(String strands) {
		this.strands = strands;
	}

	public String getConnectionPoint() {
		return connectionPoint;
	}

	public void setConnectionPoint(String connectionPoint) {
		this.connectionPoint = connectionPoint;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getLoss() {
		return loss;
	}

	public void setLoss(String loss) {
		this.loss = loss;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public FiberOrderSite getSiteA() {
		return siteA;
	}

	public void setSiteA(FiberOrderSite siteA) {
		this.siteA = siteA;
	}

	public FiberOrderSite getSiteZ() {
		return siteZ;
	}

	public void setSiteZ(FiberOrderSite siteZ) {
		this.siteZ = siteZ;
	}

	public String getCircuitNumber() {
		return circuitNumber;
	}

	public void setCircuitNumber(String circuitNumber) {
		this.circuitNumber = circuitNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCranHub() {
		return cranHub;
	}

	public void setCranHub(String cranHub) {
		this.cranHub = cranHub;
	}

	public String getMsc() {
		return msc;
	}

	public void setMsc(String msc) {
		this.msc = msc;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getSegmentName() {
		return segmentName;
	}

	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}

	public String getDisconnectReason() {
		return disconnectReason;
	}

	public void setDisconnectReason(String disconnectReason) {
		this.disconnectReason = disconnectReason;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(String segmentId) {
		this.segmentId = segmentId;
	}

	@Override
	public String toString() {
		return "PcOrderRequest [requestType=" + requestType + ", orderType=" + orderType + ", requestedDate=" + requestedDate + ", msc=" + msc
				+ ", projectId=" + projectId + ", region=" + region + ", mustHaveDate=" + mustHaveDate + ", bandWidth=" + ", cranHub=" + cranHub 
				+ bandWidth + ", strands=" + strands + ", connectionPoint=" + connectionPoint + ", circuitNumber=" + circuitNumber
				+ ", distance=" + distance + ", loss=" + loss + ", comments=" + comments + ", name=" + name + ", userId=" + userId + ", vendor=" + vendor
				+ ", phone=" + phone + ", userEmail=" + userEmail + ", siteA details=" + siteA + ", siteZ details=" + siteZ 
				+ ", segmentName=" + segmentName +  ", subMarket=" + subMarket +", source=" + source + ", disconnectReason=" + disconnectReason + ", segmentId=" + segmentId +  ", siteCategory=" + siteCategory +"]";
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getSiteCategory() {
		return siteCategory;
	}

	public void setSiteCategory(String siteCategory) {
		this.siteCategory = siteCategory;
	}

	public String getSubMarket() {
		return subMarket;
	}

	public void setSubMarket(String subMarket) {
		this.subMarket = subMarket;
	}
}
