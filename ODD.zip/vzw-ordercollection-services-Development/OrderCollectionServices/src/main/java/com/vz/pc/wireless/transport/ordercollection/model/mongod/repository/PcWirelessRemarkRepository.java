package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessRemark;

public interface PcWirelessRemarkRepository extends MongoRepository<PcWirelessRemark, Long> {
	
	public PcWirelessRemark findByremarksIdAndPcOrderId(Long remarksId,Long pcOrderId);
	
	public List<PcWirelessRemark> findByPcOrderId(Long pcOrderId);
	
	public List<PcWirelessRemark> findByFiberOrderNumber(Long fiberOrderNumber);

}
