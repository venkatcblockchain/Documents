package com.vz.pc.wireless.transport.ordercollection.service;

import org.springframework.stereotype.Service;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;

@Service
public interface GroovyRuleEngine {

	public Object execute( Object obj , Object obj1);

}
