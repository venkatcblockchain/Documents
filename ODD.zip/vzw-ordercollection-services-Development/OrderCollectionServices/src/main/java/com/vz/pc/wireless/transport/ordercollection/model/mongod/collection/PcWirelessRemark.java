package com.vz.pc.wireless.transport.ordercollection.model.mongod.collection;

import java.util.Date;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "pcWirelessRemark")
public class PcWirelessRemark {
	

	@Id
	private Long NotesRemarksId;
	private Long RemarksId;
	private Long pcOrderId;
	private Long fiberOrderNumber;
	private String NotesRemarksText;
	private String modifiedBy;
	public Long getRemarksId() {
		return RemarksId;
	}
	public void setRemarksId(Long remarksId) {
		RemarksId = remarksId;
	}
	private Date modifiedDate;
	private String taskName;
	private String strikeFlag;
	public Long getNotesRemarksId() {
		return NotesRemarksId;
	}
	public void setNotesRemarksId(Long notesRemarksId) {
		NotesRemarksId = notesRemarksId;
	}
	public Long getPcOrderId() {
		return pcOrderId;
	}
	public void setPcOrderId(Long pcOrderId) {
		this.pcOrderId = pcOrderId;
	}
	public String getNotesRemarksText() {
		return NotesRemarksText;
	}
	public void setNotesRemarksText(String notesRemarksText) {
		NotesRemarksText = notesRemarksText;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getStrikeFlag() {
		return strikeFlag;
	}
	public void setStrikeFlag(String strikeFlag) {
		this.strikeFlag = strikeFlag;
	}

	public Long getFiberOrderNumber() {
		return fiberOrderNumber;
	}

	public void setFiberOrderNumber(Long fiberOrderNumber) {
		this.fiberOrderNumber = fiberOrderNumber;
	}
}
