package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OutEventStore;


public interface OutEventStoreRepository  extends MongoRepository<com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OutEventStore,Long>{

	public	List<OutEventStore> findByPcOrderId(long pcOrderId);

	public OutEventStore findById(long Id);

}
