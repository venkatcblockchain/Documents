package com.vz.pc.wireless.transport.ordercollection.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.vz.pc.wireless.transport.ordercollection.Enumerators.PcCEnum;
import com.vz.pc.wireless.transport.ordercollection.config.SwaggerConfig;
import com.vz.pc.wireless.transport.ordercollection.model.OrderCardsResponse;
import com.vz.pc.wireless.transport.ordercollection.model.UISettings;
import com.vz.pc.wireless.transport.ordercollection.model.User;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.UISettingsRepository;
import com.vz.pc.wireless.transport.ordercollection.service.OrderCardsService;
import com.vz.pc.wireless.transport.ordercollection.service.UserInfoService;

@Component("OrderCardsService")
@EnableAutoConfiguration(exclude = { SwaggerConfig.class })
@Transactional
public class OrderCardsServiceImpl implements OrderCardsService {

	private static Logger logger = LoggerFactory.getLogger(OrderCardsServiceImpl.class);

	@Autowired
	private MongoOperations mongo;
	
	@Autowired
	UserInfoService userInfoService;
	
	@Autowired
	UISettingsRepository uiSettingsRepository;


	@Async
	@Override
	public List<OrderCardsResponse> getOrderCardsInfo() {

		logger.debug("Order Cards Service is Initiated .");
		List<OrderCardsResponse> OrderNumberList = new ArrayList<OrderCardsResponse>();
		try {
			DBCollection collection = mongo.getCollection("pcWirelessOrder");
			DBCursor cursorDoc = collection.find();
			while (cursorDoc.hasNext()) {
				BasicDBObject orderObj = queryOrderObj(cursorDoc);
				if (orderObj != null) {
					OrderNumberList.add(getOrderNumberObject(orderObj));
				}
			}
		}

		catch (Exception e) {
			e.printStackTrace();
			logger.info("Order Cards List Generation failed due to error["+e+"]");
			throw e;
		}

		logger.info("Order Cards List Generated ");
		return OrderNumberList;
	}

	@Async
	@Override
	public List<OrderCardsResponse> getFiberOrderCardsInfo() {

		logger.debug("Fiber Order Cards Service is Initiated .");
		List<OrderCardsResponse> OrderNumberList = new ArrayList<OrderCardsResponse>();
		try {
			DBCollection collection = mongo.getCollection("oneFiberOrder");
			DBCursor cursorDoc = collection.find();
			while (cursorDoc.hasNext()) {
				BasicDBObject orderObj = queryOrderObj(cursorDoc);
				if (orderObj != null) {
					OrderNumberList.add(getOrderNumberObject(orderObj));
				}
			}
		}

		catch (Exception e) {
			e.printStackTrace();
			logger.info("Fiber Order Cards List Generation failed due to error["+e+"]");
			throw e;
		}

		logger.info("Fiber Order Cards List Generated ");
		return OrderNumberList;
	}

	@Async
	private OrderCardsResponse getOrderNumberObject(BasicDBObject orderObj) {

		OrderCardsResponse orderCardsResponse = new OrderCardsResponse();
		String orderStatus = null;
		String orderNumber = "";
		int orderSource = 0;
		logger.info("Individual Order Number Being Fetched");
		
        try{
		orderStatus = (String) orderObj.get("orderStatus");
		orderNumber = (String) orderObj.get("orderNumber");
		orderSource = (Integer) orderObj.get("orderSource");

		logger.info("Order Number [" + orderNumber.toString() + "] is being added to list");
		orderStatus = getOrderStatus(orderObj,orderNumber,orderStatus);
	
		orderCardsResponse.setOrderNumber(orderNumber);
		orderCardsResponse.setOrderStatus(orderStatus);
		orderCardsResponse.setOrderSource(orderSource);
        }
        catch(Exception e){
        	e.printStackTrace();
        	logger.info("Order Card Obj for Order Number["+orderNumber+"] Response is failed");
        	throw e;
        }
        logger.info("Order Card Obj :"+orderCardsResponse+" Response returned");
		return orderCardsResponse;
	}

	@Async
	private BasicDBObject queryOrderObj(DBCursor cursorDoc) {

		logger.info("Order Obj fetching from mongoDB Initiated");
		BasicDBObject orderObj = null;
		BasicDBObject result = null;
		try {
			result = (BasicDBObject) cursorDoc.next();
			orderObj = (BasicDBObject) result.get("order");
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Order Obj fetched from mongoDB is failed");
			throw e;
		}
		logger.info("Order Obj fetched from mongoDB Successfull");
		return orderObj;

	}
	
	@Async
	private String getOrderStatus(BasicDBObject orderObj,String orderNumber,String orderStatus){
		int orderStatusEnum = 0;
		logger.info("Order Obj Status Being Fetched for OrderNumber["+orderNumber+"]");
		try{
		orderStatusEnum = PcCEnum.OrderStatus.getValueBygetFieldName(orderStatus);
		orderStatus = PcCEnum.OrderStatus.name(orderStatusEnum);
		orderObj.replace("orderStatus", orderStatus);

		orderStatus = (String) orderObj.get("orderStatus");
		}
		catch(Exception e){
			e.printStackTrace();
			logger.info("Order Obj Status for OrderNumber["+orderNumber+"] is failed");
			throw e;
		}
		logger.info("Order Obj Status is ["+orderStatus+"] for OrderNumber["+orderNumber+"]");
		return orderStatus;		
	}

	@Override
	public  List<UISettings> mergeUserSettings(String UserId, String orderNumber) throws Exception {
		
		User user = userInfoService.getUserInfo();

		ArrayList<String> ordersCards = null;
		UISettings uiSetting =	uiSettingsRepository.findByUserIdAndObjectName(user.getUserId().toUpperCase(), "Order-Cards-Cache");
		//** UI Settings for that user already exists **//*
		if(Optional.ofNullable(uiSetting).isPresent() && Optional.ofNullable(uiSetting.getOrderCards()).isPresent()){

			ordersCards = uiSetting.getOrderCards();
			logger.info(	"REGULATORY-SERVICE :uiSetting.getOrderCards()  {}  " , ordersCards);

		} else {
			ordersCards = new ArrayList<String>();
			uiSetting = new UISettings();
		}

		if (null != ordersCards && !ordersCards.contains(orderNumber)) {
			ordersCards.add(orderNumber);
			uiSetting.setUserId(user.getUserId().toUpperCase());
			uiSetting.setObjectName("Order-Cards-Cache");
			uiSetting.setOrderCards(ordersCards);
			uiSettingsRepository.save(uiSetting);
		}
		
		return uiSettingsRepository.findByUserId(user.getUserId().toUpperCase());
	}

	@Override
	public List<UISettings> getUserSettings(String UserId) throws Exception {
		
		return uiSettingsRepository.findByUserId(UserId.toUpperCase());
	}

}
