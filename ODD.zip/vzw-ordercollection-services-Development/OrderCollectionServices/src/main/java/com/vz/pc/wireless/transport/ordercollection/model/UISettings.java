package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.ArrayList;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "UISettings")
@CompoundIndexes({
    @CompoundIndex(name = "uisettingscompindex", def = "{'userId' : 1, 'objectName' : 1}")
})
public class UISettings  {
	@Id
	private String id;

	private String userId;
    private String objectName;
    private ArrayList<String> orderCards;

	public String getObjectName() {
		return objectName;
	}
	public ArrayList<String> getOrderCards() {
		return orderCards;
	}
	public String getUserId() {
		return userId;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	public void setOrderCards(ArrayList<String> orderCards) {
		this.orderCards = orderCards;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("UISetting [userId=");
		builder.append(userId);
		builder.append(", objectName=");
		builder.append(objectName);
		builder.append(", orderCards=");
		builder.append(orderCards);
		builder.append("]");
		return builder.toString();
	}

}
