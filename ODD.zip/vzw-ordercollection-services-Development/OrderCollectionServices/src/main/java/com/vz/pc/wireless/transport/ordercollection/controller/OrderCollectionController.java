package com.vz.pc.wireless.transport.ordercollection.controller;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jettison.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vz.pc.wireless.transport.ordercollection.exception.DataNotFoundException;
import com.vz.pc.wireless.transport.ordercollection.feign.TaskServiceClient;
import com.vz.pc.wireless.transport.ordercollection.model.CircuitDetails;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderCircuitDetails;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderRequest;
import com.vz.pc.wireless.transport.ordercollection.model.MongoParams;
import com.vz.pc.wireless.transport.ordercollection.model.OrderCardsResponse;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetailReport;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetailRequest;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.OrderInOutResponse;
import com.vz.pc.wireless.transport.ordercollection.model.OrderReport;
import com.vz.pc.wireless.transport.ordercollection.model.OrderSearchRequest;
import com.vz.pc.wireless.transport.ordercollection.model.OwnershipDetails;
import com.vz.pc.wireless.transport.ordercollection.model.PcOrderRequest;
import com.vz.pc.wireless.transport.ordercollection.model.PcWirelessRemarkRequest;
import com.vz.pc.wireless.transport.ordercollection.model.RemarksResponse;
import com.vz.pc.wireless.transport.ordercollection.model.TaskDetailReport;
import com.vz.pc.wireless.transport.ordercollection.model.UIOrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.UISettings;
import com.vz.pc.wireless.transport.ordercollection.model.User;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.AcnaCcnaData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OneFiberOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessRemark;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.TaskInst;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.VendorData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.AcnaCcnaDataRepository;
import com.vz.pc.wireless.transport.ordercollection.service.CircuitDetailsService;
import com.vz.pc.wireless.transport.ordercollection.service.FiberOrderCollectionService;
import com.vz.pc.wireless.transport.ordercollection.service.IOrderCollectionService;
import com.vz.pc.wireless.transport.ordercollection.service.IOrderDetailsService;
import com.vz.pc.wireless.transport.ordercollection.service.IReportService;
import com.vz.pc.wireless.transport.ordercollection.service.IVendorIcscDetails;
import com.vz.pc.wireless.transport.ordercollection.service.OrderCardsService;
import com.vz.pc.wireless.transport.ordercollection.service.OrderInterfaceActivityService;
import com.vz.pc.wireless.transport.ordercollection.service.RemarksService;
import com.vz.pc.wireless.transport.ordercollection.service.UserInfoService;
import com.vz.pc.wireless.transport.ordercollection.validator.CircuitDetailsValidator;
import com.vz.pc.wireless.transport.ordercollection.validator.FiberOrderCollectionValidator;
import com.vz.pc.wireless.transport.ordercollection.validator.OrderCollectionValidator;
import com.vz.pc.wireless.transport.ordercollection.validator.RemarksDetailsValidator;
import com.vz.pc.wireless.transport.ordercollection.validator.StrikeRemarksValidator;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
@RefreshScope
@RestController
@RequestMapping("/order-processing")
@Api(value = "Order Collection")
public class OrderCollectionController {

	@Autowired
	IOrderCollectionService iOrderCollectionService;

	@Autowired
	OrderCollectionValidator OrderCollectionValidator;

	@Autowired
	FiberOrderCollectionService fiberOrderCollectionService;

	@Autowired
	FiberOrderCollectionValidator fiberOrderCollectionValidator;
	
	@Autowired
	IOrderDetailsService iOrderDetailService;
	
	@Autowired
	CircuitDetailsService circuitDetailService;
	
	@Autowired
	OrderCardsService orderCardsService;
	
	@Autowired
	RemarksService remarksService;
/*
	@Autowired
	OrderDetailsValidator orderDetailsValidator;*/
	
	@Autowired
	CircuitDetailsValidator circuitDetailsValidator;
	
	@Autowired
	RemarksDetailsValidator remarksDetailsValidator;
	
	@Autowired
	StrikeRemarksValidator strikeRemarksValidator;
	
	@Autowired
	OrderInterfaceActivityService orderRetryService;
	
	@Autowired
	IVendorIcscDetails iVendorIcscDetails;

	@Autowired
	AcnaCcnaDataRepository acnaCcnaRepo;

	@Autowired
	IReportService iReportService;
	
	@Autowired
	UserInfoService userInfoService;
	
	
	@Value("${spring.application.name}")
	private String applicationname;

	
	 @Autowired
	 @Qualifier("ribbonTaskServiceClient")
	  private TaskServiceClient taskServiceClient;
	 
	private static Logger logger = LoggerFactory.getLogger(OrderCollectionController.class);
	
	@RequestMapping(value = "/create", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ApiOperation(value = "Create Wireless Transport Order", notes = "Create PC Wireless Transport order", response = PcWirelessOrder.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Order Created Successfully", response = PcWirelessOrder.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })

	
	public PcWirelessOrder create(@RequestBody @Validated PcOrderRequest pcOrderReq, BindingResult errors, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info(applicationname  + " : Inside {0}. Parameter :  {1}" , new Object[]{Thread.currentThread().getStackTrace()[2].getMethodName(), pcOrderReq});

		ValidationUtils.invokeValidator(OrderCollectionValidator, pcOrderReq, errors);
		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		
		Future<PcWirelessOrder> orderResponse = iOrderCollectionService.createPCOrder(pcOrderReq);
		PcWirelessOrder pcWirelessOrder = orderResponse.get();

		if (pcWirelessOrder == null) {
		//	iOrderCollectionService.auditEvents("[FAILURE] Order Collection Failure for Pon Number ["+ pcOrderReq.getPonNumber()+"]" , pcOrderReq.getUserId() , 0);
			throw new DataNotFoundException("Order ", " unable to Create", "Request Not found");
		}
		//iOrderCollectionService.auditEvents("[SUCCESS] Order Collection Successful", pcWirelessOrder.getOrderDetails().getUserId(), Long.parseLong(pcWirelessOrder.getOrder().getOrderNumber()));

		logger.info("Ending Order Collection Service - Response [" + pcWirelessOrder.toString() + "]");
		
		return pcWirelessOrder;
	}
	 
	@RequestMapping(value = "/createOneFiberOrder", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ApiOperation(value = "Create Wireless One Fiber Order", notes = "Create PC Wireless One Fiber Order", response = PcWirelessOrder.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Order Created Successfully", response = PcWirelessOrder.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })

	
	public OneFiberOrder createOneFiberOrder(@RequestBody @Validated FiberOrderRequest fiberOrderReq, BindingResult errors, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info(applicationname  + " : Inside {0}. Parameter :  {1}" , new Object[]{Thread.currentThread().getStackTrace()[2].getMethodName(), fiberOrderReq});

		ValidationUtils.invokeValidator(fiberOrderCollectionValidator, fiberOrderReq, errors);
		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		
		Future<OneFiberOrder> orderResponse = fiberOrderCollectionService.createFiberOrder(fiberOrderReq);
		OneFiberOrder oneFiberOrder = orderResponse.get();

		if (oneFiberOrder == null) {
			throw new DataNotFoundException("Order ", " unable to Create", "Request Not found");
		}

		logger.info("Ending Order Collection Service - Response [" + oneFiberOrder.toString() + "]");
		
		return oneFiberOrder;
	}

	
	@RequestMapping(value = "/updateOrderDetails", method = RequestMethod.POST)
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Order Details  Successfully", response = String.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public String  updateOrderDetails(@RequestParam @Validated String orderNumber,@RequestParam @Validated String userId,  @RequestParam  String   firstName ,@RequestParam   String   lastName,   @RequestParam String   userEmail,   HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info(applicationname  + " : Inside {0}. Parameter :  {1}" , new Object[]{Thread.currentThread().getStackTrace()[2].getMethodName(), orderNumber , userId });
		
		String orderResponse = "{\"Status\":\"Failure\"}";
		orderResponse = iOrderCollectionService.updateOrderDetails(orderNumber,userId ,firstName ,  lastName  , userEmail);
		if (orderResponse == null) {
			throw new DataNotFoundException("Order ", " unable to update Order Details ", "Request Not found");
		}
		logger.debug("Ending Update Order Details  Service - Response [" + orderResponse.toString() + "]");
		return orderResponse;
	}

	
	
	@RequestMapping(value = "/getOrderDetails/{orderNumber}", method = RequestMethod.GET)
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = OrderDetails.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Order Details  Successfully", response = OrderDetails.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public UIOrderDetails getOrderDetails(@RequestParam @Validated String orderNumber, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info(applicationname  + " : Inside {0}. Parameter :  {1}" , new Object[]{Thread.currentThread().getStackTrace()[2].getMethodName(), orderNumber  });
		

		UIOrderDetails orderResponse = iOrderDetailService.getOrderDetails(orderNumber);
		

		if (orderResponse == null) {
			throw new DataNotFoundException("Order ", " unable to Get Order Details ", "Request Not found");
		}
		logger.debug("Ending Order Details  Service - Response [" + orderResponse.toString() + "]");
		return orderResponse;
	}

	@RequestMapping(value = "/getFiberOrderDetails/{orderNumber}", method = RequestMethod.GET)
	@ApiOperation(value = "Wireless Transport Order", notes = " Fiber Order Details for order number", response = OrderDetails.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Order Details  Successfully", response = OrderDetails.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public UIOrderDetails getFiberOrderDetails(@RequestParam @Validated String orderNumber, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info(applicationname  + " : Inside {0}. Parameter :  {1}" , new Object[]{Thread.currentThread().getStackTrace()[2].getMethodName(), orderNumber  });
		

		UIOrderDetails orderResponse = fiberOrderCollectionService.getFiberOrderDetails(orderNumber);
		

		if (orderResponse == null) {
			throw new DataNotFoundException("Order ", " unable to Get Order Details ", "Request Not found");
		}
		logger.debug("Ending Order Details  Service - Response [" + orderResponse.toString() + "]");
		return orderResponse;
	}
	

	@RequestMapping(value = "/getOrderSearchData",method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = OrderDetails.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Order Details  Successfully", response = OrderDetails.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public List<UIOrderDetails> getOrderSearchData(@RequestBody @Validated OrderSearchRequest orderSearchRequest, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Order Detail  Service Request  [ " + orderSearchRequest.toString() + " ] ");
		

		List<UIOrderDetails> orderResponse = iOrderDetailService.getOrderSearchData(orderSearchRequest);
		

/*		if (orderResponse == null || orderResponse.size() ==0) {
			throw new DataNotFoundException("Order ", " unable to Get Order Detail ", "Request Not found");
		}*/
		logger.debug("Ending Order Detail  Service - Response [" + orderResponse.toString() + "]");
		
		return orderResponse;
	}
	
	@RequestMapping(value = "/getFiberOrderSearchData",method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	@ApiOperation(value = "Wireless Transport Order", notes = " Fiber Order Details ", response = OrderDetails.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Order Details  Successfully", response = OrderDetails.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public List<UIOrderDetails> getFiberOrderSearchData(@RequestBody @Validated OrderSearchRequest orderSearchRequest, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Order Detail  Service Request  [ " + orderSearchRequest.toString() + " ] ");
		

		List<UIOrderDetails> orderResponse = iOrderDetailService.getOneFiberOrderSearchData(orderSearchRequest);
		

		logger.debug("Ending Order Detail  Service - Response [" + orderResponse.toString() + "]");
		
		return orderResponse;
	}
	
	
	@RequestMapping(value = "/circuitDetails/{orderNumber}",method = RequestMethod.GET)
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = CircuitDetails.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Circuit Details  Successfully", response = CircuitDetails.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })
		
	public CircuitDetails getCircuitDetails(@RequestParam("orderNumber") String orderNumber, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Order Detail  Service Request  [ " + orderNumber.toString() + " ] ");
		

		CircuitDetails circuitResponse = circuitDetailService.getCircuitDetails(orderNumber);
		

		if (circuitResponse == null) {
			throw new DataNotFoundException("Circuit ", " unable to Get Circuit Details", "Request Not found");
		}
		logger.debug("Ending Circuit Details Service - Response [" + circuitResponse.toString() + "]");
		
		return circuitResponse;
	}

	@RequestMapping(value = "/fiberOrderCircuitDetails/{orderNumber}",method = RequestMethod.GET)
	@ApiOperation(value = "Wireless Transport Order", notes = " Fiber Order Details ", response = CircuitDetails.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Circuit Details  Successfully", response = CircuitDetails.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })
		
	public FiberOrderCircuitDetails getFiberOrderCircuitDetails(@RequestParam("orderNumber") String orderNumber, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Fiber Order Detail  Service Request  [ " + orderNumber.toString() + " ] ");
		

		FiberOrderCircuitDetails circuitResponse = circuitDetailService.getFiberOrderCircuitDetails(orderNumber);
		

		if (circuitResponse == null) {
			throw new DataNotFoundException("Circuit ", " unable to Get Circuit Details", "Request Not found");
		}
		logger.debug("Ending Fiber Order Circuit Details Service - Response [" + circuitResponse.toString() + "]");
		
		return circuitResponse;
	}

	@RequestMapping(value = "/orderCards", method = RequestMethod.GET , produces = "application/json")
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = OrderCardsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Order Cards  Successfully", response = OrderCardsResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public List<OrderCardsResponse> getOrderCards(HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Order Cards Service Request ");

		List<OrderCardsResponse> orderCardsResponseList = orderCardsService.getOrderCardsInfo();

		if (orderCardsResponseList == null) {
			throw new DataNotFoundException("Order Cards ", "unable to Get Order Cards List", "Request Not found");
		}
		logger.debug("Ending Order Cards Service - Response [" + orderCardsResponseList.toString() + "]");

		return orderCardsResponseList;
	}

	@RequestMapping(value = "/fiberOrderCards", method = RequestMethod.GET , produces = "application/json")
	@ApiOperation(value = "Wireless Transport Order", notes = " Fiber Order Details ", response = OrderCardsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Fiber Order Cards  Successfully", response = OrderCardsResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public List<OrderCardsResponse> getFiberOrderCards(HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Fiber Order Cards Service Request ");
		
		List<OrderCardsResponse> orderCardsResponseList = orderCardsService.getFiberOrderCardsInfo();

		if (orderCardsResponseList == null) {
			throw new DataNotFoundException("Fiber Order Cards ", "unable to Get Order Cards List", "Request Not found");
		}
		logger.debug("Ending Fiber Order Cards Service - Response [" + orderCardsResponseList.toString() + "]");

		return orderCardsResponseList;
	}
	
	@RequestMapping(value = "/addRemarks", method = RequestMethod.POST)
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = PcWirelessRemark.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Remarks Info Inserted Successfully", response = PcWirelessRemark.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public Future<PcWirelessRemark> insertRemarksInfo(@RequestBody @Validated PcWirelessRemarkRequest remarks,BindingResult errors,HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Order Cards Service Request ");
		
		ValidationUtils.invokeValidator(remarksDetailsValidator,remarks,errors);
		if (errors.hasErrors()) {
			throw new BindException(errors);
		}

		Future<PcWirelessRemark> remarksResponseList = remarksService.InsertRemarksInfo(remarks);

		if (remarksResponseList == null) {
			throw new DataNotFoundException("Remarks Info ", " unable to Get Remarks Info List", "Request Not found");
		}
		logger.debug("Ending Remarks Info Service - Response [" + remarksResponseList.toString() + "]");

		return remarksResponseList;
	}
	
	@RequestMapping(value = "/showRemarks", method = RequestMethod.GET)
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = PcWirelessRemark.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Remarks Info Inserted Successfully", response = PcWirelessRemark.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public List<PcWirelessRemark> getRemarksInfo(@RequestParam("pcOrderId") String pcOrderId,HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Show Remarks Service Request ");
		

		List<PcWirelessRemark> remarksResponseList = remarksService.getRemarksInfoList(pcOrderId);

		if (remarksResponseList == null) {
			throw new DataNotFoundException("Show Remarks ", " unable to Show Remarks Info List", "Request Not found");
		}
		logger.debug("Ending Show Remarks Service - Response [" + remarksResponseList.toString() + "]");

		return remarksResponseList;
	}

	@RequestMapping(value = "/showFiberOrderRemarks", method = RequestMethod.GET)
	@ApiOperation(value = "Wireless Transport Order", notes = "Show Fibre Order Details", response = PcWirelessRemark.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Remarks Info Inserted Successfully", response = PcWirelessRemark.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public List<PcWirelessRemark> getFiberOrderRemarksInfo(@RequestParam("fiberOrderNumber") String fiberOrderNumber,HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Show Fibre Order Remarks Service Request ");
		

		List<PcWirelessRemark> remarksResponseList = remarksService.getFiberOrderRemarksInfoList(fiberOrderNumber);

		if (remarksResponseList == null) {
			throw new DataNotFoundException("Show Remarks ", " unable to Show Fiber Order Remarks Info List", "Request Not found");
		}
		logger.debug("Ending Show Remarks Service - Response [" + remarksResponseList.toString() + "]");

		return remarksResponseList;
	}
	
	@RequestMapping(value = "/strikeRemarks", method = RequestMethod.POST)
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = RemarksResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "strike remarks Successfully", response = RemarksResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public RemarksResponse strikeRemarksInfo(@RequestBody @Validated PcWirelessRemarkRequest remarks,BindingResult errors,HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException, JSONException {

		logger.info("Initiating Strike Remarks Service Request ");
		
		ValidationUtils.invokeValidator(strikeRemarksValidator,remarks,errors);
		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		
		RemarksResponse remarksResponse = remarksService.strikeRemark(remarks);

		if (remarksResponse == null) {
			throw new DataNotFoundException("Strike Remarks ", " unable to Strike Remarks Info List", "Request Not found");
		}
		logger.debug("Ending Strike Remarks Service - Response [" + remarksResponse.toString() + "]");

		return remarksResponse;
	}

	@RequestMapping(value = "/unStrikeRemarks", method = RequestMethod.POST)
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = RemarksResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Unstrike Remarks Successfully", response = RemarksResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })

	

	public RemarksResponse unStrikeRemarksInfo(@RequestBody @Validated PcWirelessRemarkRequest remarks,BindingResult errors,HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException, JSONException {

		logger.info("Initiating UnStrike Remarks Service Request ");
		
		ValidationUtils.invokeValidator(strikeRemarksValidator,remarks,errors);
		if (errors.hasErrors()) {
			throw new BindException(errors);
		}
		
		RemarksResponse remarksResponse = remarksService.unStrikeRemark(remarks);

		if (remarksResponse == null) {
			throw new DataNotFoundException("UnStrike Remarks ", " unable to UnStrike Remarks Info List", "Request Not found");
		}
		logger.debug("Ending UnStrike Remarks Service - Response [" + remarksResponse.toString() + "]");

		return remarksResponse;
	}
	
	
	
	@RequestMapping(value = "/getInterfaceActivity/{pcOrderId} ", method = RequestMethod.GET)
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ", response = Map.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Remarks Info Inserted Successfully", response = PcWirelessRemark.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	public Map<String ,Object> getInOutEvents(@RequestParam @Validated String pcOrderId,HttpServletRequest request)
			throws Exception {

		logger.info("Initiating InOutEvents Service Request ");

		Map<String ,Object> orderOutResponseMap =orderRetryService.getOrderInOutEventsInfo(pcOrderId);

		if (orderOutResponseMap == null) {
			throw new DataNotFoundException("IN OUT ", " unable to Get InOut event List", "Request Not found");
		}
		logger.debug("Ending InOutEvents Service - Response [" + orderOutResponseMap.toString() + "]");

		return orderOutResponseMap;
	}
	
	@RequestMapping(value = "/updateInterfaceActivity", method = RequestMethod.POST , consumes = "application/json", produces = "application/json") 
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Order Details ")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Updated Info Inserted Successfully"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public String  updateInOutEvents(@RequestBody @Validated OrderInOutResponse orderInOutResponse, HttpServletRequest request)
			throws Exception {
		logger.info("Initiating updateInOutEvents Service Request ["+orderInOutResponse.toString()+"]");
		String status=orderRetryService.updateOrderInOrOutEvents(orderInOutResponse);
		if (status == null) {
			throw new DataNotFoundException("IN OUT ", " unable to Update In or Out event ", "Request Not found");
		}
		logger.debug("Ending InOutEvents Update service - Response [" + status + "]");
		return status;
	}
	
	
	@RequestMapping(value = "/getOwnershipDetails/{orderNumber}", method = RequestMethod.GET)
	@ApiOperation(value = "Wireless Transport Order", notes = " PC Wireless Transport Ownership Details ", response = OwnershipDetails.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Order Details  Successfully", response = OrderDetails.class),
	@ApiResponse(code = 400, message = "Invalid input provided"), @ApiResponse(code = 500, message = "Internal Server Error"), })
		
	public OwnershipDetails getOwnershipDetails(@RequestParam @Validated String orderNumber, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		logger.info("Initiating Order Detail  Service Request  [ " + orderNumber + " ] ");

		OwnershipDetails orderResponse = iOrderDetailService.getOwnershipDetails(orderNumber);
		

		if (orderResponse == null) {
			throw new DataNotFoundException("Order ", " unable to Get Order Details ", "Request Not found");
		}
		logger.debug("Ending Order Details  Service - Response [" + orderResponse.toString() + "]");
		return orderResponse;
	}

	
	@RequestMapping(value = "/vendorIcsc/create", method = RequestMethod.POST , consumes = "application/json", produces = "application/json") 
	@ApiOperation(value = "Wireless Transport Order", notes = "Create Vendor  Code and ICSC Data")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Vendor Info Inserted Successfully"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public String  addVendorIcsc(@RequestBody @Validated VendorData vendorData, HttpServletRequest request)
			throws Exception {
		logger.info("Initiating Add Vendor Data  Service Request ["+vendorData.toString()+"]");
		iVendorIcscDetails.addVendorIcscDetail(vendorData);
		return "{\"Status\":\"Success\"}";
	}

	
	@RequestMapping(value = "/vendorIcsc/update", method = RequestMethod.POST , consumes = "application/json", produces = "application/json") 
	@ApiOperation(value = "Wireless Transport Order", notes = "Update Vendor  Code and ICSC Data")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Vendor Info Updated Successfully"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public String  updateVendorIcsc(@RequestBody @Validated VendorData vendorData, HttpServletRequest request)
			throws Exception {
		logger.info("Initiating Update Vendor Data  Service Request ["+vendorData.toString()+"]");
		iVendorIcscDetails.updateVendorDetail(vendorData);
		return "{\"Status\":\"Success\"}";
	}
	
	@RequestMapping(value = "/vendorIcsc/delete", method = RequestMethod.POST , consumes = "application/json", produces = "application/json") 
	@ApiOperation(value = "Wireless Transport Order", notes = "Update Vendor  Code and ICSC Data")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Vendor Info Updated Successfully"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public String  deleteVendorIcsc(@RequestBody @Validated VendorData vendorData, HttpServletRequest request)
			throws Exception {
		logger.info("Initiating Update Vendor Data  Service Request ["+vendorData.toString()+"]");
		iVendorIcscDetails.removeVendorDetail(vendorData);
		return "{\"Status\":\"Success\"}";
	}
	
	
	@RequestMapping(value = "/vendorIcsc/fetch", method = RequestMethod.GET ) 
	@ApiOperation(value = "Wireless Transport Order", notes = "Update Vendor  Code and ICSC Data" , response =VendorData.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Vendor Info retreived Successfully" ,  response =VendorData.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public List<VendorData>  fetchVendorIcsc(HttpServletRequest request)
			throws Exception {
		logger.info("Vendor ICSC Fetch");
		return iVendorIcscDetails.fetchVendorIcscDetail();
	}
	
	
	@RequestMapping(value = "/acnaccna/add", method = RequestMethod.POST , consumes = "application/json", produces = "application/json") 
	@ApiOperation(value = "Wireless Transport Order", notes = "Update Vendor  Code and ICSC Data")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Acna CCna Info Updated Successfully"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public String  addAcnaCcnaData(@RequestBody @Validated AcnaCcnaData acnaCcnaData, HttpServletRequest request)
			throws Exception {
		logger.info("Initiating Update acnaCcna Data  Service Request ["+acnaCcnaData.toString()+"]");
		iVendorIcscDetails.addAcnaccnaData(acnaCcnaData);
		return "{\"Status\":\"Success\"}";
	}
	
	@RequestMapping(value = "/acnaccna/delete", method = RequestMethod.POST , consumes = "application/json", produces = "application/json") 
	@ApiOperation(value = "Wireless Transport Order", notes = "Update Vendor  Code and ICSC Data")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Acna CCna Info Deleted Successfully"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public String  removeAcnaCcnaData(@RequestBody @Validated AcnaCcnaData acnaCcnaData, HttpServletRequest request)
			throws Exception {
		logger.info("Initiating Update acnaCcna Data  Service Request ["+acnaCcnaData.toString()+"]");
		iVendorIcscDetails.removeAcnaCcnaData(acnaCcnaData);
		return "{\"Status\":\"Success\"}";
	}
	
	@RequestMapping(value = "/acnaccna/fetch", method = RequestMethod.GET ) 
	@ApiOperation(value = "Wireless Transport Order", notes = "Update Vendor  Code and ICSC Data", response = AcnaCcnaData.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Acna Ccna Info retreived Successfully" ,  response = AcnaCcnaData.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public AcnaCcnaData  fetchAcnaCcnac(HttpServletRequest request)
			throws Exception {
		
		return iVendorIcscDetails.fetchAcnaCcnaDetail();
	}
	@RequestMapping(value = "/acnaccna/teritory/fetch", method = RequestMethod.GET ) 
	@ApiOperation(value = "Wireless Transport Order", notes = "Update Vendor  Code and ICSC Data", response = AcnaCcnaData.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Acna Ccna Info retreived Successfully" ,  response = AcnaCcnaData.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public AcnaCcnaData  fetchAcnaCcnaRegionsUisngTeritory(@RequestParam("teritory") List<String> teritory, HttpServletRequest request)
			throws Exception {
		AcnaCcnaData data = iVendorIcscDetails.fetchAcnaCcnaDetail();
		List<MongoParams> regions = data.getRegions().stream().filter(region->teritory.contains(region.getTeritory())).collect(Collectors.toList());
		data.setRegions(regions);
		return data;
		//return acnaCcnaRepo.findByRegionsTeritory(teritory);
	}

	
	@RequestMapping(value = "/acnaccna/bandwidth/fetch", method = RequestMethod.GET ) 
	@ApiOperation(value = "Wireless Transport Order", notes = "Update Vendor  Code and ICSC Data", response = AcnaCcnaData.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Acna Ccna Info retreived Successfully" ,  response = AcnaCcnaData.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public AcnaCcnaData  fetchAcnaCcnaBandwidth(@RequestParam("bandwidth") String bandwidth, HttpServletRequest request)
			throws Exception {
		
		return acnaCcnaRepo.findByBandwidthName(bandwidth);
	}
	
	@RequestMapping(value = "/reports/fetchorderDetails", method =RequestMethod.POST) 
	@ApiOperation(value = "Report for Order Details", notes = "Report for Order Details", response = OrderDetailReport.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OrderDetailReport retreived successfully", response = OrderDetailReport.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public List<OrderDetailReport>  fetchOrderDetailReports(@RequestBody   @Validated  OrderDetailRequest orDetailReq, BindingResult errors, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		return iReportService.getOrderDetailsReport(orDetailReq);
	}
	
	
	@RequestMapping(value = "/reports/fetchtaskDetails", method =RequestMethod.POST) 
	@ApiOperation(value = "Report for Task Details", notes = "Report for Task Details", response = TaskDetailReport.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "TaskDetailReport retreived successfully", response = TaskDetailReport.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public List<TaskDetailReport>  fetchTaskDetailReports(@RequestBody   @Validated  OrderDetailRequest orDetailReq, BindingResult errors, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		return iReportService.getTaskDetailsReport(orDetailReq);
	}
	
	
	@RequestMapping(value = "/task/load", method =RequestMethod.POST) 
	@ApiOperation(value = "Report for Task Details", notes = "Report for Task Details", response = String.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "TaskDetailReport retreived successfully", response = String.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public String createTask(@RequestBody   @Validated  TaskInst
			taskInst, BindingResult errors, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		return taskServiceClient.create(taskInst);
	}
	
	@RequestMapping(value = "/task/update", method =RequestMethod.POST) 
	@ApiOperation(value = "Report for Task Details", notes = "Report for Task Details", response = TaskInst.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "TaskDetailReport retreived successfully", response = TaskInst.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })
	
	public TaskInst updateTask(@RequestBody   @Validated  TaskInst
			taskInst, BindingResult errors, HttpServletRequest request)
			throws InterruptedException, ExecutionException, TimeoutException, BindException {

		return taskServiceClient.update(taskInst);
	}
	
    @RequestMapping(value = "/reports/fetchCountByOrderType", method = RequestMethod.GET ) 
    @ApiOperation(value = "Wireless Transport Order", notes = "Fetch OrderType Count", response = OrderReport.class)
    @ApiResponses(value = {
                  @ApiResponse(code = 200, message = "OrderType Count Info retreived Successfully" ,  response = OrderReport.class),
                  @ApiResponse(code = 400, message = "Invalid input provided"),
                  @ApiResponse(code = 500, message = "Internal Server Error"), })
    
    public List<OrderReport> getOrderTypeCount(HttpServletRequest request) throws Exception {
          
    return iOrderDetailService.getOrderTypeCount();
    }
    
    @RequestMapping(value = "/reports/fetchCountByRegion", method = RequestMethod.GET ) 
    @ApiOperation(value = "Wireless Transport Order", notes = "Fetch Region Count", response = OrderReport.class)
    @ApiResponses(value = {
                  @ApiResponse(code = 200, message = "Region Count Info retreived Successfully" ,  response = OrderReport.class),
                  @ApiResponse(code = 400, message = "Invalid input provided"),
                  @ApiResponse(code = 500, message = "Internal Server Error"), })
    
    public List<OrderReport> getRegionCount(HttpServletRequest request) throws Exception {
         return iOrderDetailService.getRegionCount();
    }

    
    @RequestMapping(value = "/reports/fetchOrderStatusAndDueDateCount", method = RequestMethod.POST ) 
    @ApiOperation(value = "Wireless Transport Order", notes = "Fetch OrderStatus and DueDate Count", response = OrderReport.class)
    @ApiResponses(value = {
                  @ApiResponse(code = 200, message = "OrderStatus and DueDate Count Info retreived Successfully" ,  response = OrderReport.class),
                  @ApiResponse(code = 400, message = "Invalid input provided"),
                  @ApiResponse(code = 500, message = "Internal Server Error"), })
    
    public List<OrderReport> getOrderStatusAndDueDateCount(@RequestParam @Validated String regions,@RequestParam @Validated String statusAndDueDate, HttpServletRequest request) throws Exception {

    	return iOrderDetailService.getOrderStatusAndDueDateCount(regions, statusAndDueDate);
    
    }

	@RequestMapping(value = "/mergeUISettings", method = RequestMethod.POST, produces = "application/json" )
	@ApiOperation(value = "Update the user visit details", notes = "Order Collection Service", response = String.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful update of user visited Site Id", response = String.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })	
	public List<UISettings> mergeUserSettings(@RequestHeader("user") String userJSON, @RequestBody String orderNumber) throws Exception {
		
		
        final User user = userInfoService.getUserInfo();
		
		final List<UISettings> userVisitedList= (List<UISettings>) orderCardsService.mergeUserSettings(user.getUserId(), orderNumber);
		logger.info("OrderCollection-Service : Returning with {}", userVisitedList);
		return userVisitedList;
	}
	
	
	@RequestMapping(value = "/getUIUserSettings", method = RequestMethod.GET,  produces = "application/json")
	@ApiOperation(value = "Returns output of user visited Order details", notes = "Order Collection Service", response = String.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful retrieval of user visited Site Id", response = String.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })	
	public List<UISettings> getUIUserSettings(@RequestHeader("user") String userJSON) throws Exception {
		
        final User user = userInfoService.getUserInfo();

		final List<UISettings> userVisitedList= (List<UISettings>) orderCardsService.getUserSettings(user.getUserId());
		logger.debug("OrderCollection-Service : Returning with", userVisitedList);
		return userVisitedList;
	}
	
	@RequestMapping(value = "/getSiteNFID", method = RequestMethod.GET ) 
	@ApiOperation(value = "Retrieve site NFID for given site", notes = "Retrieve site NFID for given site" , response =String.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Site NFID retreived Successfully" ,  response =JSONObject.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 500, message = "Internal Server Error"), })

	public JSONObject  getSiteNFID(@RequestParam @Validated String siteInstId)
			throws Exception {
		return iOrderDetailService.getSiteNFID(siteInstId);
	}
}
