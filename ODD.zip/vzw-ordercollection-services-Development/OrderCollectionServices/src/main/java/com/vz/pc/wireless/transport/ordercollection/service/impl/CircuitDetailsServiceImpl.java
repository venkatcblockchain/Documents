package com.vz.pc.wireless.transport.ordercollection.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.vz.pc.wireless.transport.ordercollection.config.SwaggerConfig;
import com.vz.pc.wireless.transport.ordercollection.exception.DataNotFoundException;
import com.vz.pc.wireless.transport.ordercollection.model.ASiteDetails;
import com.vz.pc.wireless.transport.ordercollection.model.CircuitDetails;
import com.vz.pc.wireless.transport.ordercollection.model.ClrSegments;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrder;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderCircuitDetails;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderSegment;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderSite;
import com.vz.pc.wireless.transport.ordercollection.model.Order;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.Segment;
import com.vz.pc.wireless.transport.ordercollection.model.SegmentDetails;
import com.vz.pc.wireless.transport.ordercollection.model.Site;
import com.vz.pc.wireless.transport.ordercollection.model.ZSiteDetails;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OneFiberOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.OneFiberOrderRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.PcWirelessOrderRepository;
import com.vz.pc.wireless.transport.ordercollection.service.CircuitDetailsService;

@Component("CircuitDetailsService")
@EnableAutoConfiguration(exclude = { SwaggerConfig.class })
@Transactional
public class CircuitDetailsServiceImpl implements CircuitDetailsService {

	private static Logger logger = LoggerFactory.getLogger(CircuitDetailsServiceImpl.class);

	@Autowired
	private MongoOperations mongo;

	@Autowired
	private PcWirelessOrderRepository pcWirelessOrderRepository;

	@Autowired
	OneFiberOrderRepository fiberOrderRepo;

	@Override
	public CircuitDetails getCircuitDetails(String orderNumber) {

		CircuitDetails circuitDetails = new CircuitDetails();

		circuitDetails.setSegmentDetails(getSegmentDetails(orderNumber));
		return circuitDetails;
	}

	@Override
	@Async
	public List<SegmentDetails> getSegmentDetails(String orderNumber) {
		logger.debug("Get Segment Details Order Number [" + orderNumber + "]");

		List<SegmentDetails> segmentDetailslist = new ArrayList<SegmentDetails>();
		try {
			PcWirelessOrder pcWirelessOrder = pcWirelessOrderRepository.findByOrderOrderNumber(orderNumber);

			OrderDetails orderDetail = Optional.ofNullable(pcWirelessOrder.getOrderDetails())
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

			Order order = Optional.ofNullable(pcWirelessOrder.getOrder())
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

			List<Segment> segmentList = Arrays.asList(Optional.ofNullable(orderDetail.getSegments()).orElse(null));

			List<Site> sites = Arrays.asList(Optional.ofNullable(orderDetail.getSites()).orElse(null));
			/*
			 * String controlIcsc =
			 * Optional.ofNullable(segmentList.stream().filter(s ->
			 * "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().
			 * getIcsc()) .orElseThrow( () -> new DataNotFoundException(null,
			 * null, "  No PC Wireless Segment  ControlICSC found for  [" +
			 * orderNumber + "] " + "   "));
			 * 
			 * String zSiteID =
			 * Optional.ofNullable(segmentList.stream().filter(s ->
			 * "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().
			 * getzSiteId()) .orElseThrow( () -> new DataNotFoundException(null,
			 * null, "  No PC Wireless Segment  ControlICSC found for  [" +
			 * orderNumber + "] " + "   "));
			 */

			segmentList.stream().forEach(segment -> {
				SegmentDetails segResponse = new SegmentDetails();
				segResponse.setSegmentName(segment.getSegmentName());
				segResponse.setSegmentId(segment.getSegmentId());
				segResponse.setCfa(segment.getCfa());
				segResponse.setIcsc(segment.getIcsc());
				segResponse.setBandwidth(segment.getBandwidth());
				segResponse.setVendor(segment.getVendorCode());
				segResponse.setBan(segment.getBan());
				segResponse.setType(segment.getSegmentType());
				
				Site siteA = (sites != null && sites.stream().filter(s -> s.getSiteId() != null && s.getSiteId().equalsIgnoreCase(segment.getaSiteId())).findAny().isPresent())
						? sites.stream().filter(s -> s.getSiteId() != null && s.getSiteId().equalsIgnoreCase(segment.getaSiteId())).findAny().get() : null;
				Site siteZ = (sites != null && sites.stream().filter(s -> s.getSiteId() != null && s.getSiteId().equalsIgnoreCase(segment.getzSiteId())).findAny().isPresent())
						? sites.stream().filter(s -> s.getSiteId() != null && s.getSiteId().equalsIgnoreCase(segment.getzSiteId())).findAny().get() : null;

				if (siteA != null) {
					ASiteDetails siteDetailsResponse = getASite(siteA);
					segResponse.setaSiteDetail(siteDetailsResponse);
				}
				if (siteZ != null) {
					ZSiteDetails siteDetailsResponse = getZSite(siteZ);
					segResponse.setzSiteDetail(siteDetailsResponse);
				}
				if(segment.getCeVlan()  !=null){
					segResponse.setCeVlan(segment.getCeVlan());
				}
				
				if(segment.getRuid()  !=null){
					segResponse.setRuid(segment.getRuid());
				}
				
				logger.info("segResponse [" + segResponse.toString() + "]");
				segmentDetailslist.add(segResponse);
			});

		}

		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		logger.info("Segment Details for  [" + orderNumber + "] is [" + segmentDetailslist + "]");
		return segmentDetailslist;
	}


	@Override
	public FiberOrderCircuitDetails getFiberOrderCircuitDetails(String orderNumber) {

		FiberOrderCircuitDetails circuitDetails = getFiberOrderSegmentDetails(orderNumber);

		return circuitDetails;
	}

	@Override
	@Async
	public FiberOrderCircuitDetails getFiberOrderSegmentDetails(String orderNumber) {
		logger.debug("Get Segment Details Order Number [" + orderNumber + "]");

		FiberOrderCircuitDetails circuitDetails = new FiberOrderCircuitDetails();
		List<SegmentDetails> segmentDetailslist = new ArrayList<SegmentDetails>();
		try {
			OneFiberOrder oneFiberOrder = fiberOrderRepo.findByOrderOrderNumber(orderNumber);

			FiberOrderDetails fiberOrderDetail = Optional.ofNullable(oneFiberOrder.getOrderDetails())
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

			FiberOrder fiberOrder = Optional.ofNullable(oneFiberOrder.getOrder())
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

			List<FiberOrderSegment> segmentList = Arrays.asList(Optional.ofNullable(fiberOrderDetail.getSegments()).orElse(null));

			List<FiberOrderSite> sites = Arrays.asList(Optional.ofNullable(fiberOrderDetail.getSites()).orElse(null));
			/*
			 * String controlIcsc =
			 * Optional.ofNullable(segmentList.stream().filter(s ->
			 * "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().
			 * getIcsc()) .orElseThrow( () -> new DataNotFoundException(null,
			 * null, "  No PC Wireless Segment  ControlICSC found for  [" +
			 * orderNumber + "] " + "   "));
			 * 
			 * String zSiteID =
			 * Optional.ofNullable(segmentList.stream().filter(s ->
			 * "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().
			 * getzSiteId()) .orElseThrow( () -> new DataNotFoundException(null,
			 * null, "  No PC Wireless Segment  ControlICSC found for  [" +
			 * orderNumber + "] " + "   "));
			 */

			segmentList.stream().forEach(segment -> {
				SegmentDetails segResponse = new SegmentDetails();
				segResponse.setSegmentName(segment.getSegmentName());
				segResponse.setSegmentId(segment.getSegmentId());
				//segResponse.setCfa(segment.getCfa());
				//segResponse.setIcsc(segment.getIcsc());
				segResponse.setBandwidth(segment.getBandwidth());
				segResponse.setVendor(segment.getVendor());
				//segResponse.setBan(segment.getBan());
				//segResponse.setType(segment.getSegmentType());
				
				FiberOrderSite siteA = (sites != null && sites.stream().filter(s -> s.getSiteId() != null && s.getSiteId().equalsIgnoreCase(segment.getaSiteId())).findAny().isPresent())
						? sites.stream().filter(s -> s.getSiteId() != null && s.getSiteId().equalsIgnoreCase(segment.getaSiteId())).findAny().get() : null;
						FiberOrderSite siteZ = (sites != null && sites.stream().filter(s -> s.getSiteId() != null && s.getSiteId().equalsIgnoreCase(segment.getzSiteId())).findAny().isPresent())
						? sites.stream().filter(s -> s.getSiteId() != null && s.getSiteId().equalsIgnoreCase(segment.getzSiteId())).findAny().get() : null;

				if (siteA != null) {
					ASiteDetails siteDetailsResponse = getFiberOrderASite(siteA);
					siteDetailsResponse.setContact(fiberOrderDetail.getFirstName());
					segResponse.setaSiteDetail(siteDetailsResponse);
				}
				if (siteZ != null) {
					ZSiteDetails siteDetailsResponse = getFiberOrderZSite(siteZ);
					siteDetailsResponse.setContact(fiberOrderDetail.getFirstName());
					segResponse.setzSiteDetail(siteDetailsResponse);
				}
				//if(segment.getCeVlan()  !=null){
				//	segResponse.setCeVlan(segment.getCeVlan());
				//}
				
				//if(segment.getRuid()  !=null){
				//	segResponse.setRuid(segment.getRuid());
				//}
				
				logger.info("segResponse [" + segResponse.toString() + "]");
				segmentDetailslist.add(segResponse);
			});
			circuitDetails.setSegmentDetails(segmentDetailslist);
			Map ordMilestone = null;
			if (!"disconnect".equalsIgnoreCase(fiberOrderDetail.getOrderType())) {
				BasicQuery query1 = new BasicQuery("{orderNumber:'"+orderNumber+"'}");
				ordMilestone = mongo.findOne(query1, Map.class,"coemilestone");
			}else {
				if(null != segmentDetailslist && !segmentDetailslist.isEmpty()) {
					ClrSegments clrSegments = new ClrSegments(segmentDetailslist.get(0).getSegmentId(), segmentDetailslist.get(0).getSegmentName(),null, null);
					ClrSegments[] clrSegmentsArr = new ClrSegments[1];
					clrSegmentsArr[0] = clrSegments;
					ordMilestone = new HashedMap();
					ordMilestone.put("clrSegments", clrSegmentsArr);
				}
			}

			if (null != ordMilestone) {
				logger.info("ordMilestone [" + ordMilestone.toString() + "]");
				circuitDetails.setCircuitDetrails(ordMilestone);
			}
		}

		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		logger.info("Segment Details for  [" + orderNumber + "] is [" + segmentDetailslist + "]");
		return circuitDetails;
	}

	@Override
	@Async
	public List<ASiteDetails> getASiteDetails(String orderNumber) {
		logger.debug("Order Number [" + orderNumber + "]");

		List<ASiteDetails> aSiteDetailslist = new ArrayList<ASiteDetails>();
		try {

			PcWirelessOrder pcWirelessOrder = pcWirelessOrderRepository.findByOrderOrderNumber(orderNumber);

			OrderDetails orderDetail = Optional.ofNullable(pcWirelessOrder.getOrderDetails())
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

			Order order = Optional.ofNullable(pcWirelessOrder.getOrder())
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

			List<Segment> segmentList = Arrays.asList(Optional.ofNullable(orderDetail.getSegments()).orElse(null));

			List<Site> sites = Arrays.asList(Optional.ofNullable(orderDetail.getSites()).orElse(null));

			/*
			 * String controlIcsc =
			 * Optional.ofNullable(segmentList.stream().filter(s ->
			 * "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().
			 * getIcsc()) .orElseThrow(() -> new DataNotFoundException(null,
			 * null, "  No PC Wireless Segment  ControlICSC found for  [" +
			 * orderNumber + "] " + "   "));
			 * 
			 * String zSiteID =
			 * Optional.ofNullable(segmentList.stream().filter(s ->
			 * "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().
			 * getzSiteId()) .orElseThrow(() -> new DataNotFoundException(null,
			 * null, "  No PC Wireless Segment  ControlICSC found for  [" +
			 * orderNumber + "] " + "   "));
			 */
			sites.stream().forEach(site -> {
				ASiteDetails siteDetailsResponse = new ASiteDetails();
				siteDetailsResponse.setSiteId(site.getSiteId());
				siteDetailsResponse.setSiteName(site.getSiteName());
				siteDetailsResponse.setContact(site.getContactName());
				siteDetailsResponse.setPhone(site.getPhone());
				siteDetailsResponse.setStreet(site.getStreet());
				siteDetailsResponse.setCity(site.getCity());
				siteDetailsResponse.setState(site.getState());
				siteDetailsResponse.setZip(site.getZip());
				siteDetailsResponse.setClli(site.getClli());
				siteDetailsResponse.setFloor(site.getFloor());
				siteDetailsResponse.setRoom(site.getRoom());
				siteDetailsResponse.setStructure(site.getStructure());
				siteDetailsResponse.setElevation(site.getElevation());
				siteDetailsResponse.setUnit(site.getUnit());
				aSiteDetailslist.add(siteDetailsResponse);
			});

		}

		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		logger.info("Persit Order Number Request [" + orderNumber + "]");
		return aSiteDetailslist;
	}

	@Override
	@Async
	public List<ZSiteDetails> getZSiteDetails(String orderNumber) {
		List<ZSiteDetails> ZSiteDetailslist = new ArrayList<ZSiteDetails>();
		try {

			PcWirelessOrder pcWirelessOrder = pcWirelessOrderRepository.findByOrderOrderNumber(orderNumber);

			OrderDetails orderDetail = Optional.ofNullable(pcWirelessOrder.getOrderDetails())
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

			Order order = Optional.ofNullable(pcWirelessOrder.getOrder())
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

			List<Segment> segmentList = Arrays.asList(Optional.ofNullable(orderDetail.getSegments()).orElse(null));

			List<Site> sites = Arrays.asList(Optional.ofNullable(orderDetail.getSites()).orElse(null));

			/*
			 * String controlIcsc =
			 * Optional.ofNullable(segmentList.stream().filter(s ->
			 * "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().
			 * getIcsc()) .orElseThrow(() -> new DataNotFoundException(null,
			 * null, "  No PC Wireless Segment  ControlICSC found for  [" +
			 * orderNumber + "] " + "   "));
			 * 
			 * String zSiteID =
			 * Optional.ofNullable(segmentList.stream().filter(s ->
			 * "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().
			 * getzSiteId()) .orElseThrow(() -> new DataNotFoundException(null,
			 * null, "  No PC Wireless Segment  ControlICSC found for  [" +
			 * orderNumber + "] " + "   "));
			 */
			sites.stream().forEach(site -> {
				ZSiteDetails siteDetailsResponse = new ZSiteDetails();
				siteDetailsResponse.setSiteId(site.getSiteId());
				siteDetailsResponse.setSiteName(site.getSiteName());
				siteDetailsResponse.setContact(site.getContactName());
				siteDetailsResponse.setPhone(site.getPhone());
				siteDetailsResponse.setStreet(site.getStreet());
				siteDetailsResponse.setCity(site.getCity());
				siteDetailsResponse.setState(site.getState());
				siteDetailsResponse.setZip(site.getZip());
				siteDetailsResponse.setClli(site.getClli());
				siteDetailsResponse.setFloor(site.getFloor());
				siteDetailsResponse.setRoom(site.getRoom());
				siteDetailsResponse.setStructure(site.getStructure());
				siteDetailsResponse.setElevation(site.getElevation());
				siteDetailsResponse.setUnit(site.getUnit());
				ZSiteDetailslist.add(siteDetailsResponse);
			});
		}

		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		logger.info("Persit Order Number Request [" + orderNumber + "]");
		return ZSiteDetailslist;
	}

	public ZSiteDetails getZSite(Site site) {
		ZSiteDetails siteDetailsResponse = new ZSiteDetails();
		siteDetailsResponse.setSiteId(site.getSiteId());
		siteDetailsResponse.setSiteName(site.getSiteName());
		siteDetailsResponse.setContact(site.getContactName());
		siteDetailsResponse.setPhone(site.getPhone());
		siteDetailsResponse.setStreet(site.getStreet());
		siteDetailsResponse.setCity(site.getCity());
		siteDetailsResponse.setState(site.getState());
		siteDetailsResponse.setZip(site.getZip());
		siteDetailsResponse.setClli(site.getClli());
		siteDetailsResponse.setFloor(site.getFloor());
		siteDetailsResponse.setRoom(site.getRoom());
		siteDetailsResponse.setStructure(site.getStructure());
		siteDetailsResponse.setElevation(site.getElevation());
		siteDetailsResponse.setUnit(site.getUnit());

		return siteDetailsResponse;
	}

	public ASiteDetails getASite(Site site) {
		ASiteDetails siteDetailsResponse = new ASiteDetails();
		siteDetailsResponse.setSiteId(site.getSiteId());
		siteDetailsResponse.setSiteName(site.getSiteName());
		siteDetailsResponse.setContact(site.getContactName());
		siteDetailsResponse.setPhone(site.getPhone());
		siteDetailsResponse.setStreet(site.getStreet());
		siteDetailsResponse.setCity(site.getCity());
		siteDetailsResponse.setState(site.getState());
		siteDetailsResponse.setZip(site.getZip());
		siteDetailsResponse.setClli(site.getClli());
		siteDetailsResponse.setFloor(site.getFloor());
		siteDetailsResponse.setRoom(site.getRoom());
		siteDetailsResponse.setStructure(site.getStructure());
		siteDetailsResponse.setElevation(site.getElevation());
		siteDetailsResponse.setUnit(site.getUnit());

		return siteDetailsResponse;
	}

	public ASiteDetails getFiberOrderASite(FiberOrderSite site) {
		ASiteDetails siteDetailsResponse = new ASiteDetails();
		siteDetailsResponse.setSiteId(site.getSiteId());
		siteDetailsResponse.setSiteName(site.getSiteName());
		//siteDetailsResponse.setContact(site.getContactName());
		siteDetailsResponse.setPhone((site.getPhone()!=null?site.getPhone():""));
		siteDetailsResponse.setStreet(site.getStreet());
		siteDetailsResponse.setCity(site.getCity());
		siteDetailsResponse.setState(site.getState());
		siteDetailsResponse.setZip(site.getZip());
		siteDetailsResponse.setClli(site.getClli());
		siteDetailsResponse.setFloor((site.getFloor()!=null?site.getFloor():""));
		siteDetailsResponse.setRoom((site.getRoom()!=null?site.getRoom():""));
		siteDetailsResponse.setStructure((site.getStructure()!=null?site.getStructure():""));
		siteDetailsResponse.setElevation((site.getElevation()!=null?site.getElevation():""));
		siteDetailsResponse.setUnit((site.getUnit()!=null?site.getUnit():""));
		siteDetailsResponse.setType((site.getType()!=null?site.getType():""));
		siteDetailsResponse.setLatitude((site.getLatitude()!=null?site.getLatitude():""));
		siteDetailsResponse.setLongitude((site.getLongitude()!=null?site.getLongitude():""));
		siteDetailsResponse.setSiterraSiteId((site.getSiterraSiteId()!=null?site.getSiterraSiteId():""));
		siteDetailsResponse.setPeoplesoftLocationCode((site.getPeoplesoftLocationCode()!=null?site.getPeoplesoftLocationCode():""));

		return siteDetailsResponse;
	}

	public ZSiteDetails getFiberOrderZSite(FiberOrderSite site) {
		ZSiteDetails siteDetailsResponse = new ZSiteDetails();
		siteDetailsResponse.setSiteId(site.getSiteId());
		siteDetailsResponse.setSiteName(site.getSiteName());
		//siteDetailsResponse.setContact(site.getContactName());
		siteDetailsResponse.setPhone((site.getPhone()!=null?site.getPhone():""));
		siteDetailsResponse.setStreet(site.getStreet());
		siteDetailsResponse.setCity(site.getCity());
		siteDetailsResponse.setState(site.getState());
		siteDetailsResponse.setZip(site.getZip());
		siteDetailsResponse.setClli(site.getClli());
		siteDetailsResponse.setFloor((site.getFloor()!=null?site.getFloor():""));
		siteDetailsResponse.setRoom((site.getRoom()!=null?site.getRoom():""));
		siteDetailsResponse.setStructure((site.getStructure()!=null?site.getStructure():""));
		siteDetailsResponse.setElevation((site.getElevation()!=null?site.getElevation():""));
		siteDetailsResponse.setUnit((site.getUnit()!=null?site.getUnit():""));
		siteDetailsResponse.setType((site.getType()!=null?site.getType():""));
		siteDetailsResponse.setLatitude((site.getLatitude()!=null?site.getLatitude():""));
		siteDetailsResponse.setLongitude((site.getLongitude()!=null?site.getLongitude():""));
		siteDetailsResponse.setSiterraSiteId((site.getSiterraSiteId()!=null?site.getSiterraSiteId():""));
		siteDetailsResponse.setPeoplesoftLocationCode((site.getPeoplesoftLocationCode()!=null?site.getPeoplesoftLocationCode():""));

		return siteDetailsResponse;
	}
}
