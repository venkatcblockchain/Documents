package com.vz.pc.wireless.transport.ordercollection.model;

public class FiberOrderSegment {

	
	private String aSiteId;
	
	private String zSiteId;
	
	private String bandwidth;
	
	private String bandwidthSpeed;

	private String segmentId;
	
	private String segmentName;
	
	private String connectionPoint;
	
	private String circuitNumber;
	
	private String demarc;
	
	private String distanceLimitation;
	
	private String lossLimitation;
	
	private String lecOrderNumber;
	
	private String vendor;

	public String getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(String segmentId) {
		this.segmentId = segmentId;
	}

	public String getSegmentName() {
		return segmentName;
	}

	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}

	public String getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	public String getBandwidthSpeed() {
		return bandwidthSpeed;
	}

	public void setBandwidthSpeed(String bandwidthSpeed) {
		this.bandwidthSpeed = bandwidthSpeed;
	}

	public String getConnectionPoint() {
		return connectionPoint;
	}

	public void setConnectionPoint(String connectionPoint) {
		this.connectionPoint = connectionPoint;
	}

	public String getCircuitNumber() {
		return circuitNumber;
	}

	public void setCircuitNumber(String circuitNumber) {
		this.circuitNumber = circuitNumber;
	}

	public String getzSiteId() {
		return zSiteId;
	}

	public void setzSiteId(String zSiteId) {
		this.zSiteId = zSiteId;
	}

	public String getaSiteId() {
		return aSiteId;
	}

	public void setaSiteId(String aSiteId) {
		this.aSiteId = aSiteId;
	}

	public String getDemarc() {
		return demarc;
	}

	public void setDemarc(String demarc) {
		this.demarc = demarc;
	}

	public String getDistanceLimitation() {
		return distanceLimitation;
	}

	public void setDistanceLimitation(String distanceLimitation) {
		this.distanceLimitation = distanceLimitation;
	}

	public String getLossLimitation() {
		return lossLimitation;
	}

	public void setLossLimitation(String lossLimitation) {
		this.lossLimitation = lossLimitation;
	}

	public String getLecOrderNumber() {
		return lecOrderNumber;
	}

	public void setLecOrderNumber(String lecOrderNumber) {
		this.lecOrderNumber = lecOrderNumber;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
}
