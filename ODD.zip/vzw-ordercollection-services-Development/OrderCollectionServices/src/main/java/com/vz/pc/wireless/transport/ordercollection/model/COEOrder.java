package com.vz.pc.wireless.transport.ordercollection.model;

public class COEOrder {

	@Override
	public String toString() {
		return "FiberOrderDetails [uniqueRequestID=" + uniqueRequestID + ", requestorSystemID=" + requestorSystemID + ", callbackURL=" 
				+ callbackURL +  requestType + ", requestType=" + "]";
	}

	private String uniqueRequestID;

	private String requestType;
	
	private String requestorSystemID;

	private String callbackURL;

	private COEOrderReqPayLoad[] requestPayload;

	public String getUniqueRequestID() {
		return uniqueRequestID;
	}

	public void setUniqueRequestID(String uniqueRequestID) {
		this.uniqueRequestID = uniqueRequestID;
	}

	public String getRequestorSystemID() {
		return requestorSystemID;
	}

	public void setRequestorSystemID(String requestorSystemID) {
		this.requestorSystemID = requestorSystemID;
	}

	public String getCallbackURL() {
		return callbackURL;
	}

	public void setCallbackURL(String callbackURL) {
		this.callbackURL = callbackURL;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public COEOrderReqPayLoad[] getRequestPayload() {
		return requestPayload;
	}

	public void setRequestPayload(COEOrderReqPayLoad[] requestPayload) {
		this.requestPayload = requestPayload;
	}
}
