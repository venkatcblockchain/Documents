package com.vz.pc.wireless.transport.ordercollection.service;

import java.util.List;

import org.springframework.context.annotation.Configuration;

import com.vz.pc.wireless.transport.ordercollection.model.ASiteDetails;
import com.vz.pc.wireless.transport.ordercollection.model.CircuitDetails;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderCircuitDetails;
import com.vz.pc.wireless.transport.ordercollection.model.SegmentDetails;
import com.vz.pc.wireless.transport.ordercollection.model.ZSiteDetails;

@Configuration
public interface CircuitDetailsService {
	

	CircuitDetails getCircuitDetails(String orderNumber);

	FiberOrderCircuitDetails getFiberOrderCircuitDetails(String orderNumber);
	
	List<SegmentDetails> getSegmentDetails(String orderNumber);
	
	FiberOrderCircuitDetails getFiberOrderSegmentDetails(String orderNumber);
	
	List<ASiteDetails> getASiteDetails(String orderNumber);
	
	List<ZSiteDetails> getZSiteDetails(String orderNumber);

}
