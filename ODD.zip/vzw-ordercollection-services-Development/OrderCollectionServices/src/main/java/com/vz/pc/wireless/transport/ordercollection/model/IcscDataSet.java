package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.ArrayList;

public class IcscDataSet {

	private String icsc;
	
	private ArrayList<String> addAcnaList;
	
	private ArrayList<String> delAcnaList;

	private ArrayList<String> addCcnaList;
	
	private ArrayList<String> delCcnaList;

	private String asogFlag;
	
	private String email;

	public String getIcsc() {
		return icsc;
	}

	public void setIcsc(String icsc) {
		this.icsc = icsc;
	}

	public ArrayList<String> getAddAcnaList() {
		return addAcnaList;
	}

	public void setAddAcnaList(ArrayList<String> addAcnaList) {
		this.addAcnaList = addAcnaList;
	}

	public ArrayList<String> getDelAcnaList() {
		return delAcnaList;
	}

	public void setDelAcnaList(ArrayList<String> delAcnaList) {
		this.delAcnaList = delAcnaList;
	}

	public ArrayList<String> getAddCcnaList() {
		return addCcnaList;
	}

	public void setAddCcnaList(ArrayList<String> addCcnaList) {
		this.addCcnaList = addCcnaList;
	}

	public ArrayList<String> getDelCcnaList() {
		return delCcnaList;
	}

	public void setDelCcnaList(ArrayList<String> delCcnaList) {
		this.delCcnaList = delCcnaList;
	}

	public String getAsogFlag() {
		return asogFlag;
	}

	public void setAsogFlag(String asogFlag) {
		this.asogFlag = asogFlag;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "IcscDataSet [icsc=" + icsc + ", addAcnaList=" + addAcnaList + ", delAcnaList=" + delAcnaList
				+ ", addCcnaList=" + addCcnaList + ", delCcnaList=" + delCcnaList + ", asogFlag=" + asogFlag
				+ ", email=" + email + "]";
	}

	
	
	
	
}
