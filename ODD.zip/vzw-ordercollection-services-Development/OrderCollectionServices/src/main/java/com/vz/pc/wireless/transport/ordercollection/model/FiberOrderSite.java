package com.vz.pc.wireless.transport.ordercollection.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FiberOrderSite {

	@Override
	public String toString() {
		return "FiberSite [siteId=" + siteId + ", siteName=" + siteName + ", street=" + street 
				+ ", city=" + city + ", state=" + state + ", zip=" + zip + ", elevation=" + elevation + ", country=" + country
				+ ", endPointType=" + endPointType + ", floor=" + floor + ", phone=" + phone + ", room=" + room + ", structure=" + structure
				+ ", unit=" + unit + ", siterraSiteId=" + siterraSiteId + ", latitude=" + latitude + ", type=" + type + ", longitude=" + longitude + ", siteNFID="+siteNFID+"]";
	}

	private String siteName;
	
	private String type;
	
	//private String status;

	private String siteId;
	
	private String street;
	
	private String city;
	
	private String clli;
	
	private String elevation;  //add in UI
	
	private String endPointType;  //add in UI
	
	private String floor;  //add in UI
	
	private String phone;
	
	private String room;	//add in UI
	
	private String state;
	
	private String zip;
	
	private String country;
	
	private String structure;	//add in UI
	
	private String unit;	//add in UI
	
	private String latitude;
	
	private String longitude;
	
	private String siterraSiteId;
	
	private String peoplesoftLocationCode;
	
	@JsonProperty(value="siteNFID")
	private String siteNFID;
	
	@JsonProperty(value="siteSubType")
	private String siteSubType;
	
	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getClli() {
		return clli;
	}

	public void setClli(String clli) {
		this.clli = clli;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	//public String getStatus() {
	//	return status;
	//}

	//public void setStatus(String status) {
	//	this.status = status;
	//}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getElevation() {
		return elevation;
	}

	public void setElevation(String elevation) {
		this.elevation = elevation;
	}

	public String getEndPointType() {
		return endPointType;
	}

	public void setEndPointType(String endPointType) {
		this.endPointType = endPointType;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public String getStructure() {
		return structure;
	}

	public void setStructure(String structure) {
		this.structure = structure;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getSiterraSiteId() {
		return siterraSiteId;
	}

	public void setSiterraSiteId(String siterraSiteId) {
		this.siterraSiteId = siterraSiteId;
	}

	public String getPeoplesoftLocationCode() {
		return peoplesoftLocationCode;
	}

	public void setPeoplesoftLocationCode(String peoplesoftLocationCode) {
		this.peoplesoftLocationCode = peoplesoftLocationCode;
	}

	public String getSiteNFID() {
		return siteNFID;
	}

	public void setSiteNFID(String siteNFID) {
		this.siteNFID = siteNFID;
	}

	public String getSiteSubType() {
		return siteSubType;
	}

	public void setSiteSubType(String siteSubType) {
		this.siteSubType = siteSubType;
	}
	
}
