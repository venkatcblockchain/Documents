package com.vz.pc.wireless.transport.ordercollection.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.vz.pc.wireless.transport.ordercollection.model.VendorDataSet;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.AcnaCcnaData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.VendorData;

@Service
public interface IVendorIcscDetails {

	public void addVendorIcscDetail(VendorData vendorDataSet);
	
	public void updateVendorDetail(VendorDataSet vendorDataSet);
	
	public void updateVendorDetail(VendorData updVendorData);
	
	public List<VendorData> fetchVendorIcscDetail();
	
	public void removeVendorDetail(VendorData updVendorData);
	
	public void addAcnaccnaData(AcnaCcnaData acnaCcnaData);
	
	public void removeAcnaCcnaData(AcnaCcnaData acnaCcnaData);
		
	public AcnaCcnaData fetchAcnaCcnaDetail();
	
}
