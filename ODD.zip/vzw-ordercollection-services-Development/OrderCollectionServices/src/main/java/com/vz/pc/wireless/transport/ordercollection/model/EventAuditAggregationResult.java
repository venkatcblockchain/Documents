package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Arrays;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import com.vz.pc.wireless.transport.ordercollection.model.Events;

@Document(collection = "eventaudit")
@CompoundIndexes({
    @CompoundIndex(name = "eventAuditCmpdIdx", def = "{'orderNumber' : 1, 'pon' : 1}")
})

public class EventAuditAggregationResult {

	private String orderNumber;
	
	private String pon;
	
	private Events events;

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getPon() {
		return pon;
	}

	public void setPon(String pon) {
		this.pon = pon;
	}

	public Events getEvents() {
		return events;
	}

	public void setEvents(Events events) {
		this.events = events;
	}

	@Override
	public String toString() {
		return "EventAudit [orderNumber=" + orderNumber + ", pon=" + pon + ", events=" + events + "]";
	}
	
	
	
}
