package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.InEventStore;

public interface InEventStoreRepository  extends MongoRepository<InEventStore,Long>{

	public List<InEventStore> findByPcOrderId(long  pcOrderId);
	
	public InEventStore findById(long Id);
	
	
}
