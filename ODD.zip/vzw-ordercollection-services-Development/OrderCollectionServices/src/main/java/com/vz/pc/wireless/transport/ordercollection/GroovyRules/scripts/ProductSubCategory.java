package com.vz.pc.wireless.transport.ordercollection.GroovyRules.scripts;

import com.vz.pc.wireless.transport.ordercollection.model.OrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.PcOrderRequest;
import com.vz.pc.wireless.transport.ordercollection.service.GroovyRuleEngine;

public class ProductSubCategory implements GroovyRuleEngine {

	@Override
	public Object  execute(Object obj, Object obj1) {
		System.out.println("Invoking my method");
		PcOrderRequest pcOrderReq  = new PcOrderRequest();
		OrderDetails orderDetails = new OrderDetails();
		
		if (obj != null && obj instanceof PcOrderRequest) {

			try {
				pcOrderReq= (PcOrderRequest) Class.forName("com.vz.pc.wireless.transport.ordercollection.model.PcOrderRequest").cast(obj);
				orderDetails = (OrderDetails) Class.forName("com.vz.pc.wireless.transport.ordercollection.model.OrderDetails").cast(obj1);
				
				System.out.println("pcOrderReq"+pcOrderReq.toString());
				System.out.println("pcWiteLessOrder"+ orderDetails);
				
				if ( (pcOrderReq.getCategory() == null || pcOrderReq.getCategory().trim().equals(""))
						&& pcOrderReq.getServiceType() != null
						&& ("EBH NE".equals(pcOrderReq.getServiceType()) || "	".equals(pcOrderReq.getServiceType())
								|| "EVPL".equals(pcOrderReq.getServiceType()) || "EMUX".equals(pcOrderReq.getServiceType())
								|| "TLS".equals(pcOrderReq.getServiceType()))
						&& pcOrderReq.getAction() != null && "C".equalsIgnoreCase(pcOrderReq.getAction())) {
					
					System.out.println("inside if "+pcOrderReq.toString());
					if (pcOrderReq.getChangeReason() != null && !pcOrderReq.getChangeReason().trim().equals("")
							&& "EVC".equalsIgnoreCase(pcOrderReq.getChangeReason())) {
						System.out.println("inside thisss");
						orderDetails.setProductSubCategory("EVC");
					} else {
						orderDetails.setProductSubCategory("UNI");
					}

				} else {
					orderDetails.setProductSubCategory(((pcOrderReq.getCategory() == null || pcOrderReq.getCategory().trim().equals(""))) ?pcOrderReq.getServiceType() : pcOrderReq.getCategory());
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return orderDetails;

	}
	
}