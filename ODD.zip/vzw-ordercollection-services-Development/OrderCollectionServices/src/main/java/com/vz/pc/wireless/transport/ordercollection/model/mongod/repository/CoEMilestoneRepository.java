package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.CoEMilestone;
/**
 * 
 * @author PEACJA7
 *
 */
public interface CoEMilestoneRepository extends MongoRepository<CoEMilestone, Long> {

	/**
	 * Do no Change the method name or signature As it aligns with spring data repository & mongo Collection
	 */

	@Query("{'orderNumber' : ?0}}")
	public  Page<CoEMilestone> findByOrderNumberOldest(String orderNumber , Pageable pageable);
		
}
