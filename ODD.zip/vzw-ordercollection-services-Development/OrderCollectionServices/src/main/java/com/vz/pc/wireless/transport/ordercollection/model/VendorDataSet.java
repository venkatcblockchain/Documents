package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.ArrayList;

public class VendorDataSet {

	private String vendor;

	private ArrayList<IcscDataSet> icscList;

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}



	public ArrayList<IcscDataSet> getIcscList() {
		return icscList;
	}

	public void setIcscList(ArrayList<IcscDataSet> icscList) {
		this.icscList = icscList;
	}

	@Override
	public String toString() {
		return "VendorData [vendor=" + vendor + ", icscList=" + icscList + "]";
	}

	
}
