package com.vz.pc.wireless.transport.ordercollection.service;

import java.util.List;
import java.util.concurrent.Future;

import org.codehaus.jettison.json.JSONException;

import com.vz.pc.wireless.transport.ordercollection.model.PcWirelessRemarkRequest;
import com.vz.pc.wireless.transport.ordercollection.model.RemarksResponse;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessRemark;

public interface RemarksService {
	
	public Future<PcWirelessRemark> InsertRemarksInfo(PcWirelessRemarkRequest remarks);
	
	public List<PcWirelessRemark> getRemarksInfoList(String pcOrderId);
	
	public RemarksResponse strikeRemark (PcWirelessRemarkRequest remarks)  throws JSONException;
	
	public RemarksResponse unStrikeRemark(PcWirelessRemarkRequest remarks);

	public List<PcWirelessRemark> getFiberOrderRemarksInfoList(String fiberOrderNumber);
}
