package com.vz.pc.wireless.transport.ordercollection.service.impl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.vz.pc.wireless.transport.ordercollection.Enumerators.PcCEnum;
import com.vz.pc.wireless.transport.ordercollection.exception.DataNotFoundException;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrder;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderSegment;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderSite;
import com.vz.pc.wireless.transport.ordercollection.model.MongoParams;
import com.vz.pc.wireless.transport.ordercollection.model.Order;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.OrderReport;
import com.vz.pc.wireless.transport.ordercollection.model.OrderSearchRequest;
import com.vz.pc.wireless.transport.ordercollection.model.OwnershipDetails;
import com.vz.pc.wireless.transport.ordercollection.model.PcWirlessAsrMilestoneCollection;
import com.vz.pc.wireless.transport.ordercollection.model.Segment;
import com.vz.pc.wireless.transport.ordercollection.model.Site;
import com.vz.pc.wireless.transport.ordercollection.model.UIOrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.AcnaCcnaData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OneFiberOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.TaskInst;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.AcnaCcnaDataRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.CustomAggregationOperation;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.PcWirelessOrderRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.TaskInstRepository;
import com.vz.pc.wireless.transport.ordercollection.service.IOrderDetailsService;

@Component("iOrderDetailService")
@Transactional
public class OrderDetailServiceImpl implements IOrderDetailsService {

	private static Logger logger = LoggerFactory.getLogger(OrderDetailServiceImpl.class);

	@Autowired
	private MongoOperations mongo;

	@Autowired
	private PcWirelessOrderRepository pcWirelessOrderRepository;
	
	@Autowired
	private TaskInstRepository taskInstRepository;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private AcnaCcnaDataRepository acnaccnaRepo;

	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${url.retrieveSiteNFIDUrl}")
	private String retrieveSiteNFIDUrl;

	@Override
	@Async
	public UIOrderDetails getOrderDetails(String orderNumber) {

		logger.debug("Order Detail  [" + orderNumber + "]");

		PcWirelessOrder pcWirelessOrder = pcWirelessOrderRepository.findByOrderOrderNumber(orderNumber);
		UIOrderDetails orderDetails = new UIOrderDetails();

		OrderDetails orderDetail = Optional.ofNullable(pcWirelessOrder.getOrderDetails())
				.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

		Order order = Optional.ofNullable(pcWirelessOrder.getOrder())
				.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderNumber + "] " + "   "));

		List<Segment> segmentList = Arrays.asList(Optional.ofNullable(orderDetail.getSegments()).orElse(null));

		int segSize = 1;
		
		if(segmentList != null){
			
			segSize = 	segmentList.size();
		}
/*		List<Site> sites = Arrays.asList(Optional.ofNullable(orderDetail.getSites()).orElseThrow(
				() -> new DataNotFoundException(null, null, "  No PC Wireless Order Site Details Data  found for [" + pcWirelessOrder.toString() + "]")));

		String controlIcsc = Optional.ofNullable(segmentList.stream().filter(s -> "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().getIcsc())
				.orElseThrow(() -> new DataNotFoundException(null, null,
						"  No PC Wireless Segment  ControlICSC found for   [" + orderDetails.toString() + "] " + "   "));

		String zSiteID = Optional.ofNullable(segmentList.stream().filter(s -> "Y".equalsIgnoreCase(s.getControlICSC())).findFirst().get().getzSiteId())
				.orElseThrow(() -> new DataNotFoundException(null, null,
						"  No PC Wireless Segment  ControlICSC found for   [" + orderDetails.toString() + "] " + "   "));
*/
		String orderStatus = null;
		orderStatus = PcCEnum.OrderStatus.name(PcCEnum.OrderStatus.getValueBygetFieldName(order.getOrderStatus()));
		orderDetails.setOrderStatus(orderStatus);
		orderDetails.setOrderVersion(order.getOrderVersion());
		orderDetails.setOrderNumber(orderNumber);

		orderDetails.setAsog(orderDetail.getAsog());
		orderDetails.setProductCategory(orderDetail.getProductCategory());
		if(Optional.ofNullable(orderDetail.getCustomerDesiredDueDate()).isPresent())
			orderDetails.setCustomerDesiredDueDate(new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault()).format(orderDetail.getCustomerDesiredDueDate()));
		orderDetails.setRegion(orderDetail.getRegion());
		orderDetails.setVendorEmail(segmentList.get(0).getVendorEmail());
		orderDetails.setCcna(orderDetail.getCcna());
		orderDetails.setAcna(orderDetail.getAcna());
		orderDetails.setPon(orderDetail.getPon());
		orderDetails.setCno(orderDetail.getCno());

		if(segSize >1 ){
			orderDetails.setMultiCkt("Y");
		}else{
			orderDetails.setMultiCkt("N");
		}
		orderDetails.setMultiEC(orderDetail.getMultiEC());
		orderDetails.setProjectId(orderDetail.getProjectId());
		orderDetails.setEvcSP(orderDetail.getEvcSP());
		orderDetails.setHotcut(orderDetail.getHotcut());
		orderDetails.setExpedite(orderDetail.getExpedite());
		orderDetails.setServiceType(orderDetail.getServiceType());
		orderDetails.setAction(orderDetail.getOrderType());
		orderDetails.setActionReason(orderDetail.getChangeReasion());
		orderDetails.setActl(orderDetail.getActl());
		orderDetails.setCopyPon(orderDetail.getCopyPon());
		orderDetails.setRelatedPon(orderDetail.getRelatedPon());
		orderDetails.setDisconnectCopyPon(orderDetail.getDisconnectCopyPon());
		orderDetails.setActlCoLocation(orderDetail.getActlCoLocation());
		orderDetails.setTspCode(orderDetail.getTspCode());
		orderDetails.setSpec(orderDetail.getSpec());
		orderDetails.setVzid(orderDetail.getUserId());
		
		logger.info("Persit Order Detail  Request [" + orderNumber + "]");
		return orderDetails;
	}

	public static Date stringToDate(String date) {
		Date d = null;
		String format = "MM-dd-yyyy";
		try {
			d = new SimpleDateFormat(format).parse(date);
		} catch (ParseException e) {
			// Do Nothing. Return null
		}
		return d;

	}

	public static boolean isBlank(String s) {
		return (s == null || s.trim().length() == 0);
	}

	@Override
	public List<UIOrderDetails> getOrderSearchData(OrderSearchRequest orderSearchRequest) {

		logger.debug("Order Detail  [" + orderSearchRequest.getOrderNumber() + "]");


		List<UIOrderDetails> details = new ArrayList<UIOrderDetails>();
		try {
			 
			 Query query2 = new Query();
			 if(Optional.ofNullable(orderSearchRequest.getOrderNumber()).isPresent()  && !orderSearchRequest.getOrderNumber().isEmpty() )  query2.addCriteria(Criteria.where("order.orderNumber").is(orderSearchRequest.getOrderNumber().trim()));
			  if(Optional.ofNullable(orderSearchRequest.getPon() ).isPresent()  && !orderSearchRequest.getPon() .isEmpty()) query2.addCriteria(Criteria.where("orderDetails.pon").is(orderSearchRequest.getPon().trim()));
			  if(Optional.ofNullable(orderSearchRequest.getStatus()).isPresent()  && !orderSearchRequest.getStatus().isEmpty()) query2.addCriteria(Criteria.where("order.orderStatus").in(orderSearchRequest.getStatus()));
			  if(Optional.ofNullable(orderSearchRequest.getProduct()).isPresent() && ! orderSearchRequest.getProduct().isEmpty()) query2.addCriteria(Criteria.where("orderDetails.productCategory").in(orderSearchRequest.getProduct()));
			  if(Optional.ofNullable(orderSearchRequest.getAsog() ).isPresent() && !orderSearchRequest.getAsog() .isEmpty() ) query2.addCriteria(Criteria.where("orderDetails.asog").is(orderSearchRequest.getAsog()));
			  if(Optional.ofNullable(orderSearchRequest.getRegion() ).isPresent() && !orderSearchRequest.getRegion() .isEmpty()) query2.addCriteria(Criteria.where("orderDetails.region").in(orderSearchRequest.getRegion()));
			  if(Optional.ofNullable(orderSearchRequest.getCcna() ).isPresent() && !orderSearchRequest.getCcna().isEmpty()) query2.addCriteria(Criteria.where("orderDetails.ccna").in(orderSearchRequest.getCcna()));
			  if(Optional.ofNullable(orderSearchRequest.getAcna() ).isPresent() && !orderSearchRequest.getAcna() .isEmpty() ) query2.addCriteria(Criteria.where("orderDetails.acna").in(orderSearchRequest.getAcna()));
			  if(Optional.ofNullable(orderSearchRequest.getProject() ).isPresent()  && !orderSearchRequest.getProject() .isEmpty()) query2.addCriteria(Criteria.where("orderDetails.projectId").is(orderSearchRequest.getProject()));
			  if(Optional.ofNullable(orderSearchRequest.getBandwidth()).isPresent() && !orderSearchRequest.getBandwidth().isEmpty()) query2.addCriteria(Criteria.where("orderDetails.segments.bandwidth").in(orderSearchRequest.getBandwidth()));
			  if(Optional.ofNullable(orderSearchRequest.getVendor()).isPresent() && !orderSearchRequest.getVendor().isEmpty()) query2.addCriteria(Criteria.where("orderDetails.segments.vendorCode").in(orderSearchRequest.getVendor()));
			  if(Optional.ofNullable(orderSearchRequest.getIcsc()).isPresent() && !orderSearchRequest.getIcsc().isEmpty()) query2.addCriteria(Criteria.where("orderDetails.segments.icsc").in(orderSearchRequest.getIcsc()));
			  if(Optional.ofNullable(orderSearchRequest.getSegmentId()).isPresent() && !orderSearchRequest.getSegmentId().isEmpty()) query2.addCriteria(Criteria.where("orderDetails.segments.segmentId").is(orderSearchRequest.getSegmentId()));
			  if(Optional.ofNullable(orderSearchRequest.getSiteName()).isPresent() && !orderSearchRequest.getSiteName().isEmpty()) query2.addCriteria(Criteria.where("orderDetails.sites.siteName").is(orderSearchRequest.getSiteName()));
			  if(Optional.ofNullable(orderSearchRequest.getOrderType()).isPresent() && !orderSearchRequest.getOrderType().isEmpty()) query2.addCriteria(Criteria.where("orderDetails.orderType").in(orderSearchRequest.getOrderType()));
			  if(Optional.ofNullable(orderSearchRequest.getCategory()).isPresent() && !orderSearchRequest.getCategory().isEmpty()) query2.addCriteria(Criteria.where("orderDetails.productSubCategory").in(orderSearchRequest.getCategory()));
			  // If a date type is present, only use if there is a start or end date also  
			  if(orderSearchRequest.getDataType() != null && !orderSearchRequest.getDataType().isEmpty() && 
					  ((Optional.ofNullable(orderSearchRequest.getStartDate()).isPresent() && !orderSearchRequest.getStartDate().isEmpty()) || 
							  (Optional.ofNullable(orderSearchRequest.getEndDate()).isPresent() && !orderSearchRequest.getEndDate().isEmpty()))){
			       	Date startDate= null;
			      	Date endDate= null;
			    	if (Optional.ofNullable(orderSearchRequest.getStartDate()).isPresent() && !orderSearchRequest.getStartDate().isEmpty()) {
			    		startDate = stringToDate(orderSearchRequest.getStartDate() + " 00:00:00", "MM-dd-yyyy HH:mm:ss");
			    	}
			    	if (Optional.ofNullable(orderSearchRequest.getEndDate()).isPresent() && !orderSearchRequest.getEndDate().isEmpty()) {
			    		endDate = stringToDate(orderSearchRequest.getEndDate()  + " 23:59:59", "MM-dd-yyyy HH:mm:ss");;
			    	}
			    	
				    if(("Create Date".equals(orderSearchRequest.getDataType())) ){
				    	if (startDate != null && endDate != null) {
				    		query2.addCriteria(Criteria.where("order.createdTime").lte(endDate).andOperator(Criteria.where("order.createdTime").gte(startDate)));
				    	} else if (endDate != null) {
				    		query2.addCriteria(Criteria.where("order.createdTime").lte(endDate));
				    	} else if (startDate != null) {
				    		query2.addCriteria(Criteria.where("order.createdTime").gte(startDate));
				    	}
				    	/*if(!startDate.equals(endDate)){
				      		query2.addCriteria(Criteria.where("order.createdTime").lte(endDate).andOperator(Criteria.where("order.createdTime").gte(startDate)));
				      	}else{
				      		query2.addCriteria(Criteria.where("order.createdTime").gte(endDate));
				      	}*/
				    }
			    }
				List<PcWirelessOrder> pcWirelessOrderDetails = mongo.find(query2, PcWirelessOrder.class);
				logger.info("Search Query from GUI  -- " + query2.toString());

			
				Optional.ofNullable(pcWirelessOrderDetails)
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderSearchRequest.toString() + "] " + "   "));
			
				logger.info("pcWirelessOrderDetails  ["+pcWirelessOrderDetails.toString()+"]");
				
				if(pcWirelessOrderDetails == null || pcWirelessOrderDetails.size()==0){
					return details;
				}
				/** Join Mechanism
				 * Join ASRmilestone table (local)  with PcWireless order table (foreign)**/
				   
				Aggregation aggregation = newAggregation(
					   match(
					        Criteria.where("orderNumber").in(pcWirelessOrderDetails.stream().map(i->i.getOrder().getOrderNumber()).collect(Collectors.toList()))					    ),
					    new CustomAggregationOperation(
					        new BasicDBObject(
					            "$lookup",
					            new BasicDBObject("from", "pcWirelessOrder")
					                .append("localField","orderNumber")
					                .append("foreignField", "order.orderNumber")
					                .append("as", "pcWirelessOrder")
					        )
					    ),	
					    sort(Sort.Direction.DESC, "ponVersion")
					 ,group("orderNumber", "icsc").last("_id").as("transactionId").last("orderNumber").as("orderNumber").last("icsc").as("icsc").
					 last("pon").as("pon").last("ponVersion").as("ponVersion").
					 last("lecDesiredDueDate").as("lecDesiredDueDate").last("asrSendDate").as("asrSendDate").last("ackReceivedDate").as("ackReceivedDate").last("focReceivedDate").as("focReceivedDate").
					 last("focDate").as("focDate").last("pcWirelessOrder").as("pcWirelessOrder") ,
					project("transactionId", "orderNumber" , "icsc" , "pon", "ponVersion", "lecDesiredDueDate" , "asrSendDate" ,"ackReceivedDate" , "focReceivedDate" , "focDate" ,"pcWirelessOrder").andExclude("_id")
					);
				
		//		db.temperature.aggregate([{$sort:{"dt":1}},{$group:{"_id":"$station", result:{$last:"$dt"}, t:{$last:"$t"}}}])
				logger.info("aggreagtion"+aggregation.toString());
				AggregationResults<PcWirlessAsrMilestoneCollection> results1  = mongoTemplate.aggregate(aggregation, "asrmilestone", PcWirlessAsrMilestoneCollection.class);
				System.out.println("results1 "+results1.toString());
				List<PcWirlessAsrMilestoneCollection> mappedResults1 = results1.getMappedResults();
				System.out.println("mappedResults1 "+mappedResults1.toString());

				Optional.ofNullable(mappedResults1)
				.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderSearchRequest.toString() + "] " + "   "));
					
				mappedResults1.stream().forEach(asrmilestone->{
					PcWirelessOrder pcWirelessorder = asrmilestone.getPcWirelessOrder().get(0);
					OrderDetails orderDetailInfo = Optional.ofNullable(pcWirelessorder.getOrderDetails())
							.orElseThrow(() -> new DataNotFoundException(null, null, "No PC Wireless Order Details Data  found for [" + orderSearchRequest.toString() + "] " + "   "));
					Order orderInfo = Optional.ofNullable(pcWirelessorder.getOrder())
							.orElseThrow(() -> new DataNotFoundException(null, null, "No Order  Data  found for [" + orderSearchRequest.toString() + "] " + "   "));
					List<Site> sites = Arrays.asList(Optional.ofNullable(orderDetailInfo.getSites()).orElse(null));
					List<Segment> segments = Arrays.asList(Optional.ofNullable(orderDetailInfo.getSegments()).orElse(null));
					logger.info("orderInfo.getOrderNumber()"+orderInfo.getOrderNumber());
					UIOrderDetails orderDetails = new UIOrderDetails();
					orderDetails.setOrderNumber(orderInfo.getOrderNumber());
					orderDetails.setOrderVersion(orderInfo.getOrderVersion());
					orderDetails.setPon(orderDetailInfo.getPon());
					orderDetails.setAcna(orderDetailInfo.getAcna());
					orderDetails.setCreateDate(DatetoString(orderInfo.getCreatedTime()));
					orderDetails.setOrderType(orderDetailInfo.getOrderType());
					orderDetails.setAction(orderDetailInfo.getOrderType());
					orderDetails.setActionReason(orderDetailInfo.getChangeReasion());
					orderDetails.setAsog(orderDetailInfo.getAsog());
					orderDetails.setCcna(orderDetailInfo.getCcna());
					orderDetails.setActl(orderDetailInfo.getActl());
					orderDetails.setCno(orderDetailInfo.getCno());
					orderDetails.setCopyPon(orderDetailInfo.getCopyPon());
					if(Optional.ofNullable(orderDetailInfo.getCustomerDesiredDueDate()).isPresent()){
						orderDetails.setCustomerDesiredDueDate(dateFormat(orderDetailInfo.getCustomerDesiredDueDate()));
					}
					orderDetails.setEvcSP(orderDetailInfo.getEvcSP());
					orderDetails.setExpedite(orderDetailInfo.getExpedite());
					orderDetails.setProductCategory(orderDetailInfo.getProductCategory());
					orderDetails.setProductSubCategory(orderDetailInfo.getProductCategory());
					orderDetails.setOrderStatus( PcCEnum.OrderStatus.acronym(PcCEnum.OrderStatus.getValueBygetFieldName(orderInfo.getOrderStatus())));
					orderDetails.setRegion(orderDetailInfo.getRegion());
					orderDetails.setArea(getAreaForRegion(orderDetailInfo.getRegion()));
					orderDetails.setProjectId(orderDetailInfo.getProjectId());
					orderDetails.setSpec(orderDetailInfo.getSpec());
					orderDetails.setHotcut(orderDetailInfo.getHotcut());
					orderDetails.setMultiEC(orderDetailInfo.getMultiEC());
					if(segments != null && segments.size()> 1 ){
						orderDetails.setMultiCkt("Y");
					}else{
						orderDetails.setMultiCkt("N");
					}
					orderDetails.setVendorEmail(segments.get(0).getVendorEmail());
					orderDetails.setSegmentName(segments.get(0).getSegmentName());
					orderDetails.setMrc(segments.get(0).getMrc());
					orderDetails.setTspCode(orderDetailInfo.getTspCode());
					orderDetails.setRelatedPon(orderDetailInfo.getRelatedPon());
					orderDetails.setPonVersion(asrmilestone.getPonVersion());
					orderDetails.setFocDueDate(DatetoString(asrmilestone.getFocDate()));
					orderDetails.setLecduedate(DatetoString(asrmilestone.getLecDesiredDueDate()));
					orderDetails.setAckReceivedDate(DatetoString(asrmilestone.getAckReceivedDate()));
					orderDetails.setFocReceivedDate(DatetoString(asrmilestone.getFocReceivedDate()));
					orderDetails.setSentDate(DatetoString(asrmilestone.getAsrSendDate()));
					
					if(Optional.ofNullable(orderSearchRequest.getIcsc()).isPresent() && !orderSearchRequest.getIcsc().isEmpty()) {
						  orderDetails.setIcsc(asrmilestone.getIcsc());
					  }else{
						  orderDetails.setIcsc(asrmilestone.getIcsc());
					  }
					  if(Optional.ofNullable(orderSearchRequest.getSegmentId()).isPresent() && !orderSearchRequest.getSegmentId().isEmpty()) {
						  orderDetails.setSegmentInstaId(orderSearchRequest.getSegmentId());
					  }else{
						  orderDetails.setSegmentInstaId(segments.get(0).getSegmentId());
					  }
					  if(Optional.ofNullable(orderSearchRequest.getBandwidth()).isPresent() && !orderSearchRequest.getBandwidth().isEmpty()) {
						  orderDetails.setBandwidth(segments.get(0).getBandwidth());
					  }else{
						  orderDetails.setBandwidth(segments.get(0).getBandwidth());
					  }
					  if(Optional.ofNullable(orderSearchRequest.getSiteName()).isPresent() && !orderSearchRequest.getSiteName().isEmpty()) {
						  orderDetails.setBandwidth(orderSearchRequest.getSiteName());
					  }else{
						  orderDetails.setSiteName(sites.get(0).getSiteName());
					  }
					  if(Optional.ofNullable(orderSearchRequest.getVendor()).isPresent() && !orderSearchRequest.getVendor().isEmpty()) {
						  orderDetails.setVendorCode(segments.get(0).getVendorCode());
					  }else{
						  orderDetails.setVendorCode(segments.get(0).getVendorCode());
					  }
					details.add(orderDetails);
					
				});
				
			logger.info("details ["+details.toString()+"]");
		} catch (Exception e) {
			logger.info("e ", e);
		}
		return details;
	}

	@Override
	public List<UIOrderDetails> getOneFiberOrderSearchData(OrderSearchRequest orderSearchRequest) {

		logger.debug("Order Detail  [" + orderSearchRequest.getOrderNumber() + "]");


		List<UIOrderDetails> details = new ArrayList<UIOrderDetails>();
		try {
			 
			 Query query2 = new Query();
			if (Optional.ofNullable(orderSearchRequest.getNfid()).isPresent()
					&& !orderSearchRequest.getNfid().isEmpty())
				query2.addCriteria(Criteria.where("coeNFID").regex(Pattern.compile(orderSearchRequest.getNfid().trim(),
						Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE)));
			if (Optional.ofNullable(orderSearchRequest.getOrderNumber()).isPresent()
					&& !orderSearchRequest.getOrderNumber().isEmpty())
				query2.addCriteria(Criteria.where("order.orderNumber").is(orderSearchRequest.getOrderNumber().trim()));
			if (Optional.ofNullable(orderSearchRequest.getStatus()).isPresent()
					&& !orderSearchRequest.getStatus().isEmpty())
				query2.addCriteria(Criteria.where("order.orderStatus").in(orderSearchRequest.getStatus()));
			if (Optional.ofNullable(orderSearchRequest.getProduct()).isPresent()
					&& !orderSearchRequest.getProduct().isEmpty())
				query2.addCriteria(Criteria.where("orderDetails.requestSubType").in(orderSearchRequest.getProduct()));
			if (Optional.ofNullable(orderSearchRequest.getRegion()).isPresent()
					&& !orderSearchRequest.getRegion().isEmpty())
				query2.addCriteria(Criteria.where("orderDetails.region").in(orderSearchRequest.getRegion()));
			if (Optional.ofNullable(orderSearchRequest.getProject()).isPresent()
					&& !orderSearchRequest.getProject().isEmpty())
				query2.addCriteria(Criteria.where("orderDetails.projectId").regex(Pattern
						.compile(orderSearchRequest.getProject(), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE)));
			if (Optional.ofNullable(orderSearchRequest.getBandwidth()).isPresent()
					&& !orderSearchRequest.getBandwidth().isEmpty())
				query2.addCriteria(
						Criteria.where("orderDetails.segments.bandwidth").in(orderSearchRequest.getBandwidth()));
			if (Optional.ofNullable(orderSearchRequest.getSegmentId()).isPresent()
					&& !orderSearchRequest.getSegmentId().isEmpty())
				query2.addCriteria(Criteria.where("orderDetails.segments.segmentId").regex(Pattern
						.compile(orderSearchRequest.getSegmentId(), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE)));
			if (Optional.ofNullable(orderSearchRequest.getSiteName()).isPresent()
					&& !orderSearchRequest.getSiteName().isEmpty())
				query2.addCriteria(Criteria.where("orderDetails.sites.siteName").regex(Pattern
						.compile(orderSearchRequest.getSiteName(), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE)));
			if (Optional.ofNullable(orderSearchRequest.getOrderType()).isPresent()
					&& !orderSearchRequest.getOrderType().isEmpty())
				query2.addCriteria(Criteria.where("orderDetails.orderType").in(orderSearchRequest.getOrderType()));
			  if(orderSearchRequest.getDataType() != null && !orderSearchRequest.getDataType().isEmpty() && 
					  ((Optional.ofNullable(orderSearchRequest.getStartDate()).isPresent() && !orderSearchRequest.getStartDate().isEmpty()) || 
							  (Optional.ofNullable(orderSearchRequest.getEndDate()).isPresent() && !orderSearchRequest.getEndDate().isEmpty()))){
			       	Date startDate= null;
			      	Date endDate= null;
			    	if (Optional.ofNullable(orderSearchRequest.getStartDate()).isPresent() && !orderSearchRequest.getStartDate().isEmpty()) {
			    		startDate = stringToDate(orderSearchRequest.getStartDate() + " 00:00:00", "MM-dd-yyyy HH:mm:ss");
			    	}
			    	if (Optional.ofNullable(orderSearchRequest.getEndDate()).isPresent() && !orderSearchRequest.getEndDate().isEmpty()) {
			    		endDate = stringToDate(orderSearchRequest.getEndDate()  + " 23:59:59", "MM-dd-yyyy HH:mm:ss");;
			    	}
			    	
				    if(("Create Date".equals(orderSearchRequest.getDataType())) ){
				    	if (startDate != null && endDate != null) {
				    		query2.addCriteria(Criteria.where("order.createdTime").lte(endDate).andOperator(Criteria.where("order.createdTime").gte(startDate)));
				    	} else if (endDate != null) {
				    		query2.addCriteria(Criteria.where("order.createdTime").lte(endDate));
				    	} else if (startDate != null) {
				    		query2.addCriteria(Criteria.where("order.createdTime").gte(startDate));
				    	}
				    }
			    }

				List<OneFiberOrder> oneFiberOrderDetails = mongo.find(query2, OneFiberOrder.class);
				logger.info("Search Query from GUI  -- " + query2.toString());

			
				Optional.ofNullable(oneFiberOrderDetails)
					.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderSearchRequest.toString() + "] " + "   "));
			
				logger.info("oneFiberOrderDetails  ["+oneFiberOrderDetails.toString()+"]");
				
				if(oneFiberOrderDetails == null || oneFiberOrderDetails.size()==0){
					return details;
				}
				/** Join Mechanism
				 * Join ASRmilestone table (local)  with PcWireless order table (foreign)**/
				
				Map<String,TaskInst> latestWorklistTaskDetailsMap = getLatestWorklistTaskDetails(oneFiberOrderDetails);
			 
				Aggregation aggregation = newAggregation(
					   match(
					        Criteria.where("orderNumber").in(oneFiberOrderDetails.stream().map(i->i.getOrder().getOrderNumber()).collect(Collectors.toList()))					    ),
					    new CustomAggregationOperation(
					        new BasicDBObject(
					            "$lookup",
					            new BasicDBObject("from", "oneFiberOrder")
					                .append("localField","orderNumber")
					                .append("foreignField", "order.orderNumber")
					                .append("as", "oneFiberOrder")
					        )
					    ),	
					    sort(Sort.Direction.DESC, "orderNumber")
					 ,group("orderNumber").last("_id").as("transactionId").last("orderNumber").as("orderNumber").
					 last("nfid").as("nfid").last("orderVersion").as("orderVersion").
					 last("sentDate").as("sentDate").last("facilityCheckDate").as("facilityCheckDate").last("focDate").as("focDate").last("focReceivedDate").as("focReceivedDate").
					last("oneFiberOrder").as("oneFiberOrder").last("inEffectNotifDate").as("inEffectNotifDate") ,
					project("transactionId", "orderNumber" , "orderVersion" , "nfid", "sentDate" , "facilityCheckDate" ,"focDate" , "focReceivedDate" ,"oneFiberOrder","inEffectNotifDate").andExclude("_id")
					);
				
		//		db.temperature.aggregate([{$sort:{"dt":1}},{$group:{"_id":"$station", result:{$last:"$dt"}, t:{$last:"$t"}}}])
				logger.info("aggreagtion"+aggregation.toString());
				AggregationResults<PcWirlessAsrMilestoneCollection> results1  = mongoTemplate.aggregate(aggregation, "coemilestone", PcWirlessAsrMilestoneCollection.class);
				System.out.println("results1 "+results1.toString());
				List<PcWirlessAsrMilestoneCollection> mappedResults1 = results1.getMappedResults();
				System.out.println("mappedResults1 "+mappedResults1.toString());

				Optional.ofNullable(mappedResults1)
				.orElseThrow(() -> new DataNotFoundException(null, null, "  No PC Wireless Order Details Data  found for [" + orderSearchRequest.toString() + "] " + "   "));

				HashMap<String, String> areaForRegionMap = getAreaForRegionMap();
				mappedResults1.stream().forEach(coemilestone->{
					OneFiberOrder oneFiberOrder = coemilestone.getOneFiberOrder().get(0);
					FiberOrderDetails orderDetailInfo = Optional.ofNullable(oneFiberOrder.getOrderDetails())
							.orElseThrow(() -> new DataNotFoundException(null, null, "No PC Wireless Order Details Data  found for [" + orderSearchRequest.toString() + "] " + "   "));
					FiberOrder orderInfo = Optional.ofNullable(oneFiberOrder.getOrder())
							.orElseThrow(() -> new DataNotFoundException(null, null, "No Order  Data  found for [" + orderSearchRequest.toString() + "] " + "   "));
					List<FiberOrderSite> sites = Arrays.asList(Optional.ofNullable(orderDetailInfo.getSites()).orElse(null));
					List<FiberOrderSegment> segments = Arrays.asList(Optional.ofNullable(orderDetailInfo.getSegments()).orElse(null));
					logger.info("orderInfo.getOrderNumber()"+orderInfo.getOrderNumber());
					UIOrderDetails orderDetails = new UIOrderDetails();
					orderDetails.setOrderNumber(orderInfo.getOrderNumber());
					orderDetails.setOrderVersion(orderInfo.getOrderVersion());
					orderDetails.setCreateDate(DatetoString(orderInfo.getCreatedTime()));
					orderDetails.setOrderType(orderDetailInfo.getOrderType());
					orderDetails.setAction(orderDetailInfo.getOrderType());
					orderDetails.setVzid(orderDetailInfo.getUserId());
					orderDetails.setFirstName(orderDetailInfo.getFirstName());
					orderDetails.setNumberOfCircuits(orderDetailInfo.getNumberOfCircuits());
					orderDetails.setSiteCategory(orderDetailInfo.getSiteCategory());
					String technologyType = (StringUtils.isEmpty(orderDetailInfo.getTechnologyType())) ? "4G" : orderDetailInfo.getTechnologyType();
					orderDetails.setTechnologyType(technologyType);
					orderDetails.setAutomated(!StringUtils.isBlank(oneFiberOrder.getSource()) && "CRAN".equalsIgnoreCase(oneFiberOrder.getSource()));
					if(Optional.ofNullable(orderDetailInfo.getCustomerDesiredDueDate()).isPresent()){
						orderDetails.setCustomerDesiredDueDate(dateFormat(orderDetailInfo.getCustomerDesiredDueDate()));
					}
					orderDetails.setProductCategory(orderDetailInfo.getServiceType());
					orderDetails.setOrderStatus( PcCEnum.OrderStatus.acronym(PcCEnum.OrderStatus.getValueBygetFieldName(orderInfo.getOrderStatus())));
					orderDetails.setRegion(orderDetailInfo.getRegion());
					if (null != areaForRegionMap && areaForRegionMap.containsKey(orderDetailInfo.getRegion())) {
						orderDetails.setArea(areaForRegionMap.get(orderDetailInfo.getRegion()));
					} else {
						orderDetails.setArea(getAreaForRegion(orderDetailInfo.getRegion()));
					}
					orderDetails.setProjectId(orderDetailInfo.getProjectId());
					orderDetails.setFocReceivedDate(DatetoString(coemilestone.getFocReceivedDate()));
					orderDetails.setFocDueDate(DatetoString(coemilestone.getFocDate()));
					orderDetails.setSentDate(DatetoString(coemilestone.getSentDate()));
					orderDetails.setFacilityCheckDate(DatetoString(coemilestone.getFacilityCheckDate()));
					orderDetails.setIneffectDate(DatetoString(coemilestone.getInEffectNotifDate()));
					orderDetails.setNfid(coemilestone.getNfid());

					  if(Optional.ofNullable(orderSearchRequest.getSegmentId()).isPresent() && !orderSearchRequest.getSegmentId().isEmpty()) {
						  orderDetails.setSegmentInstaId(orderSearchRequest.getSegmentId());
					  }else{
						  orderDetails.setSegmentInstaId(segments.get(0).getSegmentId());
					  }
					  if (segments.get(0).getBandwidth().equals("0")) {
				  		orderDetails.setBandwidth("DF");
					  } else {
				  		orderDetails.setBandwidth(segments.get(0).getBandwidth());
					  }
					  orderDetails.setVendorCode(segments.get(0).getVendor());
					  orderDetails.setSiteAId(segments.get(0).getaSiteId());
					  orderDetails.setSiteZId(segments.get(0).getzSiteId());
					  
					  logger.debug("Site A {}::", sites.get(0));
					  orderDetails.setaSiteName(sites.get(0).getSiteName());
					  if (Optional.ofNullable(sites.get(1)).isPresent()) {
						  logger.debug("Site Z {}::", sites.get(1));
						  orderDetails.setzSiteName(sites.get(1).getSiteName());
						  orderDetails.setSiteNFID(sites.get(1).getSiteNFID());
					  }
					  
					String taskName = StringUtils.EMPTY;
					String taskStatus = StringUtils.EMPTY;
					TaskInst latestTask = latestWorklistTaskDetailsMap.get(orderInfo.getOrderNumber());
					if(null != latestTask) {
						taskName = (null != latestTask.getTaskName()) ? latestTask.getTaskName(): StringUtils.EMPTY;
						taskStatus = (null != latestTask.getTaskStatus()) ? latestTask.getTaskStatus(): StringUtils.EMPTY;;	
					}
					orderDetails.setTaskName(taskName);
					orderDetails.setTaskStatus(taskStatus);
				    details.add(orderDetails);
				});
				
			logger.debug("details ["+details.toString()+"]");
		} catch (Exception e) {
			logger.info("e ", e);
		}
		return details;
	}

	private Map<String,TaskInst> getLatestWorklistTaskDetails(List<OneFiberOrder> oneFiberOrderDetails) {
		Map<String,TaskInst> latestWorklistTaskDetailsMap = null;
		Aggregation taskInstAggregation = newAggregation(
				match(Criteria.where("pcORderNumber")
						.in(oneFiberOrderDetails
								.stream().map(i -> i.getOrder().getOrderNumber()).collect(Collectors.toList())).and("taskStatus").ne("COMPLETE")),
				sort(Sort.Direction.DESC, "id"),
				group("pcORderNumber").first("taskName").as("taskName").first("taskStatus").as("taskStatus")
						.first("pcORderNumber").as("pcORderNumber"),
				project("taskName", "taskStatus", "pcORderNumber").andExclude("_id"));
		
		
		 AggregationResults<TaskInst> latestTaskResults = mongoTemplate.aggregate(taskInstAggregation, "taskinst", TaskInst.class);
		 if(null != latestTaskResults) {
			 latestWorklistTaskDetailsMap = new HashMap<String,TaskInst>();
			 for (TaskInst taskInst : latestTaskResults) {
				 latestWorklistTaskDetailsMap.put(taskInst.getPcORderNumber(), taskInst);
			}
		 }
		return latestWorklistTaskDetailsMap;
		 
	}

	private String dateFormat(Date dateRange) {

		SimpleDateFormat mdyFormat = new SimpleDateFormat("MM-dd-yyyy");
		String strDate = mdyFormat.format(dateRange)  ;
		return strDate;
	}

	public static String secondsToDate(long seconds) {

		Date date = new Date(seconds * 1000);
		DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
		return df.format(date);

	}
	/*
	 * public static void main(String[] args) throws Exception { String
	 * startDate = "11-18-2015"; DateFormat df = new
	 * SimpleDateFormat("MM-dd-yyyy"); Date startDate1 = df.parse(startDate);
	 * System.out.println(startDate1); }
	 */

	public static Date stringToDate(String date, String format) {
		Date d = null;

		try {
			d = new SimpleDateFormat(format).parse(date);
		} catch (ParseException e) {
			// Do Nothing. Return null
		}
		return d;
	}
	//EEE MMM dd HH:mm:ss z yyyy
	public static String DatetoString(Date date){
		   DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
           //to convert Date to String, use format method of SimpleDateFormat class.
		   if(date != null &&  !"".equals(date)){
	           String strDate = dateFormat.format(date);
	           return strDate;
		   }
           return null;
	}

	@Override
	@Async
	public OwnershipDetails getOwnershipDetails(String  orderNumber) {

		logger.debug("Order Detail  [" + orderNumber + "]");
		DBCollection collection = mongo.getCollection("pcWirelessOrder");
		OwnershipDetails orderDetails = new OwnershipDetails();
		DBCursor cursorDoc = collection.find();

		while(cursorDoc.hasNext())
		{
			
		    BasicDBObject result = (BasicDBObject) cursorDoc.next();
		 
		    BasicDBObject order = (BasicDBObject) result.get("order");
			 if(order != null){
			    String orderNum= (String) order.get("orderNumber");
			    System.out.println(result);
			    if(!orderNumber.equals(orderNum)){
			    	continue;
			    }
//			    orderDetails.setOrderSource((String) order.get("orderSource"));
			    orderDetails.setOrderSource("VZW");
			    orderDetails.setLob("VZW");
			    orderDetails.setWorkGroup("WIRELESS_PROVISIONING");
			    orderDetails.setWorkPool("W_B_VARng");
			    
			    orderDetails.setOrderNumber(orderNum);
		    }
			 BasicDBObject orderDetail = (BasicDBObject) result.get("orderDetails"); 
			 orderDetails.setCategory((String) orderDetail.get("productCategory"));
			 orderDetails.setSubCategory((String) orderDetail.get("productSubCategory"));
			 orderDetails.setUserId((String) orderDetail.get("userId"));
			 if((String) orderDetail.get("firstName") !=null && (String) orderDetail.get("lastName") != null && !"".equals((String) orderDetail.get("firstName"))&&!"".equals((String) orderDetail.get("lastName"))){
				 orderDetails.setUserName((String) orderDetail.get("firstName") + " " + (String) orderDetail.get("lastName"));
			 }else{
				 orderDetails.setUserName((String) orderDetail.get("userId"));
			 }
		}
		logger.info("Persit Order Detail  Request [" + orderNumber + "]");
		//pcOrderRepo.findByDateRangeAndDateOneAndDateRadiosAndFormSubmitFlagAndPageAndQtypeAndQueryAndRpAndSortnameAndSortorderAndVzid(req.getDateRange(),req.getDateOne(),req.getDateRadios(),req.getFormSubmitFlag(),req.getPage(),req.getQtype(),req.getQuery(),req.getRp(), req.getSortname(), req.getSortorder(), req.getVzid());
        return orderDetails;
	}
	
    public List<OrderReport> getOrderTypeCount() throws Exception {
        Aggregation aggregation = newAggregation(group("orderDetails.orderType").count().as("count"),project("orderDetails.orderType","count"));              
        AggregationResults<OrderReport> results = mongoTemplate.aggregate(aggregation, "pcWirelessOrder", OrderReport.class);
        logger.info("fetchorderTypeCount:"+results.getMappedResults().toString());
        return results.getMappedResults();
 }
    
    
    public List<OrderReport> getRegionCount() throws Exception {
           Aggregation aggregation = newAggregation(group("orderDetails.region").count().as("count"),project("orderDetails.region","count"));              
           AggregationResults<OrderReport> results = mongoTemplate.aggregate(aggregation, "pcWirelessOrder", OrderReport.class);
           logger.info("fetchoregionCount:"+results.getMappedResults().toString());
    return results.getMappedResults();
    }
	
    
    public List<OrderReport> getOrderStatusAndDueDateCount(String regions, String statusAndDueDate) throws Exception {
        String[] strings = regions.split(",");
     List<String> regionsList = Arrays.asList(strings);
        Aggregation aggregation=null;
        if (statusAndDueDate.equals("status")){
        aggregation = newAggregation(match(Criteria.where("orderDetails.region").in(regionsList)),
                      group("order.orderStatus").count().as("count"),project("order.orderStatus","count"));
        }else if(statusAndDueDate.equals("dueDate")){
        aggregation = newAggregation(match(Criteria.where("orderDetails.region").in(regionsList)),
                      group("orderDetails.customerDesiredDueDate").count().as("count"),project("orderDetails.customerDesiredDueDate","count"));                                  
        }
        AggregationResults<OrderReport> results = mongoTemplate.aggregate(aggregation, "pcWirelessOrder", OrderReport.class);
        logger.info("fetchorderStatusAndDueDateCount:"+results.getMappedResults().toString());
        List<OrderReport> mappedResults1 = results.getMappedResults();
        mappedResults1.stream().forEach(e->{
               e.setId(PcCEnum.OrderStatus.acronym(PcCEnum.OrderStatus.getValueBygetFieldName(e.getId())));
        });
 return results.getMappedResults();
 }
	
    
  public String getAreaForRegion(String region){
	  
	AcnaCcnaData acnaCcnaData =   acnaccnaRepo.findByRegionsName(region);
		 if (acnaCcnaData != null && acnaCcnaData.getRegions() != null && acnaCcnaData.getRegions().size()>0)
			return acnaCcnaData.getRegions().stream().filter(s->s.getName().equals(region)).findAny().get().getValue();
		else
			return null;
  }
  
	public HashMap<String, String> getAreaForRegionMap(){
		HashMap<String, String> acnaCcnaDataMap = new HashMap<String, String>();
		List<AcnaCcnaData> acnaCcnaDataList =   acnaccnaRepo.findAll();
		AcnaCcnaData acnaCcnaData = (AcnaCcnaData)acnaCcnaDataList.get(0);
		List<MongoParams> regionsList = acnaCcnaData.getRegions();
		for (MongoParams region:regionsList) {
			if (null != region && null != region.getName() && null != region.getValue()) {
				acnaCcnaDataMap.put(region.getName(), region.getValue());
			}
		}
		return acnaCcnaDataMap;
	}
	
	@Override
	public JSONObject getSiteNFID(String siteInstId) {
		JSONObject siteInstIdJSON = new JSONObject();
		siteInstIdJSON.put("siteInstId", siteInstId);
		JSONObject siteNFID =  new JSONObject();
		try {
			siteNFID = restTemplate.postForObject("http://nj51ntlwda9v.nss.vzwnet.com:8001/getSiteNfid", siteInstIdJSON, JSONObject.class);
		} catch (RestClientException e) {
			e.printStackTrace();
		}
		return siteNFID;
		
	}
}
