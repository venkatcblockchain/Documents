package com.vz.pc.wireless.transport.ordercollection.model;

public class OrderReport {

	private String id;
	
	private long count;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "OrderReport [id=" + id + ", count=" + count + "]";
	}
	
	
}
