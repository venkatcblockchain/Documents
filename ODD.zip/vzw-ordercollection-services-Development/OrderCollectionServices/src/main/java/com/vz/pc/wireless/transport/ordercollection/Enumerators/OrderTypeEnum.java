package com.vz.pc.wireless.transport.ordercollection.Enumerators;

import java.util.HashMap;
import java.util.Map;

public enum OrderTypeEnum {
	Install("N"),
	Change("C"),
	Disconnect("D"), 
	Inquiry("Q"),
	Move("M");

	private static class Holder {
		static Map<String, OrderTypeEnum> MAP = new HashMap<>();
	}
	
	String s;

	private OrderTypeEnum(String s) {
		Holder.MAP.put(s, this);
	}

	
	public static OrderTypeEnum find(String val) {
System.out.println("Holder.MAP"+Holder.MAP.toString() + val);
		OrderTypeEnum t = Holder.MAP.get(val);
		if (t == null) {
			throw new IllegalStateException(String.format("Unsupported type %s.", val));
		}
		return t;
	}
	
	  
	  
}
