package com.vz.pc.wireless.transport.ordercollection.model;

public class UIOrderDetails {

	private String siteAId;
	private String siteZId;
	private String orderNumber;
	private String orderStatus;
	private String orderVersion;
	private String asog;
	private String productCategory;
	private String productSubCategory;
	private String customerDesiredDueDate;
	private String region;
	private String vendorEmail;
	private String ccna;
	private String acna;
	private String pon;
	private String cno;
	private String multiEC;
	private String projectId;
	private String evcSP;
	private String hotcut;
	private String expedite;
	private String serviceType;
	private String action;
	private String actionReason;
	private String actl;
	private String copyPon;
	private String relatedPon;
	private String disconnectCopyPon;
	private String actlCoLocation;
	private String multiCkt;
	private String tspCode;
	private String spec;

	private String orderType;
	private String siteName;
	private String aSiteName;
	private String zSiteName;
	private String segmentName;
	private String segmentInstaId;
	private String bandwidth;
	private String mrc;
	private String ponVersion;
	private String vendorCode;
	private String icsc;
	private String createDate;
	private String siteTypeA;
	private String siteTypeZ;
	private String latitudeA;
	private String longitudeA;
	private String streetA;
	private String cityA;
	private String stateA;
	private String zipA;
	private String countryA;
	private String latitudeZ;
	private String longitudeZ;
	private String streetZ;
	private String cityZ;
	private String stateZ;
	private String zipZ;
	private String countryZ;
	private String siterraSiteIdZ;
	private String peopleSoftLocCdZ;
	private String siterraSiteIdA;
	private String peopleSoftLocCdA;
	private String siteSubType;
	private String siteCategory;
	private String taskName;
	private String taskStatus;
	private String technologyType;
	private boolean automated;

	private String lecOrderNumber;
	public String getSiteNFID() {
		return siteNFID;
	}

	public void setSiteNFID(String siteNFID) {
		this.siteNFID = siteNFID;
	}

	public String getIneffectDate() {
		return ineffectDate;
	}

	public void setIneffectDate(String ineffectDate) {
		this.ineffectDate = ineffectDate;
	}

	private String lecduedate;
	private String ackReceivedDate;
	private String focReceivedDate;
	private String focDueDate;
	private String vzid;
	private String firstName;
	private String lastName;
	private String sentDate;
	private String area;
	private String facilityCheckDate;
	private String nfid;
	private String customerMustHaveDueDate;
	private String numberOfCircuits;
	private String connectionPoint;
	private String distanceLimitation;
	private String lossLimitation;
	private String cranHub;
	private String msc;
	private String diversityType;
	private String relatedOrderNumber;
	private String relatedCircuitId;
	private String dateRecorded;
	private String zNfid;
	private String zSiteClli;
	private String aSiteClli;
	private String siteNFID;
	private String ineffectDate;

	public String getzNfid() {
		return zNfid;
	}

	public void setzNfid(String zNfid) {
		this.zNfid = zNfid;
	}

	public String getSiteTypeA() {
		return siteTypeA;
	}

	public void setSiteTypeA(String siteTypeA) {
		this.siteTypeA = siteTypeA;
	}

	public String getSiteTypeZ() {
		return siteTypeZ;
	}

	public void setSiteTypeZ(String siteTypeZ) {
		this.siteTypeZ = siteTypeZ;
	}

	public String getLatitudeA() {
		return latitudeA;
	}

	public void setLatitudeA(String latitudeA) {
		this.latitudeA = latitudeA;
	}

	public String getLongitudeA() {
		return longitudeA;
	}

	public void setLongitudeA(String longitudeA) {
		this.longitudeA = longitudeA;
	}

	public String getStreetA() {
		return streetA;
	}

	public String getSiteCategory() {
		return siteCategory;
	}

	public void setSiteCategory(String siteCategory) {
		this.siteCategory = siteCategory;
	}

	public void setStreetA(String streetA) {
		this.streetA = streetA;
	}

	public String getCityA() {
		return cityA;
	}

	public void setCityA(String cityA) {
		this.cityA = cityA;
	}

	public String getStateA() {
		return stateA;
	}

	public void setStateA(String stateA) {
		this.stateA = stateA;
	}

	public String getZipA() {
		return zipA;
	}

	public void setZipA(String zipA) {
		this.zipA = zipA;
	}

	public String getCountryA() {
		return countryA;
	}

	public void setCountryA(String countryA) {
		this.countryA = countryA;
	}

	public String getLatitudeZ() {
		return latitudeZ;
	}

	public void setLatitudeZ(String latitudeZ) {
		this.latitudeZ = latitudeZ;
	}

	public String getLongitudeZ() {
		return longitudeZ;
	}

	public void setLongitudeZ(String longitudeZ) {
		this.longitudeZ = longitudeZ;
	}

	public String getStreetZ() {
		return streetZ;
	}

	public void setStreetZ(String streetZ) {
		this.streetZ = streetZ;
	}

	public String getCityZ() {
		return cityZ;
	}

	public void setCityZ(String cityZ) {
		this.cityZ = cityZ;
	}

	public String getStateZ() {
		return stateZ;
	}

	public void setStateZ(String stateZ) {
		this.stateZ = stateZ;
	}

	public String getZipZ() {
		return zipZ;
	}

	public void setZipZ(String zipZ) {
		this.zipZ = zipZ;
	}

	public String getCountryZ() {
		return countryZ;
	}

	public void setCountryZ(String countryZ) {
		this.countryZ = countryZ;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderVersion() {
		return orderVersion;
	}

	public void setOrderVersion(String orderVersion) {
		this.orderVersion = orderVersion;
	}

	public String getAsog() {
		return asog;
	}

	public void setAsog(String asog) {
		this.asog = asog;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getCustomerDesiredDueDate() {
		return customerDesiredDueDate;
	}

	public void setCustomerDesiredDueDate(String customerDesiredDueDate) {
		this.customerDesiredDueDate = customerDesiredDueDate;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getVendorEmail() {
		return vendorEmail;
	}

	public void setVendorEmail(String vendorEmail) {
		this.vendorEmail = vendorEmail;
	}

	public String getCcna() {
		return ccna;
	}

	public void setCcna(String ccna) {
		this.ccna = ccna;
	}

	public String getAcna() {
		return acna;
	}

	public void setAcna(String acna) {
		this.acna = acna;
	}

	public String getPon() {
		return pon;
	}

	public void setPon(String pon) {
		this.pon = pon;
	}

	public String getCno() {
		return cno;
	}

	public void setCno(String cno) {
		this.cno = cno;
	}

	public String getMultiEC() {
		return multiEC;
	}

	public void setMultiEC(String multiEC) {
		this.multiEC = multiEC;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getEvcSP() {
		return evcSP;
	}

	public void setEvcSP(String evcSP) {
		this.evcSP = evcSP;
	}

	public String getHotcut() {
		return hotcut;
	}

	public void setHotcut(String hotcut) {
		this.hotcut = hotcut;
	}

	public String getExpedite() {
		return expedite;
	}

	public void setExpedite(String expedite) {
		this.expedite = expedite;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getActionReason() {
		return actionReason;
	}

	public void setActionReason(String actionReason) {
		this.actionReason = actionReason;
	}

	public String getActl() {
		return actl;
	}

	public void setActl(String actl) {
		this.actl = actl;
	}

	public String getCopyPon() {
		return copyPon;
	}

	public void setCopyPon(String copyPon) {
		this.copyPon = copyPon;
	}

	public String getRelatedPon() {
		return relatedPon;
	}

	public void setRelatedPon(String relatedPon) {
		this.relatedPon = relatedPon;
	}

	public String getDisconnectCopyPon() {
		return disconnectCopyPon;
	}

	public void setDisconnectCopyPon(String disconnectCopyPon) {
		this.disconnectCopyPon = disconnectCopyPon;
	}

	public String getActlCoLocation() {
		return actlCoLocation;
	}

	public void setActlCoLocation(String actlCoLocation) {
		this.actlCoLocation = actlCoLocation;
	}

	public String getMultiCkt() {
		return multiCkt;
	}

	public void setMultiCkt(String multiCkt) {
		this.multiCkt = multiCkt;
	}

	public String getTspCode() {
		return tspCode;
	}

	public void setTspCode(String tspCode) {
		this.tspCode = tspCode;
	}

	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public String getSiteSubType() {
		return siteSubType;
	}

	public void setSiteSubType(String siteSubType) {
		this.siteSubType = siteSubType;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	/**
	 * @return the orderType
	 */
	public String getOrderType() {
		return orderType;
	}

	/**
	 * @param orderType
	 *            the orderType to set
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	/**
	 * @return the siteName
	 */
	public String getSiteName() {
		return siteName;
	}

	/**
	 * @param siteName
	 *            the siteName to set
	 */
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	/**
	 * @return the segmentName
	 */
	public String getSegmentName() {
		return segmentName;
	}

	/**
	 * @param segmentName
	 *            the segmentName to set
	 */
	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}

	/**
	 * @return the segmentInstaId
	 */
	public String getSegmentInstaId() {
		return segmentInstaId;
	}

	/**
	 * @param segmentInstaId
	 *            the segmentInstaId to set
	 */
	public void setSegmentInstaId(String segmentInstaId) {
		this.segmentInstaId = segmentInstaId;
	}

	/**
	 * @return the bandwidth
	 */
	public String getBandwidth() {
		return bandwidth;
	}

	/**
	 * @param bandwidth
	 *            the bandwidth to set
	 */
	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	/**
	 * @return the mrc
	 */
	public String getMrc() {
		return mrc;
	}

	/**
	 * @param mrc
	 *            the mrc to set
	 */
	public void setMrc(String mrc) {
		this.mrc = mrc;
	}

	/**
	 * @return the ponVersion
	 */
	public String getPonVersion() {
		return ponVersion;
	}

	/**
	 * @param ponVersion
	 *            the ponVersion to set
	 */
	public void setPonVersion(String ponVersion) {
		this.ponVersion = ponVersion;
	}

	/**
	 * @return the vendorCode
	 */
	public String getVendorCode() {
		return vendorCode;
	}

	/**
	 * @param vendorCode
	 *            the vendorCode to set
	 */
	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	/**
	 * @return the icsc
	 */
	public String getIcsc() {
		return icsc;
	}

	/**
	 * @param icsc
	 *            the icsc to set
	 */
	public void setIcsc(String icsc) {
		this.icsc = icsc;
	}

	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate
	 *            the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the lecOrderNumber
	 */
	public String getLecOrderNumber() {
		return lecOrderNumber;
	}

	/**
	 * @param lecOrderNumber
	 *            the lecOrderNumber to set
	 */
	public void setLecOrderNumber(String lecOrderNumber) {
		this.lecOrderNumber = lecOrderNumber;
	}

	/**
	 * @return the lecduedate
	 */
	public String getLecduedate() {
		return lecduedate;
	}

	/**
	 * @param lecduedate
	 *            the lecduedate to set
	 */
	public void setLecduedate(String lecduedate) {
		this.lecduedate = lecduedate;
	}

	/**
	 * @return the ackReceivedDate
	 */
	public String getAckReceivedDate() {
		return ackReceivedDate;
	}

	/**
	 * @param ackReceivedDate
	 *            the ackReceivedDate to set
	 */
	public void setAckReceivedDate(String ackReceivedDate) {
		this.ackReceivedDate = ackReceivedDate;
	}

	/**
	 * @return the focReceivedDate
	 */
	public String getFocReceivedDate() {
		return focReceivedDate;
	}

	/**
	 * @param focReceivedDate
	 *            the focReceivedDate to set
	 */
	public void setFocReceivedDate(String focReceivedDate) {
		this.focReceivedDate = focReceivedDate;
	}

	/**
	 * @return the focDueDate
	 */
	public String getFocDueDate() {
		return focDueDate;
	}

	/**
	 * @param focDueDate
	 *            the focDueDate to set
	 */
	public void setFocDueDate(String focDueDate) {
		this.focDueDate = focDueDate;
	}

	/**
	 * @return the vzid
	 */
	public String getVzid() {
		return vzid;
	}

	/**
	 * @param vzid
	 *            the vzid to set
	 */
	public void setVzid(String vzid) {
		this.vzid = vzid;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the sentDate
	 */
	public String getSentDate() {
		return sentDate;
	}

	/**
	 * @param sentDate
	 *            the sentDate to set
	 */
	public void setSentDate(String sentDate) {
		this.sentDate = sentDate;
	}

	public String getProductSubCategory() {
		return productSubCategory;
	}

	public void setProductSubCategory(String productSubCategory) {
		this.productSubCategory = productSubCategory;
	}

	public String getFacilityCheckDate() {
		return facilityCheckDate;
	}

	public void setFacilityCheckDate(String facilityCheckDate) {
		this.facilityCheckDate = facilityCheckDate;
	}

	public String getNfid() {
		return nfid;
	}

	public void setNfid(String nfid) {
		this.nfid = nfid;
	}

	public String getCustomerMustHaveDueDate() {
		return customerMustHaveDueDate;
	}

	public void setCustomerMustHaveDueDate(String customerMustHaveDueDate) {
		this.customerMustHaveDueDate = customerMustHaveDueDate;
	}

	public String getNumberOfCircuits() {
		return numberOfCircuits;
	}

	public void setNumberOfCircuits(String numberOfCircuits) {
		this.numberOfCircuits = numberOfCircuits;
	}

	public String getConnectionPoint() {
		return connectionPoint;
	}

	public void setConnectionPoint(String connectionPoint) {
		this.connectionPoint = connectionPoint;
	}

	public String getDistanceLimitation() {
		return distanceLimitation;
	}

	public void setDistanceLimitation(String distanceLimitation) {
		this.distanceLimitation = distanceLimitation;
	}

	public String getLossLimitation() {
		return lossLimitation;
	}

	public void setLossLimitation(String lossLimitation) {
		this.lossLimitation = lossLimitation;
	}

	public String getCranHub() {
		return cranHub;
	}

	public void setCranHub(String cranHub) {
		this.cranHub = cranHub;
	}

	public String getMsc() {
		return msc;
	}

	public void setMsc(String msc) {
		this.msc = msc;
	}

	public String getDiversityType() {
		return diversityType;
	}

	public void setDiversityType(String diversityType) {
		this.diversityType = diversityType;
	}

	public String getRelatedOrderNumber() {
		return relatedOrderNumber;
	}

	public void setRelatedOrderNumber(String relatedOrderNumber) {
		this.relatedOrderNumber = relatedOrderNumber;
	}

	public String getRelatedCircuitId() {
		return relatedCircuitId;
	}

	public void setRelatedCircuitId(String relatedCircuitId) {
		this.relatedCircuitId = relatedCircuitId;
	}

	public String getzSiteName() {
		return zSiteName;
	}

	public void setzSiteName(String zSiteName) {
		this.zSiteName = zSiteName;
	}

	public String getaSiteName() {
		return aSiteName;
	}

	public void setaSiteName(String aSiteName) {
		this.aSiteName = aSiteName;
	}

	public String getDateRecorded() {
		return dateRecorded;
	}

	public void setDateRecorded(String dateRecorded) {
		this.dateRecorded = dateRecorded;
	}

	public String getSiteAId() {
		return siteAId;
	}

	public void setSiteAId(String siteAId) {
		this.siteAId = siteAId;
	}

	public String getSiteZId() {
		return siteZId;
	}

	public void setSiteZId(String siteZId) {
		this.siteZId = siteZId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UIOrderDetails [siteAId=");
		builder.append(siteAId);
		builder.append(", siteZId=");
		builder.append(siteZId);
		builder.append(", orderNumber=");
		builder.append(orderNumber);
		builder.append(", orderStatus=");
		builder.append(orderStatus);
		builder.append(", orderVersion=");
		builder.append(orderVersion);
		builder.append(", asog=");
		builder.append(asog);
		builder.append(", productCategory=");
		builder.append(productCategory);
		builder.append(", productSubCategory=");
		builder.append(productSubCategory);
		builder.append(", customerDesiredDueDate=");
		builder.append(customerDesiredDueDate);
		builder.append(", region=");
		builder.append(region);
		builder.append(", vendorEmail=");
		builder.append(vendorEmail);
		builder.append(", ccna=");
		builder.append(ccna);
		builder.append(", acna=");
		builder.append(acna);
		builder.append(", pon=");
		builder.append(pon);
		builder.append(", cno=");
		builder.append(cno);
		builder.append(", multiEC=");
		builder.append(multiEC);
		builder.append(", projectId=");
		builder.append(projectId);
		builder.append(", evcSP=");
		builder.append(evcSP);
		builder.append(", hotcut=");
		builder.append(hotcut);
		builder.append(", expedite=");
		builder.append(expedite);
		builder.append(", serviceType=");
		builder.append(serviceType);
		builder.append(", action=");
		builder.append(action);
		builder.append(", actionReason=");
		builder.append(actionReason);
		builder.append(", actl=");
		builder.append(actl);
		builder.append(", copyPon=");
		builder.append(copyPon);
		builder.append(", relatedPon=");
		builder.append(relatedPon);
		builder.append(", disconnectCopyPon=");
		builder.append(disconnectCopyPon);
		builder.append(", actlCoLocation=");
		builder.append(actlCoLocation);
		builder.append(", multiCkt=");
		builder.append(multiCkt);
		builder.append(", tspCode=");
		builder.append(tspCode);
		builder.append(", spec=");
		builder.append(spec);
		builder.append(", orderType=");
		builder.append(orderType);
		builder.append(", siteName=");
		builder.append(siteName);
		builder.append(", aSiteName=");
		builder.append(aSiteName);
		builder.append(", zSiteName=");
		builder.append(zSiteName);
		builder.append(", segmentName=");
		builder.append(segmentName);
		builder.append(", segmentInstaId=");
		builder.append(segmentInstaId);
		builder.append(", bandwidth=");
		builder.append(bandwidth);
		builder.append(", mrc=");
		builder.append(mrc);
		builder.append(", ponVersion=");
		builder.append(ponVersion);
		builder.append(", vendorCode=");
		builder.append(vendorCode);
		builder.append(", icsc=");
		builder.append(icsc);
		builder.append(", createDate=");
		builder.append(createDate);
		builder.append(", siteTypeA=");
		builder.append(siteTypeA);
		builder.append(", siteTypeZ=");
		builder.append(siteTypeZ);
		builder.append(", latitudeA=");
		builder.append(latitudeA);
		builder.append(", longitudeA=");
		builder.append(longitudeA);
		builder.append(", streetA=");
		builder.append(streetA);
		builder.append(", cityA=");
		builder.append(cityA);
		builder.append(", stateA=");
		builder.append(stateA);
		builder.append(", zipA=");
		builder.append(zipA);
		builder.append(", countryA=");
		builder.append(countryA);
		builder.append(", siterraSiteIdA=");
		builder.append(siterraSiteIdA);
		builder.append(", peopleSoftLocCdA=");
		builder.append(peopleSoftLocCdA);
		builder.append(", latitudeZ=");
		builder.append(latitudeZ);
		builder.append(", longitudeZ=");
		builder.append(longitudeZ);
		builder.append(", streetZ=");
		builder.append(streetZ);
		builder.append(", cityZ=");
		builder.append(cityZ);
		builder.append(", stateZ=");
		builder.append(stateZ);
		builder.append(", zipZ=");
		builder.append(zipZ);
		builder.append(", countryZ=");
		builder.append(countryZ);
		builder.append(", siterraSiteIdZ=");
		builder.append(siterraSiteIdZ);
		builder.append(", peopleSoftLocCdZ=");
		builder.append(peopleSoftLocCdZ);
		builder.append(", siteSubType=");
		builder.append(siteSubType);
		builder.append(", siteCategory=");
		builder.append(siteCategory);
		builder.append(", lecOrderNumber=");
		builder.append(lecOrderNumber);
		builder.append(", lecduedate=");
		builder.append(lecduedate);
		builder.append(", ackReceivedDate=");
		builder.append(ackReceivedDate);
		builder.append(", focReceivedDate=");
		builder.append(focReceivedDate);
		builder.append(", focDueDate=");
		builder.append(focDueDate);
		builder.append(", vzid=");
		builder.append(vzid);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", sentDate=");
		builder.append(sentDate);
		builder.append(", area=");
		builder.append(area);
		builder.append(", facilityCheckDate=");
		builder.append(facilityCheckDate);
		builder.append(", nfid=");
		builder.append(nfid);
		builder.append(", customerMustHaveDueDate=");
		builder.append(customerMustHaveDueDate);
		builder.append(", numberOfCircuits=");
		builder.append(numberOfCircuits);
		builder.append(", connectionPoint=");
		builder.append(connectionPoint);
		builder.append(", distanceLimitation=");
		builder.append(distanceLimitation);
		builder.append(", lossLimitation=");
		builder.append(lossLimitation);
		builder.append(", cranHub=");
		builder.append(cranHub);
		builder.append(", msc=");
		builder.append(msc);
		builder.append(", diversityType=");
		builder.append(diversityType);
		builder.append(", relatedOrderNumber=");
		builder.append(relatedOrderNumber);
		builder.append(", relatedCircuitId=");
		builder.append(relatedCircuitId);
		builder.append(", dateRecorded=");
		builder.append(dateRecorded);
		builder.append(", zNfid=");
		builder.append(zNfid);
		builder.append("]");
		return builder.toString();
	}

	public String getSiterraSiteIdZ() {
		return siterraSiteIdZ;
	}

	public void setSiterraSiteIdZ(String siterraSiteIdZ) {
		this.siterraSiteIdZ = siterraSiteIdZ;
	}

	public String getPeopleSoftLocCdZ() {
		return peopleSoftLocCdZ;
	}

	public void setPeopleSoftLocCdZ(String peopleSoftLocCdZ) {
		this.peopleSoftLocCdZ = peopleSoftLocCdZ;
	}

	public String getSiterraSiteIdA() {
		return siterraSiteIdA;
	}

	public void setSiterraSiteIdA(String siterraSiteIdA) {
		this.siterraSiteIdA = siterraSiteIdA;
	}

	public String getPeopleSoftLocCdA() {
		return peopleSoftLocCdA;
	}

	public void setPeopleSoftLocCdA(String peopleSoftLocCdA) {
		this.peopleSoftLocCdA = peopleSoftLocCdA;
	}

	public String getzSiteClli() {
		return zSiteClli;
	}

	public void setzSiteClli(String zSiteClli) {
		this.zSiteClli = zSiteClli;
	}

	public String getaSiteClli() {
		return aSiteClli;
	}

	public void setaSiteClli(String aSiteClli) {
		this.aSiteClli = aSiteClli;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getTechnologyType() {
		return technologyType;
	}

	public void setTechnologyType(String technologyType) {
		this.technologyType = technologyType;
	}

	public boolean isAutomated() {
		return automated;
	}

	public void setAutomated(boolean automated) {
		this.automated = automated;
	}

}
