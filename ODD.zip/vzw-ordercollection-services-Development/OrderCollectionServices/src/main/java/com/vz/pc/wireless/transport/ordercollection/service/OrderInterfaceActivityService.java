package com.vz.pc.wireless.transport.ordercollection.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.vz.pc.wireless.transport.ordercollection.model.OrderInOutResponse;

@Service
public interface OrderInterfaceActivityService {
	Map<String ,Object> getOrderInOutEventsInfo(String pcOrderId) throws Exception;
	String updateOrderInOrOutEvents(OrderInOutResponse orderInOutResponse);
}
