package com.vz.pc.wireless.transport.ordercollection.validator;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.vz.pc.wireless.transport.ordercollection.model.PcWirelessRemarkRequest;

@Configuration
public class RemarksDetailsValidator implements Validator{
	
	private static Logger logger = LoggerFactory.getLogger(RemarksDetailsValidator.class);

	@Override
	public boolean supports(Class<?> clazz) {
		return PcWirelessRemarkRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		PcWirelessRemarkRequest request = (PcWirelessRemarkRequest) target;
		

		if (request == null) {
			logger.info("Validating If Remarks Request is Empty", request);
			errors.rejectValue("RemarksRequest", "RemarksRequest", "Empty request");
		}
		
		if(request.getModifiedDate() != null && request.getModifiedDate().trim().length() == 0){
			logger.info("Requested Modified Date Length is:", 0);
			errors.rejectValue("Modified Date", "Modified Date.invalid", new Object[] { request.getModifiedDate() }, "Modified Date " + request.getModifiedDate() + "  should be 1 character long");
		}
		
		if(request.getModifiedBy() != null && request.getModifiedBy().trim().length() == 0){
			logger.info("Requested Modified By Length is:", 0);
			errors.rejectValue("Modified By", "Modified By.invalid", new Object[] { request.getModifiedDate() },
					"[ " + request.getModifiedDate() + " ] should be 1 character long");
		}
		
		if(request.getNotesRemarksText() != null && request.getNotesRemarksText().trim().length() == 0){
			logger.info("Requested NotesRemarks Text Length is:", 0);
			errors.rejectValue("NotesRemarks Text", "NotesRemarks Text.invalid", new Object[] { request.getNotesRemarksText() },
					"[ " + request.getNotesRemarksText() + " ] should be 1 character long");
		}
		
		if(request.getPcOrderId() != null && request.getPcOrderId() ==  0){
			logger.info("Requested pc orderid should be greater than :", 0);
			errors.rejectValue("pc orderid", "pc orderid.invalid", new Object[] { request.getPcOrderId() },
					"[ " + request.getPcOrderId() + " ] should be greater than 0");
		}
		
		if(request.getStrikeFlag() != null && request.getStrikeFlag().trim().length() ==  0){
			logger.info("Requested strikeflag Length is :", 0);
			errors.rejectValue("strikeflag", "strikeflag.invalid", new Object[] { request.getStrikeFlag() },
					"[ " + request.getStrikeFlag() + " ] should be 1 character long");
		}
		
		if(request.getTaskName() != null && request.getTaskName().trim().length() ==  0){
			logger.info("Requested taskname Length is :", 0);
			errors.rejectValue("taskname", "taskname.invalid", new Object[] { request.getTaskName() },
					"[ " + request.getTaskName() + " ] should be 1 character long");
		}
		
	}

}

