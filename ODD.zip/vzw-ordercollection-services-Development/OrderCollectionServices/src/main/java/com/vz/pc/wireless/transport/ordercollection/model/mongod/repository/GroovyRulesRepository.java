package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.GroovyRules;


public interface GroovyRulesRepository  extends MongoRepository<GroovyRules, String>{
	

	@Query("{'scriptName' : ?0}")
	public GroovyRules findByScriptName(String scriptName);
	
	
	
}

