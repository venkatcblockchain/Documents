package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Date;

public class Events {

private String pon;	
	
public String getPon() {
	return pon;
}

public void setPon(String pon) {
	this.pon = pon;
}

private String ponVersion ;

private String eventName ;

private Date eventCreationTime;

private String notes;

private String userId;

public String getPonVersion() {
	return ponVersion;
}

public void setPonVersion(String ponVersion) {
	this.ponVersion = ponVersion;
}

public String getEventName() {
	return eventName;
}

public void setEventName(String eventName) {
	this.eventName = eventName;
}

public Date getEventCreationTime() {
	return eventCreationTime;
}

public void setEventCreationTime(Date eventCreationTime) {
	this.eventCreationTime = eventCreationTime;
}

public String getNotes() {
	return notes;
}

public void setNotes(String notes) {
	this.notes = notes;
}

public String getUserId() {
	return userId;
}

public void setUserId(String userId) {
	this.userId = userId;
}

@Override
public String toString() {
	return "Events [pon=" + pon + ", ponVersion=" + ponVersion + ", eventName=" + eventName + ", eventCreationTime="
			+ eventCreationTime + ", notes=" + notes + ", userId=" + userId + "]";
}

	
}
