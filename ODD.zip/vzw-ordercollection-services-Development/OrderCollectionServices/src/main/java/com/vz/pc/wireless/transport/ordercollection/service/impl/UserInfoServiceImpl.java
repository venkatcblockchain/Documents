package com.vz.pc.wireless.transport.ordercollection.service.impl;

import org.springframework.stereotype.Component;

import com.vz.pc.wireless.transport.ordercollection.model.User;
import com.vz.pc.wireless.transport.ordercollection.service.UserInfoService;

@Component("userInfoService")
public class UserInfoServiceImpl implements UserInfoService {

	  private User user;
	  
	  public void setUserInfo(User pUser) {
	    this.user = pUser;    
	  }

	  public User getUserInfo() {
	    return this.user;
	  }  
	  
	}