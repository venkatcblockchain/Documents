package com.vz.pc.wireless.transport.ordercollection.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vz.pc.wireless.transport.ordercollection.Enumerators.PcCEnum;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrder;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderDetails;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderRequest;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderSegment;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderSite;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OneFiberOrder;

public class FiberOrderUtils {
	
	private final static Logger logger = LoggerFactory.getLogger(FiberOrderUtils.class.getName());
	
	public static OneFiberOrder prepareOneFiberOrder(FiberOrderRequest fiberOrderReq, long orderid){
		OneFiberOrder oneFiberOrder = new OneFiberOrder();

		oneFiberOrder.setId(orderid);
		oneFiberOrder.setCoeOrderCreated("");
		oneFiberOrder.setCoeNFID("");
		oneFiberOrder.setSource(fiberOrderReq.getSource());

		FiberOrder order = new FiberOrder();
		order.setOrderNumber(orderid + "");
		order.setOrderSource(PcCEnum.OrderSource.VZW);  //TODO: Verify if the value is correct
		order.setOrderStatus("A");  //TODO: Verify if the value is correct
		order.setCreatedTime(new Timestamp(new Date().getTime()));
		order.setLastUpdatedTime(new Timestamp(new Date().getTime()));
		order.setWorkId(-11);  //TODO: Verify if the value is correct
		order.setOrderVersion(" ");  //TODO: Verify if the value is correct

		FiberOrderDetails orderDetails = new FiberOrderDetails();
		orderDetails.setCktRows("");  //TODO: Verify what value to be set
		if (!isBlank(fiberOrderReq.getRequestedDate())) {
			orderDetails.setCustomerDesiredDueDate(stringToDate(fiberOrderReq.getRequestedDate(), "MM/dd/yyyy"));
		}
		if (!isBlank(fiberOrderReq.getMustHaveDate())) {
			orderDetails.setCustomerMustHaveDueDate(stringToDate(fiberOrderReq.getMustHaveDate(), "MM/dd/yyyy"));
		}

		orderDetails.setDomain("");	//TODO: Verify what value to be set
		orderDetails.setFirstName(fiberOrderReq.getName());
		orderDetails.setOrderType(fiberOrderReq.getOrderType());
		orderDetails.setProjectId(fiberOrderReq.getProjectId());
		orderDetails.setRegion(fiberOrderReq.getRegion());
		orderDetails.setSubMarket(fiberOrderReq.getSubMarket());
		orderDetails.setNumberOfCircuits(fiberOrderReq.getStrands());
		orderDetails.setCranHub(fiberOrderReq.getCranHub());
		orderDetails.setMsc(fiberOrderReq.getMsc());
		orderDetails.setRelatedCircuitId(fiberOrderReq.getRelatedCircuitId());
		if(!StringUtils.isEmpty(fiberOrderReq.getRelatedOrderNumber())) {
			orderDetails.setRelatedOrderNumber(fiberOrderReq.getRelatedOrderNumber().trim());
		}
		
		
		String reqType = fiberOrderReq.getRequestType();
		if (null !=reqType && reqType.equalsIgnoreCase("BH")) {
			orderDetails.setDiversityType(fiberOrderReq.getDiversityType());
		}
		orderDetails.setServiceType(reqType);
		orderDetails.setReason(fiberOrderReq.getDisconnectReason());
		logger.info("OrderCollection Service -> Saving disconnect order -> Reason for disconnect :: {}", fiberOrderReq.getDisconnectReason());
		orderDetails.setRequestSubType(fiberOrderReq.getRequestSubType());
		if(null != fiberOrderReq.getSource() && "CRAN".equalsIgnoreCase(fiberOrderReq.getSource()) && StringUtils.isEmpty(fiberOrderReq.getTechnologyType())) {
			fiberOrderReq.setTechnologyType("4G");
		}
		orderDetails.setTechnologyType(fiberOrderReq.getTechnologyType());

		FiberOrderSegment fiberOrderSegment = new FiberOrderSegment();
		FiberOrderSite siteA = fiberOrderReq.getSiteA();
		FiberOrderSite sitez = fiberOrderReq.getSiteZ();
		fiberOrderSegment.setaSiteId(siteA.getSiteId());
		fiberOrderSegment.setzSiteId(sitez.getSiteId());
		fiberOrderSegment.setBandwidth(fiberOrderReq.getBandWidth());
		fiberOrderSegment.setBandwidthSpeed("");	//TODO: Verify what value to be set
		fiberOrderSegment.setSegmentId(fiberOrderReq.getSegmentId());
		fiberOrderSegment.setSegmentName(fiberOrderReq.getSegmentName()); //Segment name in case of Disconnect order
		fiberOrderSegment.setConnectionPoint(fiberOrderReq.getConnectionPoint());
		fiberOrderSegment.setCircuitNumber(fiberOrderReq.getCircuitNumber());
		fiberOrderSegment.setDemarc("");	   //TODO: This needs to value of demarc received from COE
		fiberOrderSegment.setDistanceLimitation(fiberOrderReq.getDistance());
		fiberOrderSegment.setLossLimitation(fiberOrderReq.getLoss());
		fiberOrderSegment.setLecOrderNumber("");	   //TODO: This needs to value of NFDI received from COE
		fiberOrderSegment.setVendor(fiberOrderReq.getVendor());

		FiberOrderSite fiberOrderSiteA = new FiberOrderSite();
		FiberOrderSite reqSiteA = fiberOrderReq.getSiteA();
		fiberOrderSiteA.setCity(reqSiteA.getCity());
		fiberOrderSiteA.setClli(reqSiteA.getClli());
		fiberOrderSiteA.setElevation(reqSiteA.getElevation());
		fiberOrderSiteA.setEndPointType(reqSiteA.getEndPointType());
		fiberOrderSiteA.setFloor(reqSiteA.getFloor());
		fiberOrderSiteA.setPhone(reqSiteA.getPhone());
		fiberOrderSiteA.setRoom(reqSiteA.getRoom());
		fiberOrderSiteA.setSiteId(reqSiteA.getSiteId());
		fiberOrderSiteA.setSiteName(reqSiteA.getSiteName());
		fiberOrderSiteA.setSiteNFID(reqSiteA.getSiteNFID());
		fiberOrderSiteA.setStreet(reqSiteA.getStreet());
		fiberOrderSiteA.setZip(reqSiteA.getZip());
		fiberOrderSiteA.setState(reqSiteA.getState());
		fiberOrderSiteA.setCountry(reqSiteA.getCountry());
		fiberOrderSiteA.setStructure(reqSiteA.getStructure());
		fiberOrderSiteA.setType(reqSiteA.getType());
		fiberOrderSiteA.setUnit(reqSiteA.getUnit());
		fiberOrderSiteA.setLatitude(reqSiteA.getLatitude());
		fiberOrderSiteA.setLongitude(reqSiteA.getLongitude());
		fiberOrderSiteA.setSiterraSiteId(reqSiteA.getSiterraSiteId());
		fiberOrderSiteA.setPeoplesoftLocationCode(reqSiteA.getPeoplesoftLocationCode());
		
		
		FiberOrderSite fiberOrderSiteZ = new FiberOrderSite();
		FiberOrderSite reqSitez = fiberOrderReq.getSiteZ();
		fiberOrderSiteZ.setCity(reqSitez.getCity());
		fiberOrderSiteZ.setClli(reqSitez.getClli());
		fiberOrderSiteZ.setElevation(reqSitez.getElevation());
		fiberOrderSiteZ.setEndPointType(reqSitez.getEndPointType());
		fiberOrderSiteZ.setFloor(reqSitez.getFloor());
		fiberOrderSiteZ.setPhone(reqSitez.getPhone());
		fiberOrderSiteZ.setRoom(reqSitez.getRoom());
		fiberOrderSiteZ.setSiteId(reqSitez.getSiteId());
		fiberOrderSiteZ.setSiteName(reqSitez.getSiteName());
		fiberOrderSiteZ.setSiteNFID(reqSitez.getSiteNFID());
		fiberOrderSiteZ.setStreet(reqSitez.getStreet());
		fiberOrderSiteZ.setZip(reqSitez.getZip());
		fiberOrderSiteZ.setState(reqSitez.getState());
		fiberOrderSiteZ.setCountry(reqSitez.getCountry());
		fiberOrderSiteZ.setStructure(reqSitez.getStructure());
		fiberOrderSiteZ.setType(reqSitez.getType());
		fiberOrderSiteZ.setUnit(reqSitez.getUnit());
		fiberOrderSiteZ.setLatitude(reqSitez.getLatitude());
		fiberOrderSiteZ.setLongitude(reqSitez.getLongitude());
		fiberOrderSiteZ.setSiterraSiteId(reqSitez.getSiterraSiteId());
		fiberOrderSiteZ.setPeoplesoftLocationCode(reqSitez.getPeoplesoftLocationCode());
		fiberOrderSiteZ.setSiteSubType(reqSitez.getSiteSubType());
		
		String siteCategory = fiberOrderReq.getSiteCategory();
		if(StringUtils.isEmpty(siteCategory)) {
			int noOfStrands = (!StringUtils.isEmpty(fiberOrderReq.getStrands())) ? Integer.parseInt(fiberOrderReq.getStrands()) : 0;
			if(StringUtils.isEmpty(reqSitez.getSiteSubType())) {
				if(noOfStrands <=8 && noOfStrands > 0) {
					siteCategory = ApplicationConstants.CELL_SITE_TYPE_MICRO;
				}else if(noOfStrands <=24 && noOfStrands > 8){
					siteCategory = ApplicationConstants.CELL_SITE_TYPE_MACRO;
				}
			}else {
				if(noOfStrands <=12 && noOfStrands > 0) {
					siteCategory = ApplicationConstants.CELL_SITE_TYPE_MICRO_5G;
				}else if(noOfStrands <=36 && noOfStrands > 12){
					siteCategory = ApplicationConstants.CELL_SITE_TYPE_MACRO_5G;
				}
			}
		}
		orderDetails.setSiteCategory(siteCategory);

		String comments = fiberOrderReq.getComments();
		if (!StringUtils.isEmpty(comments)) {
			comments = (comments.length()>200) ? comments.substring(0, 199): comments; 
			comments = comments.trim().replaceAll("[\\n\\t ]", "");
		}
		orderDetails.setComments(comments);
		orderDetails.setUserEmail(fiberOrderReq.getUserEmail());
		orderDetails.setUserPhone(fiberOrderReq.getPhone());
		orderDetails.setUserId(fiberOrderReq.getUserId());

		orderDetails.setSegments(new FiberOrderSegment[] {fiberOrderSegment});
		orderDetails.setSites(new FiberOrderSite[]{fiberOrderSiteA,fiberOrderSiteZ});
		oneFiberOrder.setOrder(order);
		oneFiberOrder.setOrderDetails(orderDetails);
		oneFiberOrder.setCoeAssignmentCreated(false);
		return oneFiberOrder;
		
	}

	public static Date stringToDate(String date, String format) {
		Date d = null;

		try {
			d = new SimpleDateFormat(format).parse(date);
		} catch (ParseException e) {
			logger.error("",e);
		}
		return d;
	}

	public static boolean isBlank(String s) {
		return (s == null || s.trim().length() == 0);
	}

}