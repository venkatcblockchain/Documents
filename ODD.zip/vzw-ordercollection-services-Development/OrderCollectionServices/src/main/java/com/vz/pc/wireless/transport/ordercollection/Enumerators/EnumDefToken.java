package com.vz.pc.wireless.transport.ordercollection.Enumerators;

public class EnumDefToken
{
  public Object  value;
  public String  name;
  public String  acronym;
  public EnumDef aggregator;

  public EnumDefToken(int v, String n, String a)
  {
    this(new Integer(v), n, a, null);
  }

  public EnumDefToken(Object v, String n, String a)
  {
    this(v, n, a, null);
  }

  public EnumDefToken(Object v, String n, String a, EnumDef p)
  {
    value       = v;
    name        = n;
    acronym     = a;
    aggregator  = p;
  }

  public Object getValue()   { return value;   }
  public String getName()    { return name;    }
  public String getAcronym() { return acronym; }

  public String toString()   { return name;    }

  public int hashCode()
  {
    if(value!=null)
     return value.hashCode();
    else
     return hashCode();
  }

}
// -EOF-


