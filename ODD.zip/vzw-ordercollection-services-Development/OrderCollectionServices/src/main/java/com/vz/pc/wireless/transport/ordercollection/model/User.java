package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Date;
import java.util.List;

public class User {

	
	public static final String COL_USER_ID = "USER_ID";
	public static final String COL_FIRST_NAME = "FIRST_NAME";
	public static final String COL_LAST_NAME = "LAST_NAME";
	public static final String COL_MIDDLE_NAME = "MIDDLE_NAME";
	public static final String COL_USER_TYPE = "USER_TYPE";
	public static final String COL_EMAIL_ADDR = "EMAIL_ADDR";
	public static final String COL_CREATION_DATE = "CREATION_DATE";
	public static final String COL_LAST_MODIFIED_DATE = "LAST_MODIFIED_DATE";
	
	public User(String userId) {
		this.userId = userId;
	}

	public User() {
	}

	/** Used for gtting User from Header */
	public static final String HEADER_KEY = "user";

	private String userId;
	private String firstName;
	private String lastName;
	private String middleName;
	private String userType;
 	private String email;
 	private String universalId;
 	private String eid;
	private Date creationDate;
	private Date lastModifiedDate;

	private List<String> privileges;

	private List<String> roles;
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<String> getPrivileges() {
		return privileges;
	}

	public void setPrivileges(List<String> privileges) {
		this.privileges = privileges;
	}

	public String getUniversalId() {
		return universalId;
	}

	public void setUniversalId(String universalId) {
		this.universalId = universalId;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("User [userId=");
		builder.append(userId);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", middleName=");
		builder.append(middleName);
		builder.append(", userType=");
		builder.append(userType);
		builder.append(", email=");
		builder.append(email);
		builder.append(", universalId=");
		builder.append(universalId);
		builder.append(", eid=");
		builder.append(eid);
		builder.append(", creationDate=");
		builder.append(creationDate);
		builder.append(", lastModifiedDate=");
		builder.append(lastModifiedDate);
		builder.append(", privileges=");
		builder.append(privileges);
		builder.append("]");
		return builder.toString();
	}

}
