package com.vz.pc.wireless.transport.ordercollection.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.vz.pc.wireless.transport.ordercollection.model.OrderInOutResponse;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.InEventStore;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OutEventStore;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.InEventStoreRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.OutEventStoreRepository;
import com.vz.pc.wireless.transport.ordercollection.service.OrderInterfaceActivityService;

@Service
public class OrderInterfaceActivityServiceImpl implements OrderInterfaceActivityService {
	private static Logger logger = LoggerFactory.getLogger(OrderInterfaceActivityServiceImpl.class);

	@Autowired
	private MongoOperations mongo;
	
	@Autowired
	private OutEventStoreRepository outStore;
	
	@Autowired
	private InEventStoreRepository inStore;
	

	@Async
	@Override
	public Map<String ,Object> getOrderInOutEventsInfo(String pcOrderId) throws Exception{
		
		Map<String ,Object> map=new HashMap<String ,Object>();
		map.put("OrderInEvents", getOrderInEventsInfo(pcOrderId));
		map.put("OrderOutEvents", getOrderOutEventsInfo(pcOrderId));
		return map;
	}

	@Async
	public List<OrderInOutResponse> getOrderInEventsInfo(String pcOrderId) throws Exception {

		logger.info("OrderIn Events for orderNumber ["+ pcOrderId+"]");
		List<OrderInOutResponse> OrderInEvents = new ArrayList<OrderInOutResponse>();
		try {

			List<InEventStore> ineventStoreList = inStore.findByPcOrderId(Long.parseLong(pcOrderId));
			if (ineventStoreList != null && ineventStoreList.size() > 0) {

				ineventStoreList.stream().forEach(events -> {
					OrderInOutResponse orderInOutResponse = new OrderInOutResponse();
					orderInOutResponse.setActionType(events.getActionType());
					orderInOutResponse.setPcOrderId(events.getPcOrderId());
					orderInOutResponse.setEventName(events.getEventName());
					orderInOutResponse.setSequence(events.getSequence());
					orderInOutResponse.setCreateTime(events.getCreateTime().toDate());

					orderInOutResponse.setSourceSystem(events.getSourceSystem());
					orderInOutResponse.setDestSystem(events.getDestSystem());
					orderInOutResponse.setEventType("inEvent");
					orderInOutResponse.setDbObject(events.getDbObject());
					orderInOutResponse.setId(events.getId());
					OrderInEvents.add(orderInOutResponse);
				});
			}

		}

		catch (Exception e) {
			e.printStackTrace();
			logger.info("Order In Events  List Generation failed due to error[" + e + "]");
			throw e;
		}

		logger.debug("Order In Events   List Generated  ["+ OrderInEvents.toString()+"]");
		return OrderInEvents;
	}
	
	@Async
	public List<OrderInOutResponse> getOrderOutEventsInfo(String pcOrderId) throws Exception {

		logger.info("Order  Outeventstore Service is Initiated  for Order number ["+pcOrderId+"]");
		List<OrderInOutResponse> orderOutEvents = new ArrayList<OrderInOutResponse>();
		try {

			List<OutEventStore> outeventStoreList = outStore.findByPcOrderId(Long.parseLong(pcOrderId));
			if (outeventStoreList != null && outeventStoreList.size() > 0) {
				outeventStoreList.stream().forEach(events -> {
					OrderInOutResponse orderInOutResponse = new OrderInOutResponse();
					orderInOutResponse.setActionType(events.getActionType());
					orderInOutResponse.setPcOrderId(events.getPcOrderId());
					orderInOutResponse.setEventName(events.getEventName());
					orderInOutResponse.setSequence(events.getSequence());

					orderInOutResponse.setCreateTime(events.getCreateTime().toDate());

					orderInOutResponse.setSourceSystem(events.getSourceSystem());
					orderInOutResponse.setDestSystem(events.getDestSystem());
					orderInOutResponse.setEventType("inEvent");
					orderInOutResponse.setDbObject(events.getDbObject());
					orderInOutResponse.setId(events.getId());
					orderOutEvents.add(orderInOutResponse);
				});
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			logger.info("Order Cards List Generation failed due to error[" + e + "]");
			throw e;
		}
		logger.debug("Order Out Events   List Generated  ["+ orderOutEvents.toString()+"]");
		return orderOutEvents;
	}
	

	public static Map<Object, Object> toMap(JSONObject object) throws JSONException {
	    Map<Object, Object> map = new HashMap<Object, Object>();

	    Iterator<String> keysItr = object.keys();
	    while(keysItr.hasNext()) {
	        String key = keysItr.next();
	        Object value = object.get(key);

	        if(value instanceof JSONArray) {
	            value = toList((JSONArray) value);
	        }

	        else if(value instanceof JSONObject) {
	            value = toMap((JSONObject) value);
	        }
	        map.put(key, value);
	    }
	    return map;
	}
	
	public static List<Object> toList(JSONArray array) throws JSONException {
	    List<Object> list = new ArrayList<Object>();
	    for(int i = 0; i < array.length(); i++) {
	        Object value = array.get(i);
	        if(value instanceof JSONArray) {
	            value = toList((JSONArray) value);
	        }

	        else if(value instanceof JSONObject) {
	            value = toMap((JSONObject) value);
	        }
	        list.add(value);
	    }
	    return list;
	}
	@Async
	private BasicDBObject queryOrderObj(DBCursor cursorDoc) {

		logger.info("Order Obj fetching from mongoDB Initiated");
		BasicDBObject result = null;
		try {
			result = (BasicDBObject) cursorDoc.next();
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Order Obj fetched from mongoDB is failed");
			throw e;
		}
		logger.info("Order Obj fetched from mongoDB Successfull");
		return result;

	}
	
	@Async
	@Override
	public String updateOrderInOrOutEvents(OrderInOutResponse orderInOutResponse) {
		String status = "";
		if(orderInOutResponse.getEventType().equalsIgnoreCase("inEvent")){
			InEventStore inEventStore = new InEventStore();
			inEventStore.setPcOrderId(orderInOutResponse.getPcOrderId());
			inEventStore.setEventName(orderInOutResponse.getEventName());
			inEventStore.setSequence(orderInOutResponse.getSequence());
			inEventStore.setCreateTime(new DateTime());
			inEventStore.setSourceSystem(orderInOutResponse.getSourceSystem());
			inEventStore.setDestSystem(orderInOutResponse.getDestSystem());
			inEventStore.setActionType(orderInOutResponse.getActionType());
			inEventStore.setId(orderInOutResponse.getId());
			inEventStore.setDbObject(orderInOutResponse.getDbObject());
			inEventStore.setTaskId(orderInOutResponse.getTaskId());
			inStore.save(inEventStore);
			
			status="success";
		}else if(orderInOutResponse.getEventType().equalsIgnoreCase("outEvent")){
			OutEventStore outEventStore = new OutEventStore();
			outEventStore.setPcOrderId(orderInOutResponse.getPcOrderId());
			outEventStore.setEventName(orderInOutResponse.getEventName());
			outEventStore.setSequence(orderInOutResponse.getSequence());
			outEventStore.setCreateTime(new DateTime());
			outEventStore.setSourceSystem(orderInOutResponse.getSourceSystem());
			outEventStore.setDestSystem(orderInOutResponse.getDestSystem());
			outEventStore.setActionType(orderInOutResponse.getActionType());
			outEventStore.setId(orderInOutResponse.getId());
			outEventStore.setTaskId(orderInOutResponse.getTaskId());
			logger.info("orderInOutResponse ["+orderInOutResponse.toString()+"]");

			outStore.save(outEventStore);
			status="success";
		}
		
		
		
	return status;	
	}
	private String dateFormat(Date dateRange){
		
		  SimpleDateFormat mdyFormat = new SimpleDateFormat("MM-dd-yyyy");
		  String strDate = mdyFormat.format(dateRange);
		  return strDate;
	}
	
}
