package com.vz.pc.wireless.transport.ordercollection.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.GroovyRules;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.GroovyRulesRepository;
import com.vz.pc.wireless.transport.ordercollection.service.GroovyRuleService;

@Component
public class GroovyRuleServiceImpl implements GroovyRuleService {

	@Autowired
	GroovyRulesRepository groovyRulesRepository;

	@Override
	public GroovyRules getGroovyRule(String scriptName) {
		
	String scriptDesc = null;
	
	System.out.println("ScriptName"+scriptName);	
return  groovyRulesRepository.findByScriptName(scriptName);
	
	}

}
