package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.List;

public class CircuitDetails{
	
	List<SegmentDetails> segmentDetails;
	
/*	List<ASiteDetails> asiteDetails;
	
	List<ZSiteDetails> zsiteDetails;*/

	public List<SegmentDetails> getSegmentDetails() {
		return segmentDetails;
	}

	public void setSegmentDetails(List<SegmentDetails> segmentDetails) {
		this.segmentDetails = segmentDetails;
	}

/*	public List<ASiteDetails> getAsiteDetails() {
		return asiteDetails;
	}

	public void setAsiteDetails(List<ASiteDetails> asiteDetails) {
		this.asiteDetails = asiteDetails;
	}

	public List<ZSiteDetails> getZsiteDetails() {
		return zsiteDetails;
	}

	public void setZsiteDetails(List<ZSiteDetails> zsiteDetails) {
		this.zsiteDetails = zsiteDetails;
	}*/

}
