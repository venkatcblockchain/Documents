package com.vz.pc.wireless.transport.ordercollection.model;

public class MongoParams {

	private String name;
	
	private String value;
	
	private String teritory;
	
	

	public String getTeritory() {
		return teritory;
	}

	public void setTeritory(String teritory) {
		this.teritory = teritory;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}


	@Override
	public String toString() {
		return "MongoParams [name=" + name + ", value=" + value + ", teritory=" + teritory + "]";
	}
	
}
