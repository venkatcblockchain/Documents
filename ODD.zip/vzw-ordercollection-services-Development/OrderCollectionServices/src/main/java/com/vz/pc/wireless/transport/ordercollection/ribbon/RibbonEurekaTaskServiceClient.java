package com.vz.pc.wireless.transport.ordercollection.ribbon;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.common.collect.Maps;
import com.vz.pc.wireless.transport.ordercollection.feign.TaskServiceClient;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.TaskInst;

@Service("ribbonTaskServiceClient")
public class RibbonEurekaTaskServiceClient implements TaskServiceClient {

    @Autowired
    @LoadBalanced
    private RestTemplate loadBalanced;


	@Override
	public String create(TaskInst taskInst) {
		   HttpEntity<TaskInst> requestEntity = new HttpEntity<>(taskInst);
	        ResponseEntity<String> response =  this.loadBalanced.exchange("http://vzw-task-service/service/load/task", HttpMethod.POST, requestEntity, String.class, Maps.newHashMap());
	        return response.getBody();
	}


	@Override
	public TaskInst update(TaskInst taskInst) {
		  HttpEntity<TaskInst> requestEntity = new HttpEntity<>(taskInst);
	        ResponseEntity<TaskInst> response =  this.loadBalanced.exchange("http://vzw-task-service/service/update/task", HttpMethod.POST, requestEntity, TaskInst.class, Maps.newHashMap());
	        return response.getBody();
	}

}
