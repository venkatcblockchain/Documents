package com.vz.pc.wireless.transport.ordercollection.service;

import java.util.concurrent.Future;

import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.vz.pc.wireless.transport.ordercollection.model.PcOrderRequest;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;

@Service
public interface IOrderCollectionService {

	public Future<PcWirelessOrder> createPCOrder(PcOrderRequest pcOrderReq);
	public String updateOrderDetails(String orderNumber,String userId ,  String   firstName ,   String   lastName,   String   userEmail);
}
