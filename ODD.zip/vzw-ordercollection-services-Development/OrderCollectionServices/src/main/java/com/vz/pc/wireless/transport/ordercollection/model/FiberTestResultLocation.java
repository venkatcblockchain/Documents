package com.vz.pc.wireless.transport.ordercollection.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FiberTestResultLocation {

	
	private String Loss_1310;
	private String Loss_1550;
	private String ORL_1310;
	private String ORL_1550;
	
	
	@JsonProperty(value ="Loss_1310")
	public String getLoss_1310() {
		return Loss_1310;
	}
	@JsonProperty(value ="Loss_1310")
	public void setLoss_1310(String loss_1310) {
		Loss_1310 = loss_1310;
	}
	@JsonProperty(value ="Loss_1550")
	public String getLoss_1550() {
		return Loss_1550;
	}
	@JsonProperty(value ="Loss_1550")
	public void setLoss_1550(String loss_1550) {
		Loss_1550 = loss_1550;
	}
	@JsonProperty(value ="ORL_1310")
	public String getORL_1310() {
		return ORL_1310;
	}
	@JsonProperty(value ="ORL_1310")
	public void setORL_1310(String oRL_1310) {
		ORL_1310 = oRL_1310;
	}
	@JsonProperty(value ="ORL_1550")

	public String getORL_1550() {
		return ORL_1550;
	}
	@JsonProperty(value ="ORL_1550")

	public void setORL_1550(String oRL_1550) {
		ORL_1550 = oRL_1550;
	}
	@Override
	public String toString() {
		return "FiberTestResultLocation [Loss_1310=" + Loss_1310 + ", Loss_1550=" + Loss_1550 + ", ORL_1310=" + ORL_1310
				+ ", ORL_1550=" + ORL_1550 + "]";
	}
	
	
}
