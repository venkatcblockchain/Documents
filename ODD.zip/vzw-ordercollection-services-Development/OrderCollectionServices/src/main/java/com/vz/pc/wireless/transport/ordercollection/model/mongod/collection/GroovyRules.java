package com.vz.pc.wireless.transport.ordercollection.model.mongod.collection;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "groovyRules")
public class GroovyRules {

	private String scriptName;
	
	private List<String> 	scriptDesc;

	public String getScriptName() {
		return scriptName;
	}

	public void setScriptName(String scriptName) {
		this.scriptName = scriptName;
	}

	public List<String> getScriptDesc() {
		return scriptDesc;
	}

	public void setScriptDesc(List<String> scriptDesc) {
		this.scriptDesc = scriptDesc;
	}
	
		
	
}
