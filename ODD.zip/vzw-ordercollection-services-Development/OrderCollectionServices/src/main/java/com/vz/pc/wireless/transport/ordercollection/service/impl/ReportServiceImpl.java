package com.vz.pc.wireless.transport.ordercollection.service.impl;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;

import com.mongodb.BasicDBObject;
import com.vz.pc.wireless.transport.ordercollection.Enumerators.PcCEnum;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetailReport;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetailRequest;
import com.vz.pc.wireless.transport.ordercollection.model.PcWirlessAsrMilestoneCollection;
import com.vz.pc.wireless.transport.ordercollection.model.PcWirlessTaskCollection;
import com.vz.pc.wireless.transport.ordercollection.model.TaskDetailReport;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.CustomAggregationOperation;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.PcWirelessOrderRepository;
import com.vz.pc.wireless.transport.ordercollection.service.IReportService;


@Component("iReportService")
public class ReportServiceImpl  implements IReportService{

	@Autowired
	private MongoTemplate mongoTemplate;
	
	@ Autowired
	 PcWirelessOrderRepository pcwirelessOrderRepo;
	 
	
	@Override
	public List<OrderDetailReport> getOrderDetailsReport(OrderDetailRequest orderReq) {

		String vzId = orderReq.getVzid()== null?"":orderReq.getVzid();

		List<String> orderNumList = getPcWirelessOrderList( orderReq);

		/** Join Mechanism
		 * Join ASRmilestone table (local)  with PcWireless order table (foreign)**/
		
		Aggregation aggregation = newAggregation(
			   match(
			        Criteria.where("orderNumber").in(orderNumList)
			    ),
			    new CustomAggregationOperation(
			        new BasicDBObject(
			            "$lookup",
			            new BasicDBObject("from", "pcWirelessOrder")
			                .append("localField","orderNumber")
			                .append("foreignField", "order.orderNumber")
			                .append("as", "pcWirelessOrder")
			        )
			    ),		
			    sort(Sort.Direction.DESC, "ponVersion")
				);
		
		AggregationResults<PcWirlessAsrMilestoneCollection> results1  = mongoTemplate.aggregate(aggregation, "asrmilestone", PcWirlessAsrMilestoneCollection.class);
		System.out.println("results1 "+results1.toString());
		List<PcWirlessAsrMilestoneCollection> mappedResults1 = results1.getMappedResults();
		System.out.println("mappedResults1 "+mappedResults1.toString());

		  List<OrderDetailReport> orderDetailsReportNew= 	mappedResults1.stream().map(i->
		new OrderDetailReport (
				  i.getPcWirelessOrder().get(0).getOrderDetails().getRegion(),
				  i.getPcWirelessOrder().get(0).getOrder().getOrderNumber(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getOrderType(),
				  PcCEnum.OrderStatus.name(PcCEnum.OrderStatus.getValueBygetFieldName(  i.getPcWirelessOrder().get(0).getOrder().getOrderStatus())),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSites()[0].getSiteName(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getTspCode(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getSegmentName(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getSegmentId(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getBandwidth(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getMrc(),
				  i.getPon(),
				  i.getPonVersion(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getProductCategory(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getProjectId(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getIcsc(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getVendorCode(),
				  i.getPcWirelessOrder().get(0).getOrder().getCreatedTime(),//null,i.get("pcWirelessOrder.order.createdTime").toString(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getCustomerDesiredDueDate(),
				  i.getAsrSendDate(),
				  i.getLecOrderNumber(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getCcna(),
				  i.getLecDesiredDueDate(),
				  i.getAckReceivedDate(),
				  i.getFocReceivedDate()
				  ,i.getFocDate(),
				  vzId,
				  null,
				  null				 
				)).filter(vzCheck-> (vzId !=null && vzCheck.getVZID().equals(vzId) || "".equals(vzId) || "admin".equals(vzId))).collect(Collectors.toList());
		  System.out.println("orderDetailsReports ["+orderDetailsReportNew+"]");
		
		return orderDetailsReportNew;
	}

	
	
	public List<TaskDetailReport> getTaskDetailsReport(OrderDetailRequest orderReq) {

		String vzId = orderReq.getVzid()== null?"":orderReq.getVzid();
		List<String> orderNumList = getPcWirelessOrderList( orderReq);

		/** Join Mechanism**/
		Aggregation aggregation = newAggregation(
			   match(
			        Criteria.where("pcORderNumber").in(orderNumList).and("uteTaskId").exists(true).and("taskStatus").ne("COMPLETE").and("taskStatus").ne("NEW")
			    ),
			    new CustomAggregationOperation(
			        new BasicDBObject(
			            "$lookup",
			            new BasicDBObject("from", "pcWirelessOrder")
			                .append("localField","pcORderNumber")
			                .append("foreignField", "order.orderNumber")
			                .append("as", "pcWirelessOrder")
			        )
			    ),		
			    sort(Sort.Direction.DESC, "ponVersion")
				);
		
		
		AggregationResults<PcWirlessTaskCollection> results1  = mongoTemplate.aggregate(aggregation, "taskinst", PcWirlessTaskCollection.class);
		System.out.println("results1 "+results1.toString());
		List<PcWirlessTaskCollection> mappedResults1 = results1.getMappedResults();
		System.out.println("mappedResults1 "+mappedResults1.toString());

		  List<TaskDetailReport> taskDetailsReport= 	mappedResults1.stream().map(i->
		new TaskDetailReport (
				  i.getPcWirelessOrder().get(0).getOrderDetails().getRegion(),
				  i.getPcWirelessOrder().get(0).getOrder().getOrderNumber(),
				  i.getTaskName(),
				  PcCEnum.OrderStatus.name(PcCEnum.OrderStatus.getValueBygetFieldName(  i.getPcWirelessOrder().get(0).getOrder().getOrderStatus())),
				  i.getTaskCreatedTime(),
				  i.getUserId(),
				  null,
				  null				 
				)).filter(vzCheck-> (vzId !=null && vzCheck.getVZID().equals(vzId) || "".equals(vzId) || "admin".equals(vzId))).
				  collect(Collectors.toList());
		  
		  System.out.println("TaskDetailReport ["+taskDetailsReport+"]");
		
		return taskDetailsReport;
	}

	
	public List<String> getPcWirelessOrderList(OrderDetailRequest orderReq){
		
		Date fromDate = stringToDate(orderReq.getDateOne(), "MM-dd-yyyy");
		Date toDate =  stringToDate(orderReq.getDateTwo(), "MM-dd-yyyy");
		List<PcWirelessOrder> pcwirelessorderList = null;
		if ("twoday".equals(orderReq.getDateRadios())) {
			if (orderReq.getRegion() != null && orderReq.getRegion().size() > 0) {
				pcwirelessorderList = pcwirelessOrderRepo
						.findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDateBetween(orderReq.getRegion(),
								toDate, fromDate);
			} else {
				pcwirelessorderList = pcwirelessOrderRepo.findByOrderDetailsCustomerDesiredDueDateBetween(
						toDate, fromDate);
			}
		} else {
			if (orderReq.getRegion() != null && orderReq.getRegion().size() > 0) {	
			pcwirelessorderList = pcwirelessOrderRepo
					.findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDate(orderReq.getRegion(), toDate);
			}else{
				pcwirelessorderList = pcwirelessOrderRepo.findByOrderDetailsCustomerDesiredDueDate(
						toDate);
			}
		}
		System.out.println("pcwirelessorderList " + pcwirelessorderList);
		List<String> orderNumList = pcwirelessorderList.stream().map(i->i.getId()+"").collect(Collectors.toList());
		
		return orderNumList;
	}
	
	
	public static Date stringToDate(String date, String format) {
		Date d = null;

		try {
			d = new SimpleDateFormat(format).parse(date);
		} catch (ParseException e) {
			// Do Nothing. Return null
		}
		return d;
	}
}
