package com.vz.pc.wireless.transport.ordercollection.model.mongod.collection;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.mapping.Document;

import com.vz.pc.wireless.transport.ordercollection.model.MongoParams;

@Document(collection = "acnaccna")

public class AcnaCcnaData {

	private  ArrayList<String> acna;

	private ArrayList<String> ccna;
	
	private List<MongoParams>bandwidth;
	
	private List<MongoParams> regions;

	

	public ArrayList<String> getAcna() {
		return acna;
	}

	public void setAcna(ArrayList<String> acna) {
		this.acna = acna;
	}

	public ArrayList<String> getCcna() {
		return ccna;
	}

	public void setCcna(ArrayList<String> ccna) {
		this.ccna = ccna;
	}

	public List<MongoParams> getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(List<MongoParams> bandwidth) {
		this.bandwidth = bandwidth;
	}

	public List<MongoParams> getRegions() {
		return regions;
	}

	public void setRegions(List<MongoParams> regions) {
		this.regions = regions;
	}

	@Override
	public String toString() {
		return "AcnaCcnaData [acna=" + acna + ", ccna=" + ccna + ", bandwidth=" + bandwidth + ", regions=" + regions
				+ "]";
	}


}
