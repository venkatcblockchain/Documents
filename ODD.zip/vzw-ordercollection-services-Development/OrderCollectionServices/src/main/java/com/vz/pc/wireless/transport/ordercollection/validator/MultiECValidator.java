package com.vz.pc.wireless.transport.ordercollection.validator;

import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.vz.pc.wireless.transport.ordercollection.model.MultiEC;
import com.vz.pc.wireless.transport.ordercollection.model.Site;

@Configuration
public class MultiECValidator implements Validator {

	
	private SiteValidator siteValidator;
	
	@Override
	public boolean supports(Class<?> clazz) {
		return MultiEC.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

        MultiEC multilec = (MultiEC) target;
        
			ValidationUtils.rejectIfEmpty(errors, "segmentId", "value.required", "Null not allowed.");
	        ValidationUtils.rejectIfEmpty(errors, "segmentName", "value.required", "Null not allowed.");
	        ValidationUtils.rejectIfEmpty(errors, "icsc", "value.required", "Null not allowed.");


	       siteValidator = new SiteValidator();
	        
	        if(multilec.getSegmentName() != null && multilec.getSegmentName().length() >53){
	        	errors.rejectValue("segmentName", "segmentName.invalid", new Object[] {multilec.getSegmentName()}, "SegmentName should be 53 character long");
	        }
	        
	        if(multilec.getSegmentId() != null && !isNumber(multilec.getSegmentId())){
	        	errors.rejectValue("segmentId", "segmentId.invalid", new Object[] {multilec.getSegmentId()}, "SegmentId should be Numeric");
	        }

	        if(multilec.getBAN() != null && multilec.getBAN().length() >32){
	        	errors.rejectValue("BAN", "BAN.invalid", new Object[] {multilec.getBAN()}, "BAN should be 32 character long");
	        }
	        
	        if(multilec.getMrc() != null && multilec.getMrc().length() >11){
	        	errors.rejectValue("mrc", "mrc.invalid", new Object[] {multilec.getMrc()}, "Mrc	should be 11 character long");
	        }

	        if(multilec.getCfa()!=null && multilec.getCfa().length() >42){
	        	errors.rejectValue("cfa", "CFA.invalid", new Object[] {multilec.getCfa()}, "CFA	should be 42 character long");
	        }
		
	        if(multilec.getNewCFA()!=null && multilec.getNewCFA().length() >42){
	        	errors.rejectValue("newCFA", "newCFA.invalid", new Object[] {multilec.getNewCFA()}, "newCFA	should be 42 character long");
	        }
	        
	        if (multilec.getVendorCode() != null && multilec.getVendorCode().replaceAll("\\[.*\\]","").trim().length() > 100) {
	        	errors.rejectValue("vendorCode", "vendorCode.invalid", new Object[] {multilec.getVendorCode()}, "vendorCode	should be 100 character long");
			}
	
	        if (multilec.getVendorEmail() != null && multilec.getVendorEmail().length() > 100) {
	        	errors.rejectValue("vendorEmail", "vendorEmail.invalid", new Object[] {multilec.getVendorEmail()}, "vendorEmail	should be 100 character long");
			}
	        
	        if (multilec.getVendorEmail() != null && multilec.getVendorEmail().length() > 100) {
	        	errors.rejectValue("vendorEmail", "vendorEmail.invalid", new Object[] {multilec.getVendorEmail()}, "vendorEmail	should be 100 character long");
			}
	        
	        if (multilec.getIcsc() != null && (multilec.getIcsc().length() > 4|| multilec.getIcsc().length() < 4)) {
	        	errors.rejectValue("icsc", "icsc.invalid", new Object[] {multilec.getIcsc()}, "icsc	should be 4 character long");
			}
	        
	        int idx = 0;
	        for (Site item : multilec.getSite()) {
	            errors.pushNestedPath("site["+idx+"]");
	            ValidationUtils.invokeValidator(this.siteValidator, item, errors);
	            errors.popNestedPath();
	            idx++;
	        }
	        
	}
	
	public static boolean isNumber(String message) {
		try {
			Double.parseDouble(message);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

}
