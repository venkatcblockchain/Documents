package com.vz.pc.wireless.transport.ordercollection.model.mongod.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.OneFiberOrder;

public interface FiberOrderMilestone extends MongoRepository<OneFiberOrder, Long> {

	public OneFiberOrder findByOrderOrderNumber(String orderNumber);

}
