package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.List;

public class OrderSearchRequest {
	
	private String orderNumber;
	private  List<String> status;
	private List<String> region;
	private List<String> product;

	private  List<String> acna;
	private  List<String> vendor;
	private  List<String> ccna;
	private  List<String> icsc;
	private String project;
	private String siteName;
	private String asog;
	private String lecOrderNo;
	private String pon;
	private List<String> orderType;
	private String segmentId;
	private  List<String> bandwidth;
	private String startDate;
	private String endDate;
	private String dataType; 
	private  List<String> category;
	private String nfid;
	
	
	public List<String> getCategory() {
		return category;
	}
	public void setCategory(List<String> category) {
		this.category = category;
	}
	/**
	 * @return the orderNumber
	 */
	public String getOrderNumber() {
		return orderNumber;
	}
	/**
	 * @param orderNumber the orderNumber to set
	 */
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	/**
	 * @return the status
	 */
	public  List<String> getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus( List<String> status) {
		this.status = status;
	}
	/**
	 * @return the region
	 */
	public List<String> getRegion() {
		return region;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(List<String> region) {
		this.region = region;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */

	/**
	 * @return the product
	 */
	public List<String> getProduct() {
		return product;
	}
	@Override
	public String toString() {
		return "OrderSearchRequest [orderNumber=" + orderNumber + ", status=" + status + ", region=" + region
				+ ", product=" + product + ", acna=" + acna + ", vendor=" + vendor + ", ccna=" + ccna + ", icsc=" + icsc
				+ ", project=" + project + ", siteName=" + siteName + ", asog=" + asog + ", lecOrderNo=" + lecOrderNo
				+ ", pon=" + pon + ", orderType=" + orderType + ", segmentId=" + segmentId + ", bandwidth=" + bandwidth
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", dataType=" + dataType + ", category="
				+ category + ", nfid=" + nfid + "]";
	}
	/**
	 * @param product the product to set
	 */
	public void setProduct(List<String> product) {
		this.product = product;
	}
	/**
	 * @return the acna
	 */

	/**
	 * @return the vendor
	 */

	public List<String> getAcna() {
		return acna;
	}
	public void setAcna(List<String> acna) {
		this.acna = acna;
	}
	public void setVendor(List<String> vendor) {
		this.vendor = vendor;
	}
	public void setCcna(List<String> ccna) {
		this.ccna = ccna;
	}
	public void setIcsc(List<String> icsc) {
		this.icsc = icsc;
	}
	public void setBandwidth(List<String> bandwidth) {
		this.bandwidth = bandwidth;
	}
	
	
	/**
	 * @param vendor the vendor to set
	 */

	/**
	 * @param ccna the ccna to set
	 */

	public List<String> getVendor() {
		return vendor;
	}
	public List<String> getCcna() {
		return ccna;
	}
	public List<String> getIcsc() {
		return icsc;
	}
	public List<String> getBandwidth() {
		return bandwidth;
	}
	/**
	 * @return the project
	 */
	public String getProject() {
		return project;
	}
	/**
	 * @param project the project to set
	 */
	public void setProject(String project) {
		this.project = project;
	}
	/**
	 * @return the siteName
	 */
	public String getSiteName() {
		return siteName;
	}
	/**
	 * @param siteName the siteName to set
	 */
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	/**
	 * @return the asog
	 */
	public String getAsog() {
		return asog;
	}
	/**
	 * @param asog the asog to set
	 */
	public void setAsog(String asog) {
		this.asog = asog;
	}
	/**
	 * @return the lecOrderNo
	 */
	public String getLecOrderNo() {
		return lecOrderNo;
	}
	/**
	 * @param lecOrderNo the lecOrderNo to set
	 */
	public void setLecOrderNo(String lecOrderNo) {
		this.lecOrderNo = lecOrderNo;
	}
	/**
	 * @return the pon
	 */
	public String getPon() {
		return pon;
	}
	/**
	 * @param pon the pon to set
	 */
	public void setPon(String pon) {
		this.pon = pon;
	}
	/**
	 * @return the orderType
	 */

	/**
	 * @return the segmentId
	 */
	public String getSegmentId() {
		return segmentId;
	}
	public List<String> getOrderType() {
		return orderType;
	}
	public void setOrderType(List<String> orderType) {
		this.orderType = orderType;
	}
	/**
	 * @param segmentId the segmentId to set
	 */
	public void setSegmentId(String segmentId) {
		this.segmentId = segmentId;
	}
	/**
	 * @return the bandwidth
	 */

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the dataType
	 */
	public String getDataType() {
		return dataType;
	}
	/**
	 * @param dataType the dataType to set
	 */
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getNfid() {
		return nfid;
	}
	public void setNfid(String nfid) {
		this.nfid = nfid;
	}
	
	
	
	

}
