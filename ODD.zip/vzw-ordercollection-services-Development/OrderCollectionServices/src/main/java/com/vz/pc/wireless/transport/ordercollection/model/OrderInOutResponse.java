package com.vz.pc.wireless.transport.ordercollection.model;


import java.util.Date;

import com.mongodb.BasicDBObject;

public class OrderInOutResponse {
public long  id;

public Date createTime;
public Long pcOrderId;
public String eventName;
public Long sequence;
public String sourceSystem;
public String destSystem;
public String actionType;
public long millisec;
public String  eventType;
public long taskId;
public BasicDBObject dbObject;

public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getEventType() {
	return eventType;
}
public void setEventType(String eventType) {
	this.eventType = eventType;
}
public long getMillisec() {
	return millisec;
}
public void setMillisec(long millisec) {
	this.millisec = millisec;
}

public Date  getCreateTime() {
	return createTime;
}
public void setCreateTime(Date createTime) {
	this.createTime = createTime;
}
public Long getPcOrderId() {
	return pcOrderId;
}
public void setPcOrderId(Long pcOrderId) {
	this.pcOrderId = pcOrderId;
}
public String getEventName() {
	return eventName;
}
public void setEventName(String eventName) {
	this.eventName = eventName;
}
public Long getSequence() {
	return sequence;
}
public void setSequence(Long sequence) {
	this.sequence = sequence;
}
public String getSourceSystem() {
	return sourceSystem;
}
public void setSourceSystem(String sourceSystem) {
	this.sourceSystem = sourceSystem;
}
public String getDestSystem() {
	return destSystem;
}
public void setDestSystem(String destSystem) {
	this.destSystem = destSystem;
}
public String getActionType() {
	return actionType;
}
public void setActionType(String actionType) {
	this.actionType = actionType;
}

/*public Map<Object, Object> getDbObject() {
	return dbObject;
}
public void setDbObject(Map<Object, Object> dbObject) {
	this.dbObject = dbObject;
}*/


@Override
public String toString() {
	return "OrderInOutResponse [createTime=" + createTime + ", pcOrderId=" + pcOrderId + ", eventName=" + eventName
			+ ", sequence=" + sequence + ", sourceSystem=" + sourceSystem + ", destSystem=" + destSystem
			+ ", actionType=" + actionType + ", millisec=" + millisec + ", eventType=" + eventType + ", dbObject="
			+ dbObject + "]";
}
public long getTaskId() {
	return taskId;
}
public void setTaskId(long taskId) {
	this.taskId = taskId;
}
public BasicDBObject getDbObject() {
	return dbObject;
}
public void setDbObject(BasicDBObject dbObject) {
	this.dbObject = dbObject;
}



}
