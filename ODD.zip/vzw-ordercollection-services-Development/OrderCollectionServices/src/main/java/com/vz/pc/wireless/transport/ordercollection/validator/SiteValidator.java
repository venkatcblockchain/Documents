package com.vz.pc.wireless.transport.ordercollection.validator;

import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.vz.pc.wireless.transport.ordercollection.model.Site;

@Configuration
public class SiteValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {

		return Site.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		Site site = (Site) target;
		ValidationUtils.rejectIfEmpty(errors, "siteId", "value.required", "Null not allowed.");

		if (site.getSiteId() != null && !isNumber(site.getSiteId())) {
			errors.rejectValue("siteId", "siteId.invalid", new Object[] { site.getSiteId() },
					"SiteId   " + site.getSiteId() + "  should be Numeric");
		}

		if (site.getSiteId() != null) {
			
			ValidationUtils.rejectIfEmpty(errors, "siteName", "value.required", "Null not allowed.");
			ValidationUtils.rejectIfEmpty(errors, "street", "value.required", "Null not allowed.");
			ValidationUtils.rejectIfEmpty(errors, "city", "value.required", "Null not allowed.");
			ValidationUtils.rejectIfEmpty(errors, "state", "value.required", "Null not allowed.");
			ValidationUtils.rejectIfEmpty(errors, "zip", "value.required", "Null not allowed.");

			if (site.getType() != null && site.getType().length() > 10) {
				errors.rejectValue("type", "type.invalid", new Object[] { site.getType() },
						"Site Type   " + site.getType() + "  should be 10 character long");
			}

	
				if (site.getStreet().length() > 64) {
					errors.rejectValue("street", "street.invalid", new Object[] { site.getStreet() },
							"Street " + site.getStreet() + "  should be 64 character long");
				}
			
				
				if (site.getCity().length() > 40) {
					errors.rejectValue("city", "city.invalid", new Object[] { site.getCity() },
							"City " + site.getCity() + "  should be 40 character long");
				}
				
				
				if (site.getState().length() > 32) {
					errors.rejectValue("state", "state.invalid", new Object[] { site.getState() },
							"State " + site.getState() + "  should be 32 character long");
				}
						
				if (site.getZip().length() > 20) {
					errors.rejectValue("zip", "zip.invalid", new Object[] { site.getZip() },
							"Zip " + site.getZip() + "  should be 20 character long");
				}
						
				if (site.getFloor()!= null && site.getFloor().length() > 10) {
					errors.rejectValue("floor", "floor.invalid", new Object[] { site.getFloor() },
							"Floor " + site.getFloor() + "  should be 10 character long");
				}
				
				if (site.getRoom() != null && site.getRoom().length() > 10) {
					errors.rejectValue("room", "room.invalid", new Object[] { site.getRoom() },
							"Room " + site.getRoom() + "  should be 10 character long");
				}
				

				if (site.getStructure() != null && site.getStructure().length() > 25) {
					errors.rejectValue("structure", "structure.invalid", new Object[] { site.getStructure() },
							"Structure " + site.getStructure() + "  should be 25 character long");
				}
				

				if (site.getElevation() != null && site.getElevation().length() > 10) {
					errors.rejectValue("elevation", "elevation.invalid", new Object[] { site.getElevation() },
							"Elevation " + site.getElevation() + "  should be 10 character long");
				}
				
				if (site.getUnit() != null && site.getUnit().length() > 10) {
					errors.rejectValue("unit", "unit.invalid", new Object[] { site.getUnit() },
							"unit " + site.getUnit() + "  should be 10 character long");
				}				
				
				if (site.getSiteName().replaceAll("\\[.*\\]","").trim().length() > 140) {
					errors.rejectValue("siteName", "siteName.invalid", new Object[] { site.getSiteName() },
							"SiteName " + site.getSiteName() + "  should be 140 character long");
				}		
				
				if (site.getPhone() != null && site.getPhone().length() > 50) {
					errors.rejectValue("phone", "phone.invalid", new Object[] { site.getPhone() },
							"phone " + site.getPhone() + "  should be 50 character long");
				}				
				
				if (site.getContactName() != null && site.getContactName().length() > 65) {
					errors.rejectValue("contactName", "contactName.invalid", new Object[] { site.getContactName() },
							"ContactName " + site.getContactName() + "  should be 65 character long");
				}				
				
				if (site.getClli() != null && site.getClli().length() > 20) {
					errors.rejectValue("clli", "clli.invalid", new Object[] { site.getClli() },
							"Clli " + site.getClli() + "  should be 20 character long");
				}				
				
				
		}

	}

	public static boolean isNumber(String message) {
		try {
			Double.parseDouble(message);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
}
