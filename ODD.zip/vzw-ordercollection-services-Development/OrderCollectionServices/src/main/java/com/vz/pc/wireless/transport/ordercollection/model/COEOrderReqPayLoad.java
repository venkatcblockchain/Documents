package com.vz.pc.wireless.transport.ordercollection.model;

import java.util.Date;

public class COEOrderReqPayLoad {

	@Override
	public String toString() {
		return "FiberOrderDetails [project=" + project + ", alocClli=" + alocClli + ", alocSiteNFID=" + alocSiteNFID + ", alocLatitude=" 
				 + alocLatitude + ", alocLongitude=" + alocLongitude + ", alocStreetAddress=" + alocStreetAddress + ", alocCity=" + alocCity
				 + ", alocState=" + alocState + ", alocZip=" + alocZip + ", alocSiteraId=" + alocSiteraId + ", alocType=" + alocType  
				 + ", alocPeoplesoftLocationCode=" + alocPeoplesoftLocationCode + ", alocCity=" + alocCity + ", alocCFA=" + alocCFA 
				 + ", zlocClli=" + zlocClli + ", zlocLatitude=" + zlocLatitude + ", zlocLongitude=" + zlocLongitude + ", zlocCity=" + zlocCity
				 + ", zlocStreetAddress=" + zlocStreetAddress + ", zlocState=" + zlocState + ", zlocZip=" + zlocZip + ", zlocSiteNFID=" + zlocSiteNFID
				 + ", zlocSiteraId=" + zlocSiteraId + ", zlocType=" + zlocType + ", zlocCFA=" + zlocCFA + ", zlocPeoplesoftLocationCode="
				 + zlocPeoplesoftLocationCode + ", numberOfFibers=" + numberOfFibers + ", bandwidth=" + bandwidth + ", distanceLimitation="
				 + distanceLimitation + ", lossLimitation=" + lossLimitation + ", cellSiteName=" + cellSiteName + ", cellSiteCategory="
				 + cellSiteCategory + ", cellSiteType=" + cellSiteType + ", marketName=" + marketName + ", clusterName=" + clusterName + ", CRANHub="
				 + CRANHub + ", MSCName=" + MSCName + ", requestedByName=" + requestedByName + ", requestedByPhone=" + requestedByPhone
				 + ", requestedByEmail=" + requestedByEmail + ", remarks=" + remarks + ", mustHaveByDate=" + mustHaveByDate + ", oneFiberIndicator="
				 + oneFiberIndicator + ", BBUCFA=" + BBUCFA + ", NGMtoBBUCFA=" + NGMtoBBUCFA + ", requestedDeliveryDate=" + requestedDeliveryDate + "]";
	}

	private String project;
	
	private String alocClli;
	
	private String alocSiteNFID;
	
	private String alocLatitude;
	
	private String alocLongitude;
	
	private String alocStreetAddress;
	
	private String alocCity;
	
	private String alocState;
	
	private String alocZip;
	
	private String alocSiteraId;
	
	private String alocType;
	
	private String alocPeoplesoftLocationCode;
	
	private String alocCFA;
	
	private String zlocClli;
	
	private String zlocLatitude;
	
	private String zlocLongitude;
	
	private String zlocStreetAddress;
	
	private String zlocCity;
	
	private String zlocState;
	
	private String zlocZip;
	
	private String zlocSiteNFID;
	
	private String zlocSiteraId;
	
	private String zlocType;
	
	private String zlocCFA;
	
	private String zlocPeoplesoftLocationCode;
	
	private String numberOfFibers;
	
	private String bandwidth;
	
	private String distanceLimitation;
	
	private String lossLimitation;
	
	private String cellSiteName;
	
	private String cellSiteCategory;
	
	private String cellSiteType;
	
	private String marketName;
	
	private String clusterName;
	
	private String CRANHub;
	
	private String MSCName;
	
	private String requestedByName;
	
	private String requestedByPhone;
	
	private String requestedByEmail;
	
	private String remarks;
	
	private String oneFiberIndicator;
	
	private String BBUCFA;
	
	private String NGMtoBBUCFA;
	
	private Date requestedDeliveryDate;
	
	private Date mustHaveByDate;

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getAlocClli() {
		return alocClli;
	}

	public void setAlocClli(String alocClli) {
		this.alocClli = alocClli;
	}

	public String getAlocSiteNFID() {
		return alocSiteNFID;
	}

	public void setAlocSiteNFID(String alocSiteNFID) {
		this.alocSiteNFID = alocSiteNFID;
	}

	public String getAlocLatitude() {
		return alocLatitude;
	}

	public void setAlocLatitude(String alocLatitude) {
		this.alocLatitude = alocLatitude;
	}

	public String getAlocLongitude() {
		return alocLongitude;
	}

	public void setAlocLongitude(String alocLongitude) {
		this.alocLongitude = alocLongitude;
	}

	public String getAlocStreetAddress() {
		return alocStreetAddress;
	}

	public void setAlocStreetAddress(String alocStreetAddress) {
		this.alocStreetAddress = alocStreetAddress;
	}

	public String getAlocCity() {
		return alocCity;
	}

	public void setAlocCity(String alocCity) {
		this.alocCity = alocCity;
	}

	public String getAlocState() {
		return alocState;
	}

	public void setAlocState(String alocState) {
		this.alocState = alocState;
	}

	public String getAlocZip() {
		return alocZip;
	}

	public void setAlocZip(String alocZip) {
		this.alocZip = alocZip;
	}

	public String getAlocSiteraId() {
		return alocSiteraId;
	}

	public void setAlocSiteraId(String alocSiteraId) {
		this.alocSiteraId = alocSiteraId;
	}

	public String getAlocType() {
		return alocType;
	}

	public void setAlocType(String alocType) {
		this.alocType = alocType;
	}

	public String getAlocPeoplesoftLocationCode() {
		return alocPeoplesoftLocationCode;
	}

	public void setAlocPeoplesoftLocationCode(String alocPeoplesoftLocationCode) {
		this.alocPeoplesoftLocationCode = alocPeoplesoftLocationCode;
	}

	public String getAlocCFA() {
		return alocCFA;
	}

	public void setAlocCFA(String alocCFA) {
		this.alocCFA = alocCFA;
	}

	public String getZlocClli() {
		return zlocClli;
	}

	public void setZlocClli(String zlocClli) {
		this.zlocClli = zlocClli;
	}

	public String getZlocLatitude() {
		return zlocLatitude;
	}

	public void setZlocLatitude(String zlocLatitude) {
		this.zlocLatitude = zlocLatitude;
	}

	public String getZlocLongitude() {
		return zlocLongitude;
	}

	public void setZlocLongitude(String zlocLongitude) {
		this.zlocLongitude = zlocLongitude;
	}

	public String getZlocStreetAddress() {
		return zlocStreetAddress;
	}

	public void setZlocStreetAddress(String zlocStreetAddress) {
		this.zlocStreetAddress = zlocStreetAddress;
	}

	public String getZlocCity() {
		return zlocCity;
	}

	public void setZlocCity(String zlocCity) {
		this.zlocCity = zlocCity;
	}

	public String getZlocState() {
		return zlocState;
	}

	public void setZlocState(String zlocState) {
		this.zlocState = zlocState;
	}

	public String getZlocZip() {
		return zlocZip;
	}

	public void setZlocZip(String zlocZip) {
		this.zlocZip = zlocZip;
	}

	public String getZlocSiteNFID() {
		return zlocSiteNFID;
	}

	public void setZlocSiteNFID(String zlocSiteNFID) {
		this.zlocSiteNFID = zlocSiteNFID;
	}

	public String getZlocSiteraId() {
		return zlocSiteraId;
	}

	public void setZlocSiteraId(String zlocSiteraId) {
		this.zlocSiteraId = zlocSiteraId;
	}

	public String getZlocType() {
		return zlocType;
	}

	public void setZlocType(String zlocType) {
		this.zlocType = zlocType;
	}

	public String getZlocCFA() {
		return zlocCFA;
	}

	public void setZlocCFA(String zlocCFA) {
		this.zlocCFA = zlocCFA;
	}

	public String getZlocPeoplesoftLocationCode() {
		return zlocPeoplesoftLocationCode;
	}

	public void setZlocPeoplesoftLocationCode(String zlocPeoplesoftLocationCode) {
		this.zlocPeoplesoftLocationCode = zlocPeoplesoftLocationCode;
	}

	public String getNumberOfFibers() {
		return numberOfFibers;
	}

	public void setNumberOfFibers(String numberOfFibers) {
		this.numberOfFibers = numberOfFibers;
	}

	public String getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	public String getDistanceLimitation() {
		return distanceLimitation;
	}

	public void setDistanceLimitation(String distanceLimitation) {
		this.distanceLimitation = distanceLimitation;
	}

	public String getLossLimitation() {
		return lossLimitation;
	}

	public void setLossLimitation(String lossLimitation) {
		this.lossLimitation = lossLimitation;
	}

	public String getCellSiteName() {
		return cellSiteName;
	}

	public void setCellSiteName(String cellSiteName) {
		this.cellSiteName = cellSiteName;
	}

	public String getCellSiteCategory() {
		return cellSiteCategory;
	}

	public void setCellSiteCategory(String cellSiteCategory) {
		this.cellSiteCategory = cellSiteCategory;
	}

	public String getCellSiteType() {
		return cellSiteType;
	}

	public void setCellSiteType(String cellSiteType) {
		this.cellSiteType = cellSiteType;
	}

	public String getMarketName() {
		return marketName;
	}

	public void setMarketName(String marketName) {
		this.marketName = marketName;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	public String getCRANHub() {
		return CRANHub;
	}

	public void setCRANHub(String CRANHub) {
		this.CRANHub = CRANHub;
	}

	public String getMSCName() {
		return MSCName;
	}

	public void setMSCName(String MSCName) {
		this.MSCName = MSCName;
	}

	public String getRequestedByName() {
		return requestedByName;
	}

	public void setRequestedByName(String requestedByName) {
		this.requestedByName = requestedByName;
	}

	public String getRequestedByPhone() {
		return requestedByPhone;
	}

	public void setRequestedByPhone(String requestedByPhone) {
		this.requestedByPhone = requestedByPhone;
	}

	public String getRequestedByEmail() {
		return requestedByEmail;
	}

	public void setRequestedByEmail(String requestedByEmail) {
		this.requestedByEmail = requestedByEmail;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getOneFiberIndicator() {
		return oneFiberIndicator;
	}

	public void setOneFiberIndicator(String oneFiberIndicator) {
		this.oneFiberIndicator = oneFiberIndicator;
	}

	public String getBBUCFA() {
		return BBUCFA;
	}

	public void setBBUCFA(String BBUCFA) {
		this.BBUCFA = BBUCFA;
	}

	public String getNGMtoBBUCFA() {
		return NGMtoBBUCFA;
	}

	public void setNGMtoBBUCFA(String NGMtoBBUCFA) {
		this.NGMtoBBUCFA = NGMtoBBUCFA;
	}

	public Date getRequestedDeliveryDate() {
		return requestedDeliveryDate;
	}

	public void setRequestedDeliveryDate(Date requestedDeliveryDate) {
		this.requestedDeliveryDate = requestedDeliveryDate;
	}

	public Date getMustHaveByDate() {
		return mustHaveByDate;
	}

	public void setMustHaveByDate(Date mustHaveByDate) {
		this.mustHaveByDate = mustHaveByDate;
	}
	
}
