package com.vz.pc.wireless.transport.ordercollection.model;

public class VzWirelessPVCDetails {
	
//PC_PVC 
	

	private String ruid;
	
	private String ceVlan;
	
	private String  evcbandwidth;
	
	private String evcId;  
	
	private String evcSequenceId;

	public String getRuid() {
		return ruid;
	}

	public void setRuid(String ruid) {
		this.ruid = ruid;
	}

	public String getCeVlan() {
		return ceVlan;
	}

	public void setCeVlan(String ceVlan) {
		this.ceVlan = ceVlan;
	}


	public String getEvcbandwidth() {
		return evcbandwidth;
	}

	public void setEvcbandwidth(String evcbandwidth) {
		this.evcbandwidth = evcbandwidth;
	}

	public String getEvcId() {
		return evcId;
	}

	public void setEvcId(String evcId) {
		this.evcId = evcId;
	}

	public String getEvcSequenceId() {
		return evcSequenceId;
	}

	public void setEvcSequenceId(String evcSequenceId) {
		this.evcSequenceId = evcSequenceId;
	}

	@Override
	public String toString() {
		return "VzWirelessPVCDetails [ruid=" + ruid + ", ceVlan=" + ceVlan + ", evcbandwidth=" + evcbandwidth + ", evcId=" + evcId + ", evcSequenceId="
				+ evcSequenceId + "]";
	}



}
