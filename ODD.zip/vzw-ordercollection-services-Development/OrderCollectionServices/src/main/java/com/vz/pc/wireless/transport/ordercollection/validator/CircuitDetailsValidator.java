package com.vz.pc.wireless.transport.ordercollection.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Configuration
public class CircuitDetailsValidator implements Validator{
	
	private static Logger logger = LoggerFactory.getLogger(CircuitDetailsValidator.class);

	@Override
	public boolean supports(Class<?> clazz) {
		return CircuitDetailsValidator.class.equals(clazz);
	}

	@Override
	public void validate(Object orderNumber, Errors errors) {
		String request = (String) orderNumber;
		

		if (request == null) {
			logger.info("Validating If Order Number is Empty", request);
			errors.rejectValue("CircuitDetailRequest", "CircuitDetailRequest", "Empty request");
		}
		
		if(request != null && request.trim().length() == 0){
			logger.info("Requested Order Number Length is:", 0);
			errors.rejectValue("Order Number", "Order Number.invalid", new Object[] { request },
					"[ " + request + " ] should be 1 character long");
		}
		
		logger.info("Requested Order Number is:", request);
		
	}

}
