package com.vz.pc.wireless.transport.ordercollection.Enumerators;

public interface RemarksEnum {
	
	public  static final String  success="SUCCESS";
	public  static final String  failure="FAILURE";

}
