package com.vz.pc.wireless.transport.ordercollection.model.mongod.collection;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.vz.pc.wireless.transport.ordercollection.model.FiberOrder;
import com.vz.pc.wireless.transport.ordercollection.model.FiberOrderDetails;

@Document(collection = "oneFiberOrder")
public class OneFiberOrder {

	@Id
	private long id;

	private String coeOrderCreated;

	private String coeNFID;
	
	private String source;

	private FiberOrder order;

	private FiberOrderDetails orderDetails;
	
	private boolean isCoeAssignmentCreated;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public FiberOrder getOrder() {
		return order;
	}

	public void setOrder(FiberOrder order) {
		this.order = order;
	}

	public String getCoeOrderCreated() {
		return coeOrderCreated;
	}

	public void setCoeOrderCreated(String coeOrderCreated) {
		this.coeOrderCreated = coeOrderCreated;
	}

	public String getCoeNFID() {
		return coeNFID;
	}

	public void setCoeNFID(String coeNFID) {
		this.coeNFID = coeNFID;
	}

	public FiberOrderDetails getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(FiberOrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}

	public boolean isCoeAssignmentCreated() {
		return isCoeAssignmentCreated;
	}

	public void setCoeAssignmentCreated(boolean isCoeAssignmentCreated) {
		this.isCoeAssignmentCreated = isCoeAssignmentCreated;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return "FiberOrder [id=" + id + ", coeOrderCreated=" + coeOrderCreated + ", coeNFID=" + coeNFID + ", isCoeAssignmentCreated=" + isCoeAssignmentCreated
				+ ", source=" + source + ", order=" + order.toString() + ", orderDetails=" + orderDetails.toString() + "]";
	}
}
