package com.vz.pc.wireless.transport.ordercollection.validator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.vz.pc.wireless.transport.ordercollection.model.MultiEC;
import com.vz.pc.wireless.transport.ordercollection.model.PcOrderRequest;

@Configuration
public class OrderCollectionValidator implements Validator {

	private static Logger logger = LoggerFactory.getLogger(OrderCollectionValidator.class);

	private MultiECValidator multilecValidator;

	@Override
	public boolean supports(Class<?> clazz) {

		return PcOrderRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		PcOrderRequest request = (PcOrderRequest) target;
		multilecValidator = new MultiECValidator();

		if (request == null) {
			errors.rejectValue("pcOrderRequest", "pcOrderRequest", "Empty request");
		}

		if (request.getAsogFlag() != null && request.getAsogFlag().length() > 1) {

			errors.rejectValue("asogFlag", "asogFlag.invalid", new Object[] { request.getAsogFlag() },
					"[ " + request.getAsogFlag() + " ] should be 1 character long");
		}

		if (request.getRelatedPon() != null && request.getRelatedPon().trim().replaceAll(" ", "").length() > 60) {
			errors.rejectValue("RPON", "RPON.invalid", new Object[] { request.getRelatedPon() }, "RPON " + request.getRelatedPon() + "  should be 60 character long");
		}

		if (request.getPonNumber() != null && request.getPonNumber().trim().replaceAll(" ", "").length() > 60) {
			errors.rejectValue("ponNumber", "ponNumber.invalid", new Object[] { request.getPonNumber() },
					"PonNumber " + request.getPonNumber() + "  should be 60 character long");
		}

		if (request.getCopyFromPON() != null && request.getCopyFromPON().length() > 60) {
			errors.rejectValue("copyFromPON", "copyFromPON.invalid", new Object[] { request.getCopyFromPON() },
					"copyFromPON " + request.getCopyFromPON() + "  should be 60 character long");
		}

		if (request.getDisconnectCopyFromPON() != null && request.getDisconnectCopyFromPON().length() > 60) {
			errors.rejectValue("disconnectCopyFromPON", "disconnectCopyFromPON.invalid", new Object[] { request.getDisconnectCopyFromPON() },
					"disconnectCopyFromPON " + request.getDisconnectCopyFromPON() + "  should be 60 character long");
		}

		if (request.getProjectId() != null && request.getProjectId().length() > 20) {
			errors.rejectValue("projectId", "projectId.invalid", new Object[] { request.getProjectId() },
					"ProjectId " + request.getProjectId() + "  should be 20 character long");
		}

		if (request.getCcna() != null && request.getCcna().length() > 20) {
			errors.rejectValue("ccna", "ccna.invalid", new Object[] { request.getCcna() }, "Ccna " + request.getCcna() + "  should be 20 character long");
		}

		if (request.getActlCoLocation() != null && request.getActlCoLocation().length() > 100) {
			errors.rejectValue("actlCoLocation", "actlCoLocation.invalid", new Object[] { request.getActlCoLocation() },
					"ActlCoLocation " + request.getActlCoLocation() + "  should be 100 character long");
		}

		if (request.getAction() != null && request.getAction().length() > 20) {
			errors.rejectValue("action", "action.invalid", new Object[] { request.getAction() },
					"Action " + request.getAction() + "  should be 20 character long");
		}

		if (request.getTspCode() != null && request.getTspCode().length() > 12) {
			errors.rejectValue("tspCode", "tspCode.invalid", new Object[] { request.getTspCode() },
					"TspCode " + request.getTspCode() + "  should be 12 character long");
		}

		if (request.getCno() != null && request.getCno().length() > 12) {
			errors.rejectValue("cno", "cno.invalid", new Object[] { request.getCno() }, "Cno " + request.getCno() + "  should be 12 character long");
		}

		if (request.getEVCSP() != null && request.getEVCSP().length() > 20) {
			errors.rejectValue("EVCSP", "EVCSP.invalid", new Object[] { request.getEVCSP() }, "EVCSP " + request.getEVCSP() + "  should be 20 character long");
		}

		if (request.getSpec() != null && request.getSpec().length() > 15) {
			errors.rejectValue("spec", "spec.invalid", new Object[] { request.getSpec() }, "Spec " + request.getSpec() + "  should be 15 character long");
		}

		int idx = 0;
		for (MultiEC item : request.getMultiEC()) {
			errors.pushNestedPath("multiEC[" + idx + "]");
			ValidationUtils.invokeValidator(this.multilecValidator, item, errors);
			errors.popNestedPath();
			idx++;
		}

	}

}