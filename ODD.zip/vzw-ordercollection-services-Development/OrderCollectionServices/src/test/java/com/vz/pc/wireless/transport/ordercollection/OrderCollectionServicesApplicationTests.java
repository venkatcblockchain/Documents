package com.vz.pc.wireless.transport.ordercollection;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.match;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.sort;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBObject;
import com.mongodb.WriteResult;
import com.vz.pc.wireless.transport.ordercollection.Enumerators.PcCEnum;
import com.vz.pc.wireless.transport.ordercollection.model.Events;
import com.vz.pc.wireless.transport.ordercollection.model.IcscData;
import com.vz.pc.wireless.transport.ordercollection.model.MongoParams;
import com.vz.pc.wireless.transport.ordercollection.model.OrderDetailReport;
import com.vz.pc.wireless.transport.ordercollection.model.OrderSearchRequest;
import com.vz.pc.wireless.transport.ordercollection.model.PcWirlessAsrMilestoneCollection;
import com.vz.pc.wireless.transport.ordercollection.model.VendorDataSet;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.AcnaCcnaData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.EventAudit;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.PcWirelessOrder;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.collection.VendorData;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.AcnaCcnaDataRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.CustomAggregationOperation;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.EventAuditRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.PcWirelessOrderRepository;
import com.vz.pc.wireless.transport.ordercollection.model.mongod.repository.VendorDataRepository;
import com.vz.pc.wireless.transport.ordercollection.service.IOrderDetailsService;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = OrderCollectionServicesApplication.class)
@WebAppConfiguration
public class OrderCollectionServicesApplicationTests {

	 @Test
	public void contextLoads() {
	}

	@ Autowired
	 PcWirelessOrderRepository pcwirelessOrderRepo;
	 
	@Autowired
	VendorDataRepository vendorDataRepo;

	@Autowired
	private MongoOperations mongo;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private ObjectMapper objectMapper;
	
	@Autowired
	private IOrderDetailsService iOrderDetailService;
	@Autowired
	private AcnaCcnaDataRepository acnaCcnaDataRepository;
	
	@Autowired
	EventAuditRepository eventAuditRepository;
	
	
	// @Test
	public void testInsert() {

		VendorData data = new VendorData();
		data.setVendor("VENDOR_4");
		ArrayList<IcscData> icscList = new ArrayList<IcscData>();

		IcscData e = new IcscData();
		e.setIcsc("AC");
		ArrayList<String> acnaList = new ArrayList<>(Arrays.asList("0"));
		ArrayList<String> ccnaList = new ArrayList<>(Arrays.asList("0", "1", "2", "3", "4", "5"));
		e.setAcna(acnaList);
		e.setCcna(ccnaList);
		e.setAsogFlag("Y");
		e.setEmail(null);
		icscList.add(e);
		data.setIcscList(icscList);

		//vendorDataRepo.save(data);

	}

	//@Test
	public void testAdd() {

		/*
		 * VendorData data = new VendorData(); data.setVendor("VENDOR_4");
		 * ArrayList<IcscData> icscList = new ArrayList<IcscData>();
		 * 
		 * IcscData e = new IcscData();
		 */
		ArrayList<String> acnaList = new ArrayList<>(Arrays.asList("9" ,"23" ,"5"));
		ArrayList<String> ccnaList = new ArrayList<>(Arrays.asList("0", "1", "2", "3", "4", "5"));
		/*
		 * e.setAcna(acnaList ); e.setCcna(ccnaList); e.setAsogFlag("Y");
		 * e.setEmail(null); icscList.add(e ); data.setIcscList(icscList);
		 * 
		 * vendorDataRepo.save(data);
		 */

		// Adding an element to an array

		Query query = new Query(new Criteria().andOperator(Criteria.where("_id").is("VENDOR_4"),
				Criteria.where("icscList.icsc").is("AC")
		/*
		 * , Criteria.where("contacts.collection._class").is("SubClass2")
		 */
		));
		Update update = new Update().push("icscList.$.acna", "10");
		mongoTemplate.updateFirst(query, update, VendorData.class);

		// Removing an element from an array

		query = new Query(new Criteria().andOperator(Criteria.where("_id").is("VENDOR_4"),
				Criteria.where("icscList.icsc").is("AC")
		/*
		 * , Criteria.where("contacts.collection._class").is("SubClass2")
		 */
		));
		update = new Update().pull("icscList.$.acna", "10");
		System.out.println("update    " +update.toString());
		System.out.println("query  "+query.toString());
		mongoTemplate.updateFirst(query, update, VendorData.class);

		// Adding list of elements to an array

		query = new Query(new Criteria().andOperator(Criteria.where("_id").is("VENDOR_4"),
				Criteria.where("icscList.icsc").is("AC")
		/*
		 * , Criteria.where("contacts.collection._class").is("SubClass2")
		 */
		));
		/*update = new Update().pushAll("icscList.$.acna", new String[] { "6", "5" });
		mongoTemplate.updateFirst(query, update, VendorData.class);

		// Add element if not exist
		query = new Query(new Criteria().andOperator(Criteria.where("_id").is("VENDOR_4"),
				Criteria.where("icscList.icsc").is("AC")
		
		 * , Criteria.where("contacts.collection._class").is("SubClass2")
		 
		));
		update = new Update().addToSet("icscList.$.acna", "5");
		System.out.println("update'" +update.toString());
		WriteResult writeResult =  	mongoTemplate.updateFirst(query, update, VendorData.class);
		*/
	}
	
	//@Test
	public void acnaccna(){
		

		Update update = new Update();
		AcnaCcnaData acnaCcnaData = new AcnaCcnaData();
		
		
		List<MongoParams> bandwidth = new ArrayList<>();
		MongoParams m = new MongoParams();
		m.setName("test");
		m.setValue("testvalue");
		bandwidth.add(m);
		acnaCcnaData.setBandwidth(bandwidth );

		
		MongoParams[] regionsArray = acnaCcnaData.getBandwidth().stream().toArray(size -> new MongoParams[size]);
		update.pushAll("bandwidth", regionsArray);
		
/*		if(Optional.ofNullable(acnaCcnaData.getBandwidth()).isPresent()){
			 acnaCcnaData.getBandwidth().entrySet().forEach(keyval->{
			//	 String key = keyval.getKey().replaceAll(".", "\uff0E");
					update.set("bandwidth."+keyval.getKey().replace(".", "\uff0E"), keyval.getValue());	 
			 });
		
		}
		mongoTemplate.updateFirst(null, update, AcnaCcnaData.class);*/

	mongoTemplate.updateFirst(null, update, AcnaCcnaData.class);

	}
	
	//@Test
	
	public void acnaccnaDelete(){
		

		Update update = new Update();
		AcnaCcnaData acnaCcnaData = new AcnaCcnaData();

		ArrayList<String> acnaList = new ArrayList<>(Arrays.asList("acna1 "));

		acnaCcnaData.setAcna(acnaList);
		String[] acnaArray = acnaCcnaData.getAcna().stream().toArray(size -> new String[size]);

		ArrayList<String> ccnaList = new ArrayList<>(Arrays.asList("ccna7"));

		acnaCcnaData.setCcna(ccnaList);
		String[] ccnaArray = acnaCcnaData.getCcna().stream().toArray(size -> new String[size]);

		
		update.pullAll("icscList.$.acna", acnaArray);
		update.pullAll("icscList.$.ccna", ccnaArray);
		Query query = new Query(new Criteria().andOperator(Criteria.where("icscList.acna").in(acnaList)		/*
		 * , Criteria.where("contacts.collection._class").is("SubClass2")
		 */
		).orOperator(Criteria.where("icscList.ccna").in(ccnaList)		
		));
		
		mongoTemplate.find(query, VendorData.class);
		System.out.println("update "+update.toString());
		System.out.println("query "+query.toString());
		WriteResult	wr = mongoTemplate.updateMulti(query, update, VendorData.class);
		System.out.println("wrr " +wr.toString());
/*		if(Optional.ofNullable(acnaCcnaData.getBandwidth()).isPresent()){
			 acnaCcnaData.getBandwidth().entrySet().forEach(keyval->{
			//	 String key = keyval.getKey().replaceAll(".", "\uff0E");
					update.set("bandwidth."+keyval.getKey().replace(".", "\uff0E"), keyval.getValue());	 
			 });
		
		}
		mongoTemplate.updateFirst(null, update, AcnaCcnaData.class);*/


	}
	
	public void addVendorIcscDetail(VendorDataSet vendorDataSet) {
		VendorData vendorData = new VendorData();
		IcscData icscData = new IcscData();
		if (Optional.ofNullable(vendorDataSet).isPresent()) {
			vendorData.setVendor(vendorDataSet.getVendor());
		}
	}
	
	//@Test
	public void testDateCheck() {
		Date date   = stringToDate("01-29-2016", "MM-dd-yyyy");
		Date date2 = stringToDate("01-16-2016", "MM-dd-yyyy");
		Date date3 = stringToDate("01-15-2016", "MM-dd-yyyy");
		List<String> region =  Arrays.asList("Florida");
		List<PcWirelessOrder> pcwirelessorderList1 = pcwirelessOrderRepo
				.findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDateBetween(region, date ,  date2, new PageRequest(0, 10 ,  new Sort(Direction.ASC , "orderDetails.region")) ).getContent();
		System.out.println("pcwirelessorderList " + pcwirelessorderList1);
	
		List<PcWirelessOrder> pcwirelessorderList3 = pcwirelessOrderRepo
				.findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDateBetween(region, date ,  date2 );
		System.out.println("pcwirelessorderList3 " + pcwirelessorderList3);
		
		List<String> obj = pcwirelessorderList3.stream().map(i->i.getId()+"").collect(Collectors.toList());
		System.out.println("obj " + obj);

/*		Aggregation agg = newAggregation(
				
				match(Criteria.where("_id").lt(10)),
				group("hosting").count().as("total"),
				project("total").and("hosting").previousOperation(),
				sort(Sort.Direction.DESC, "total")
					
			);*/

//			LookupOperation lookup = Aggregation.lookup("asrMilestone", "orderNumber", "orderNumber", "newOrderNumber");

		//Aggregation support lookup/joins but only with 1.9.0-Build.Snapshot Release
		
/*			TypedAggregation<PcWirelessOrder> agg = newAggregation(PcWirelessOrder.class, 
					lookup("asrmilestone", "orderNumber", "orderNumber", "newOrderNumber"), //
					sort(ASC, "asrmilestone"));
			
			
			AggregationResults<DBObject> results  = 	mongoTemplate.aggregate(agg, "pcWirelessOrder", DBObject.class);
			List<DBObject> mappedResults = results.getMappedResults();

			DBObject firstItem = mappedResults.get(0);*/
	
		
		/** Join Mechanism**/
		Aggregation aggregation = newAggregation(
			   match(
			        Criteria.where("orderNumber").in(obj)
			    ),
			    new CustomAggregationOperation(
			        new BasicDBObject(
			            "$lookup",
			            new BasicDBObject("from", "pcWirelessOrder")
			                .append("localField","orderNumber")
			                .append("foreignField", "order.orderNumber")
			                .append("as", "pcWirelessOrder")
			        )
			    ),		
			    sort(Sort.Direction.DESC, "ponVersion")
				);
		
		
		AggregationResults<PcWirlessAsrMilestoneCollection> results1  = mongoTemplate.aggregate(aggregation, "asrmilestone", PcWirlessAsrMilestoneCollection.class);
		System.out.println("results1 "+results1.toString());
		List<PcWirlessAsrMilestoneCollection> mappedResults1 = results1.getMappedResults();
		System.out.println("mappedResults1 "+mappedResults1.toString());

/*		AggregationResults<DBObject> results  = mongoTemplate.aggregate(aggregation, "asrmilestone", DBObject.class);
		System.out.println("aggregation "+aggregation.toString());
		List<DBObject> mappedResults = results.getMappedResults();
		
	BasicDBList studentsList = (BasicDBList) mappedResults.get(0).get("pcWirelessOrder");
	

	
	BasicDBObject  pcWire = (BasicDBObject ) mappedResults.get(0);
	System.out.println("pcWire "+pcWire.toString());
	try {
		Map<String, Object> keyMap = objectMapper.readValue(pcWire.toString(), HashMap.class);
		System.out.println("keyMap "+keyMap.toString());
		String jsonData = objectMapper.writeValueAsString(keyMap.get("pcWirelessOrder"));
		System.out.println("jsonData"+jsonData);
	
		
		List<Map<String, Object>>  item = objectMapper.convertValue(keyMap.get("pcWirelessOrder"),TypeFactory.defaultInstance().constructCollectionType(List.class,  
				PcWirelessOrder.class));
		System.out.println("item "+item.toString());
		
		
		
		List<PcWirelessOrder> list = objectMapper.readValue(jsonData,
				TypeFactory.defaultInstance().constructCollectionType(List.class,  
						PcWirelessOrder.class));
		
		
		System.out.println("jsonData "+jsonData.toString());
		System.out.println("list  "+list);
		
		List<PcWirelessOrder>  taskRequestInput2 = new ArrayList<>();
		BeanUtils.populate(taskRequestInput2, keyMap);
		System.out.println("taskRequest "+taskRequestInput2.toString());
		List<PcWirelessOrder>  taskRequestInput2 = objectMapper.readValue(jsonData,List.class);
		System.out.println("taskRequestInput2 "+taskRequestInput2.toString());

		Map<String, Object>  taskRequestInput1 = objectMapper.readValue(jsonData,HashMap.class);

		System.out.println("taskRequestInput1 "+taskRequestInput1.toString());



		PcWirelessOrder  taskRequest =taskRequestInput1.get(0);
		System.out.println("taskRequest "+taskRequest.toString());
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (IllegalAccessException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (InvocationTargetException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} 
	*/
//	System.out.println(pcWire.get("orderDetails"));
	
		  List<OrderDetailReport> orderDetailsReportNew= 	mappedResults1.stream().map(i->
		new OrderDetailReport (
				  i.getPcWirelessOrder().get(0).getOrderDetails().getRegion(),
				  i.getPcWirelessOrder().get(0).getOrder().getOrderNumber(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getOrderType(),
				  PcCEnum.OrderStatus.name(PcCEnum.OrderStatus.getValueBygetFieldName(  i.getPcWirelessOrder().get(0).getOrder().getOrderStatus())),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSites()[0].getSiteName(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getTspCode(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getSegmentName(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getSegmentId(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getBandwidth(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getMrc(),
				  i.getPon(),
				  i.getPonVersion(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getProductCategory(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getProjectId(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getIcsc(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getSegments()[0].getVendorCode(),
				  i.getPcWirelessOrder().get(0).getOrder().getCreatedTime(),//null,i.get("pcWirelessOrder.order.createdTime").toString(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getCustomerDesiredDueDate(),
				  i.getAsrSendDate(),
				  i.getLecOrderNumber(),
				  i.getPcWirelessOrder().get(0).getOrderDetails().getCcna(),
				  i.getLecDesiredDueDate(),
				  i.getAckReceivedDate(),
				  i.getFocReceivedDate()
				  ,i.getFocDate(),
				  null,
				  null,
				  null				 
)
				).collect(Collectors.toList());
		  System.out.println("orderDetailsReportNew ["+orderDetailsReportNew+"]");

	//	System.out.println("firstItem "+mappedResults.toString());
		
		
		  List<OrderDetailReport> orderDetailsReport= pcwirelessorderList1.stream().
				  map(i->new OrderDetailReport (
						  i.getOrderDetails().getRegion(),
						  i.getOrder().getOrderNumber(),
						  i.getOrderDetails().getOrderType(),
						  PcCEnum.OrderStatus.name(PcCEnum.OrderStatus.getValueBygetFieldName( i.getOrder().getOrderStatus())),
						  i.getOrderDetails().getSites()[0].getSiteName(),
						  i.getOrderDetails().getTspCode(),
						  i.getOrderDetails().getSegments()[0].getSegmentName(),
						  i.getOrderDetails().getSegments()[0].getSegmentId(),
						  i.getOrderDetails().getSegments()[0].getBandwidth(),
						  i.getOrderDetails().getSegments()[0].getMrc(),
						  i.getOrderDetails().getPon(),
						  null,
						  i.getOrderDetails().getProductCategory(),
						  i.getOrderDetails().getProjectId(),
						  i.getOrderDetails().getSegments()[0].getIcsc(),
						  i.getOrderDetails().getSegments()[0].getVendorCode(),
						  i.getOrder().getCreatedTime(),
						  i.getOrderDetails().getCustomerDesiredDueDate(),
						  null,
						  null,
						  i.getOrderDetails().getCcna(),
						  null,
						  null,
						  null
						  ,null,
						  i.getOrderDetails().getUserId(),
						  null,
						  null				 
		 )).collect(Collectors.toList());
		  
		  System.out.println("orderDetailsReport ["+orderDetailsReport+"]");
		List<PcWirelessOrder> pcwirelessorderList2 = pcwirelessOrderRepo
				.findByOrderDetailsRegionInAndOrderDetailsCustomerDesiredDueDate(region, date3, new PageRequest(0, 10 ,  new Sort(Direction.ASC , "orderDetails.region")) ).getContent();
		System.out.println("pcwirelessorderList2 " + pcwirelessorderList2);

		Query query2 = new Query();
		query2.addCriteria(Criteria.where("orderDetails.customerDesiredDueDate").lte(date)
				.andOperator(Criteria.where("orderDetails.customerDesiredDueDate").gte(date2)));
		List<PcWirelessOrder> pcwirelessorderList = mongoTemplate.find(query2, PcWirelessOrder.class);
		System.out.println("pcwirelessorderList " + pcwirelessorderList);

	}

	//@Test
	public void testOrderSearch(){
		
		OrderSearchRequest orderSearchRequest = new OrderSearchRequest();
		orderSearchRequest.setOrderNumber("32446061");
		iOrderDetailService.getOrderSearchData(orderSearchRequest ); 
	}
	public static Date stringToDate(String date, String format) {
		Date d = null;

		try {
			d = new SimpleDateFormat(format).parse(date);
		} catch (ParseException e) {
			// Do Nothing. Return null
		}
		return d;
	}
	
	//@Test
	public void testBandwidth(){
		AcnaCcnaData acnaCcnaData = acnaCcnaDataRepository.findByBandwidthName("125 Mbps");
			System.out.println(""+acnaCcnaData.getBandwidth().get(0));
	}
	
	//@Test
public void addevents(){
/*	Events events[] = new Events[1];
	events[0] = new Events();
	events[0].setEventCreationTime(new Date());
	events[0].setEventName("FOC-Review");
	events[0].setNotes("FOC Review Created with Errors");
	events[0].setPonVersion("01");
	events[0].setUserId("PEACJA7");
	
	Update update = new Update();
	if(Optional.ofNullable(events).isPresent()){	
		update.pushAll("events", events);
	}
	Query query = new Query(
			new Criteria().andOperator(Criteria.where("orderNumber").is("23664778")));
	
	mongoTemplate.updateFirst(query, update, EventAudit.class);
*/
	EventAudit eventaudit = new EventAudit();
	eventaudit.setOrderNumber("1123976");
	Events events[] = new Events[1];
	events[0] = new Events();
	events[0].setEventCreationTime(new Date());
	events[0].setEventName("testevent");
	events[0].setNotes("SUCCESS");
	events[0].setPonVersion("01");
	events[0].setUserId("PEACJA7");
	eventaudit.setEvents(events);
	eventAuditRepository.save(eventaudit);
	
	
}

/*//@Test
public void getOrderTypeCount(){
		
	Aggregation aggregation = newAggregation(
			group("orderDetails.orderType").count().as("count"),
			project("orderDetails.orderType", "count" )
			);
//		db.temperature.aggregate([{$sort:{"dt":1}},{$group:{"_id":"$station", result:{$last:"$dt"}, t:{$last:"$t"}}}])
		AggregationResults<OrderReport> results1  = mongoTemplate.aggregate(aggregation, "pcWirelessOrder", OrderReport.class);
		System.out.println("results1 "+results1.getMappedResults().toString());
}*/
}
