package com.vzw.fuze.bulkupload.model;

import java.util.Date;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.verizon.webkit.annotations.ColumnMap;
import com.verizon.webkit.util.DBDataTypes;
import com.vzw.fuze.common.model.GenericModel;

@Component
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)

public class AuditFileUploadCommon extends GenericModel {

	@ColumnMap(columnName = "AUDIT_FILE_UPLOAD_COMMON_ID", dbDataType = DBDataTypes.INTEGER)
	private int auditFileUploadCommonId;
	
	@ColumnMap(columnName = "TRANS_ID", dbDataType = DBDataTypes.VARCHAR)
	private String transId;
	
	@ColumnMap(columnName = "TYPE", dbDataType = DBDataTypes.VARCHAR)
	private String type;
	
	@ColumnMap(columnName = "ID", dbDataType = DBDataTypes.INTEGER)
	private int id;
	
	@ColumnMap(columnName = "NUMBER1", dbDataType = DBDataTypes.INTEGER)
	private int number1;
	
	@ColumnMap(columnName = "NUMBER2", dbDataType = DBDataTypes.INTEGER)
	private int number2;
	
	@ColumnMap(columnName = "NUMBER3", dbDataType = DBDataTypes.INTEGER)
	private int number3;
	
	@ColumnMap(columnName = "NUMBER4", dbDataType = DBDataTypes.INTEGER)
	private int number4;
	
	@ColumnMap(columnName = "NUMBER5", dbDataType = DBDataTypes.INTEGER)
	private int number5;
	
	@ColumnMap(columnName = "TEXT1", dbDataType = DBDataTypes.VARCHAR)
	private String text1;
	
	@ColumnMap(columnName = "TEXT2", dbDataType = DBDataTypes.VARCHAR)
	private String text2;
	
	@ColumnMap(columnName = "TEXT3", dbDataType = DBDataTypes.VARCHAR)
	private String text3;
	
	@ColumnMap(columnName = "TEXT4", dbDataType = DBDataTypes.VARCHAR)
	private String text4;
	
	@ColumnMap(columnName = "TEXT5", dbDataType = DBDataTypes.VARCHAR)
	private String text5;
	
	@ColumnMap(columnName = "TEXT6", dbDataType = DBDataTypes.VARCHAR)
	private String text6;
	
	@ColumnMap(columnName = "TEXT7", dbDataType = DBDataTypes.VARCHAR)
	private String text7;
	
	@ColumnMap(columnName = "TEXT8", dbDataType = DBDataTypes.VARCHAR)
	private String text8;
	
	@ColumnMap(columnName = "TEXT9", dbDataType = DBDataTypes.VARCHAR)
	private String text9;
	
	@ColumnMap(columnName = "TEXT10", dbDataType = DBDataTypes.VARCHAR)
	private String text10;
	
	@ColumnMap(columnName = "ACTION", dbDataType = DBDataTypes.VARCHAR)
	private String action;
	
	@ColumnMap(columnName = "PRESENT", dbDataType = DBDataTypes.VARCHAR)
	private String present;
	
	@ColumnMap(columnName = "REJECT_REASON", dbDataType = DBDataTypes.VARCHAR)
	private String rejectReason;
	
	@ColumnMap(columnName = "CREATE_DATE", dbDataType = DBDataTypes.DATE)
	private Date createDate;

	public int getAuditFileUploadCommonId() {
		return auditFileUploadCommonId;
	}

	public void setAuditFileUploadCommonId(int auditFileUploadCommonId) {
		this.auditFileUploadCommonId = auditFileUploadCommonId;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNumber1() {
		return number1;
	}

	public void setNumber1(int number1) {
		this.number1 = number1;
	}

	public int getNumber2() {
		return number2;
	}

	public void setNumber2(int number2) {
		this.number2 = number2;
	}

	public int getNumber3() {
		return number3;
	}

	public void setNumber3(int number3) {
		this.number3 = number3;
	}

	public int getNumber4() {
		return number4;
	}

	public void setNumber4(int number4) {
		this.number4 = number4;
	}

	public int getNumber5() {
		return number5;
	}

	public void setNumber5(int number5) {
		this.number5 = number5;
	}

	public String getText1() {
		return text1;
	}

	public void setText1(String text1) {
		this.text1 = text1;
	}

	public String getText2() {
		return text2;
	}

	public void setText2(String text2) {
		this.text2 = text2;
	}

	public String getText3() {
		return text3;
	}

	public void setText3(String text3) {
		this.text3 = text3;
	}

	public String getText4() {
		return text4;
	}

	public void setText4(String text4) {
		this.text4 = text4;
	}

	public String getText5() {
		return text5;
	}

	public void setText5(String text5) {
		this.text5 = text5;
	}

	public String getText6() {
		return text6;
	}

	public void setText6(String text6) {
		this.text6 = text6;
	}

	public String getText7() {
		return text7;
	}

	public void setText7(String text7) {
		this.text7 = text7;
	}

	public String getText8() {
		return text8;
	}

	public void setText8(String text8) {
		this.text8 = text8;
	}

	public String getText9() {
		return text9;
	}

	public void setText9(String text9) {
		this.text9 = text9;
	}

	public String getText10() {
		return text10;
	}

	public void setText10(String text10) {
		this.text10 = text10;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getPresent() {
		return present;
	}

	public void setPresent(String present) {
		this.present = present;
	}
	
	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AuditFileUploadCommon [auditFileUploadCommonId=");
		builder.append(auditFileUploadCommonId);
		builder.append(", transId=");
		builder.append(transId);
		builder.append(", type=");
		builder.append(type);
		builder.append(", id=");
		builder.append(id);
		builder.append(", number1=");
		builder.append(number1);
		builder.append(", number2=");
		builder.append(number2);
		builder.append(", number3=");
		builder.append(number3);
		builder.append(", number4=");
		builder.append(number4);
		builder.append(", number5=");
		builder.append(number5);
		builder.append(", text1=");
		builder.append(text1);
		builder.append(", text2=");
		builder.append(text2);
		builder.append(", text3=");
		builder.append(text3);
		builder.append(", text4=");
		builder.append(text4);
		builder.append(", text5=");
		builder.append(text5);
		builder.append(", text6=");
		builder.append(text6);
		builder.append(", text7=");
		builder.append(text7);
		builder.append(", text8=");
		builder.append(text8);
		builder.append(", text9=");
		builder.append(text9);
		builder.append(", text10=");
		builder.append(text10);
		builder.append(", action=");
		builder.append(action);
		builder.append(", present=");
		builder.append(present);
		builder.append(", rejectReason=");
		builder.append(rejectReason);
		builder.append(", createDate=");
		builder.append(createDate);
		builder.append("]");
		return builder.toString();
	}
	
}
