package com.vzw.fuze.bulkupload.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.fuze.bulkupload.model.AuditFileUploadCommon;
import com.vzw.fuze.bulkupload.model.EnvBulkUpload;
import com.vzw.fuze.bulkupload.service.BulkUploadService;
import com.vzw.fuze.common.exception.DataNotFoundException;
import com.vzw.fuze.common.model.Document;
import com.vzw.fuze.common.model.User;
import com.vzw.fuze.common.service.UserInfoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**@author peacja7 **/


@RestController
@RequestMapping("/bulk-upload-service/bulk-upload")
@Api(value = "Bulk Upload Services")
public class BulkUploadController {
	
	private static Logger logger = LoggerFactory.getLogger(BulkUploadController.class.getName());

	@Autowired
	BulkUploadService bulkUploadService; 
	
	@Autowired
	UserInfoService userInfoService;
	
	@Autowired
	public BulkUploadController(UserInfoService pUserInfoService) {
	      this.userInfoService = pUserInfoService;
	}
	 	

	@RequestMapping(value = "/bulkCrownVCAUpload", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "Returns output details", notes = "Update Crown VCA Data from excell doc", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service", response = Boolean.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Boolean bulkCrownVCAUpload(@RequestHeader("user") String userJSON,@RequestBody Document document) throws Exception {
		logger.info("RELM-SERVICE : bulkCrownVCAUpload is called for by {} ",  userInfoService.getUserInfo());
		return bulkUploadService.bulkCrownVCAUpload(document);
	}
	
	@RequestMapping(value = "/bulkContractNbrInsert", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "Returns output details", notes = "Inserts Contract numbers", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service", response = Boolean.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Boolean bulkContractNbrInsert(@RequestHeader("user") String userJSON, @RequestBody Map<String, Object> command) throws Exception {
		logger.info("RELM-SERVICE : bulkCrownVCAUpload is called for by {} ",  userInfoService.getUserInfo());
		return bulkUploadService.bulkContractNbrInsert(command);
	}
	
	@RequestMapping(value = "/bulkUpdateCRANOnefiber", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "Returns output details", notes = "Update CRAN data in Onefiber", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service", response = Boolean.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Boolean bulkUpdateCRANOnefiber(@RequestHeader("user") String userJSON) throws Exception {
		logger.info("BULK-UPLOAD-SERVICE : bulkUpdateCRANOnefiber is called for by {} ",  userInfoService.getUserInfo());
		return bulkUploadService.bulkUpdateCRANOnefiber();
	}
	
	@RequestMapping(value = "/bulkAbstraction", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "Returns output details", notes = "Upload Bulk Abstraction Data from excel doc", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service", response = Boolean.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Boolean bulkAbstraction(@RequestHeader("user") String userJSON,@RequestBody Document document) throws Exception {
		logger.info("RELM-SERVICE : bulkAbstraction is called for by {} ",  userInfoService.getUserInfo());
		return bulkUploadService.bulkAbstraction(document,userJSON);
	}
	@RequestMapping(value = "/bulkUpdateSTReference", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public boolean bulkUpdateSTReference(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		
		final User user = userInfoService.getUserInfo();
		
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null : s).orElseThrow(() -> new DataNotFoundException("Document path is mandatory"));
		
		final boolean success = bulkUploadService.bulkUpdateSTReference(document, user);
		logger.info("BULK-UPLOAD-SERVICE : Update information {} by User {}", document, user);
		return success;
	}
	
	@RequestMapping(value = "/bulkSitetrakerSyncFuzeToST", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)

	public boolean bulkSitetrakerSyncFuzeToST(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		
		final User user = userInfoService.getUserInfo();
		
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null : s).orElseThrow(() -> new DataNotFoundException("Document path is mandatory"));
		
		final boolean success = bulkUploadService.bulkSitetrakerSyncFuzeToST(document, user);
		logger.info("BULK-UPLOAD-SERVICE : Update information {} by User {}", document, user);
		return success;
	}
	
	@RequestMapping(value = "/bulkSitetrakerSyncSTToFuze", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)

	public boolean bulkSitetrakerSyncSTToFuze(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		
		final User user = userInfoService.getUserInfo();
		
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null : s).orElseThrow(() -> new DataNotFoundException("Document path is mandatory"));
		
		final boolean success = bulkUploadService.bulkSitetrakerSyncSTToFuze(document, user);
		logger.info("BULK-UPLOAD-SERVICE : Update information {} by User {}", document, user);
		return success;
	}
	
	@RequestMapping(value = "/bulkSarfUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)

	public boolean bulkSarfUpdate(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		
		final User user = userInfoService.getUserInfo();
		
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null : s).orElseThrow(() -> new DataNotFoundException("Document path is mandatory"));
		
		final boolean success = bulkUploadService.bulkSarfUpdate(document, user);
		logger.info("BULK-UPLOAD-SERVICE : Update information {} by User {}", document, user);
		return success;
	}
	
	@RequestMapping(value = "/bulkProjectStatusUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public boolean bulkProjectStatusUpdate(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		
		logger.info("PROJECTS_SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		final User user = userInfoService.getUserInfo();
		
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null : s).orElseThrow(() -> new DataNotFoundException("Document path is mandatory"));
		
		final boolean success = bulkUploadService.bulkProjectStatusUpdate(document, user);
		
		logger.info("BULK-UPLOAD-SERVICE : Update information {} by User {}", document, user);
		
		return success;
	}
	
	@RequestMapping(value = "/bulkSiteTrakerCreate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public boolean bulkSiteTrakerCreate(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {

		logger.info("PROJECTS_SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());

		final User user = userInfoService.getUserInfo();

		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null : s).orElseThrow(() -> new DataNotFoundException("Document path is mandatory"));

		final boolean success = bulkUploadService.bulkSiteTrakerCreate(document, user);

		logger.info("BULK-UPLOAD-SERVICE : Update information {} by User {}", document, user);

		return success;
	}

	@RequestMapping(value = "/bulkTaskUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON,
			consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public boolean bulkTaskUpdate(@RequestHeader("user") String userJSON, @RequestBody Document document) throws
			Exception {

		logger.info("PROJECTS_SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());

		final User user = userInfoService.getUserInfo();

		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null : s).orElseThrow(() -> new DataNotFoundException("Document path is mandatory"));

		final boolean success = bulkUploadService.bulkTaskUpdate(document, user);

		logger.info("BULK-UPLOAD-SERVICE : Update information {} by User {}", document, user);

		return success;
	}
	
	@RequestMapping(value = "/bulkProjPlscUpload", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public boolean bulkProjPlscUpload(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("PROJECTS_SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null : s).orElseThrow(() -> new DataNotFoundException("Document path is mandatory"));
		final boolean success = bulkUploadService.bulkProjPlscUpload(user, document);
		logger.info("BULK-UPLOAD-SERVICE : Update information {} by User {}", document, user);
		return success;
	}
	
	@RequestMapping(value = "/bulkUploadE911", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public boolean bulkUploadE911(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		final boolean uploadStatus = bulkUploadService.bulkUploadE911(user,document);
		return uploadStatus;
		
	}
	
	@RequestMapping(value = "/bulkUploadCQ", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public boolean bulkUploadCQ(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		final boolean uploadStatus = bulkUploadService.bulkUploadCQ(user,document);
		return uploadStatus;
		
	}
	
	@RequestMapping(value = "/bulkUploadSiteTrackerSiteInfoId", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public boolean bulkUploadSiteTrackerSiteInfoId(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		final boolean uploadStatus = bulkUploadService.bulkUploadSiteTrackerSiteInfoId(user,document);
		return uploadStatus;
		
	}
	
	@RequestMapping(value = "/bulkUpdateSiteUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Map<String, List<AuditFileUploadCommon>> bulkUpdateSiteUpdate(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		return bulkUploadService.bulkUpdateSiteUpdate(user, document);
		
	}
	
	@RequestMapping(value = "/bulkUploadCranFinalAndCurrentHubs", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Cran Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	
	public boolean bulkUploadCranFinalAndCurrentHubs(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		final boolean uploadStatus = bulkUploadService.bulkUploadCranFinalAndCurrentHubs(user,document);
		return uploadStatus;
		
	}
	
	@RequestMapping(value = "/bulkUploadCranHubInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Cran Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	
	public boolean bulkUploadCranHubInfo(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		final boolean uploadStatus = bulkUploadService.bulkUploadCranHubInfo(user,document);
		return uploadStatus;
		
	}
	
	@RequestMapping(value = "/bulkTrackerDataUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Cran Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	
	public boolean bulkTrackerDataUpdate(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final ObjectMapper objectMapper = new ObjectMapper();
		final User user = objectMapper.readValue(userJSON, User.class);
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		final boolean uploadStatus = bulkUploadService.bulkTrackerDataUpdate(user,document);
		return uploadStatus;
		
	}
	
	@RequestMapping(value = "/bulkSiteTrackerAttrUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Map<String, List<AuditFileUploadCommon>> bulkSiteTrackerAttrUpdate(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		return bulkUploadService.bulkSiteTrackerAttrUpdate(user,document);
		
	}
	
	@RequestMapping(value = "/bulkPslcUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Map<String, List<AuditFileUploadCommon>> bulkPslcUpdate(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		return bulkUploadService.bulkPslcUpdate(user,document);
		
	}
	
	@RequestMapping(value = "/bulkLocationCreation", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Map<String, List<AuditFileUploadCommon>> bulkLocationCreation(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		return bulkUploadService.bulkLocationCreation(user,document);
		
	}
	
	@RequestMapping(value = "/bulkUploadSpmToGranite", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Map<String, List<AuditFileUploadCommon>> bulkUploadSpmToGranite(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		return bulkUploadService.bulkUploadSpmToGranite(user,document);
		
	}
	
	@RequestMapping(value = "/bulkEnvUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public List<EnvBulkUpload> bulkEnvUpdate(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final ObjectMapper objectMapper = new ObjectMapper();
		final User user = objectMapper.readValue(userJSON, User.class);
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		return bulkUploadService.bulkEnvUpdate(user,document);
	}	
		
	@RequestMapping(value = "/transportFieldUpdatesOneFOnBoarding", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Document Service")
	@ApiResponses(value = {
				@ApiResponse(code = 200, message = "Successful retrieval service"),
				@ApiResponse(code = 400, message = "Invalid input provided"),
				@ApiResponse(code = 404, message = "Data does not exist"), })
		@ResponseStatus(value = HttpStatus.OK)
	public List<Map<String,String>> transportFieldUpdatesOneFOnBoarding(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		return bulkUploadService.transportFieldUpdatesOneFOnBoarding(user,document);
		
	}
	
	@RequestMapping(value = "/searchBulkUploads", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Document Service", response = AuditFileUploadCommon.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful retrieval service", response = AuditFileUploadCommon.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)

	public List<AuditFileUploadCommon> searchBulkUploads(@RequestHeader("user") String userJSON,
			@RequestBody AuditFileUploadCommon auditFileUploadCommon) throws Exception {

		final User user = userInfoService.getUserInfo();

		logger.info("BULKUPLOAD_SERVICE searchBulkUploads Function {} for user{} ", auditFileUploadCommon, user);
		return bulkUploadService.searchBulkUploads(auditFileUploadCommon, user);
	}
	
	@RequestMapping(value = "/bulkOnefiberOrderCreation", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Returns output details", notes = "Bulk Upload Service")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service"),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Map<String, List<AuditFileUploadCommon>> bulkOnefiberOrderCreation(@RequestHeader("user") String userJSON, @RequestBody Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName());
		final User user = userInfoService.getUserInfo();
		Optional.ofNullable(document.getPath()).map(s -> s.isEmpty() ? null:s).orElseThrow(() -> new DataNotFoundException("Document Path Mandatory"));
		return bulkUploadService.bulkOnefiberOrderCreation(user, document);
		
	}
}
