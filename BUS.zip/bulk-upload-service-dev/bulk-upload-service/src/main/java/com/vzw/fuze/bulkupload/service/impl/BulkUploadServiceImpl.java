package com.vzw.fuze.bulkupload.service.impl;

import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.vzw.fuze.bulkupload.dao.BulkUploadDao;
import com.vzw.fuze.bulkupload.model.AuditFileUploadCommon;
import com.vzw.fuze.bulkupload.model.EnvBulkUpload;
import com.vzw.fuze.bulkupload.service.BulkUploadService;
import com.vzw.fuze.bulkupload.utils.ParseExcelUtils;
import com.vzw.fuze.common.ipc.feign.EmailServiceClient;
import com.vzw.fuze.common.model.Document;
import com.vzw.fuze.common.model.EmailQueue;
import com.vzw.fuze.common.model.User;
import com.vzw.fuze.common.util.CommonUtils;

@Component("bulkUploadService")
public class BulkUploadServiceImpl implements BulkUploadService {
	
	private final static Logger logger = LoggerFactory.getLogger(BulkUploadServiceImpl.class.getName());

	@Autowired
	BulkUploadDao bulkUploadDao;
	
	@Autowired
	@Qualifier("ribbonEmailServiceClient")
	EmailServiceClient emailServiceClient;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public Boolean bulkCrownVCAUpload(Document document) throws Exception {
		
		logger.debug("BULK-UPLOAD-SERVICE: Inside {}.", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		final String finalURL = document.getPath().replaceAll(" ", "%20");

		final String scriptNameAndCommand = "sh /apps/opt/fuze/scripts/real-estate/bulk-upload/bulk-upload-vca-crown.sh "+finalURL;
	    logger.info("BULK-UPLOAD-SERVICE: Finished File Upload; Starting Script Execution");
	    return executeJSch(scriptNameAndCommand  , finalURL);
	}
	
	private Boolean executeJSch(String shellCommand, String params) throws Exception {
	    logger.info("BULK-UPLOAD-SERVICE: Executing: {} ", shellCommand);

		Process process = Runtime.getRuntime().exec(shellCommand);
		return true;
	}
	
	
	
	@Override 
	public Boolean bulkUpdateCRANOnefiber() throws Exception { 
	 	  
	 	logger.debug("BULK-UPLOAD-SERVICE: Inside {}.", Thread.currentThread().getStackTrace()[1].getMethodName()); 

	 	//final String scriptNameAndCommand = "sh /apps/opt/fuze/scripts/real-estate/cran-onefiber-project-update.sh "; 
	 	final String scriptNameAndCommand = "/apps/opt/fuze/scripts/real-estate/cran-onefiber-project-update.sh >> /apps/opt/fuze/logs/cran-onefiber-project-update.sh.`date +\\%m\\%d\\%Y`.log 2>&1";
	    logger.info("BULK-UPLOAD-SERVICE : Starting CRAN-Onefiber Script Execution"); 
	    return executeJSch(scriptNameAndCommand   , null); 
	 } 
	
	
	@Override
	public boolean bulkContractNbrInsert(Map<String, Object> command) throws Exception {
		final String finalURL = command.get("path").toString().replaceAll(" ", "%20");
		final String batchId =  (String)command.get("batchId");
		final String scriptAndCommand = "sh " + "/apps/opt/fuze/scripts/real-estate/bulk-upload/netsites-bulk-contract-insert.sh " + finalURL + " " + batchId +">> /apps/opt/fuze/logs/netsites-bulk-contract-insert.sh.`date +\\%m\\%d\\%Y`.log 2>&1";
		return executeJSch(scriptAndCommand, null);
	}
	
	@Override
	public Boolean bulkAbstraction(Document document,String userJSON) throws Exception {
		
		logger.debug("BULK-UPLOAD-SERVICE: Inside {}.", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		final String finalURL = document.getPath().replaceAll(" ", "%20");
		final ObjectMapper mapper = new ObjectMapper();
		final User user = mapper.readValue(userJSON, User.class);
		String userName = user.getFirstName()+ user.getLastName();
		StringBuilder userInfo = new StringBuilder(finalURL);
		userInfo.append(user.getUserId()+" "+userName+" "+user.getEmail());
		
		final String scriptNameAndCommand = "sh /apps/opt/fuze/scripts/real-estate/bulk-upload/bulk-abstraction.sh "+userInfo;
	    logger.info("BULK-UPLOAD-SERVICE: Finished File Upload; Starting Script Execution");
	    return executeJSch(scriptNameAndCommand  , finalURL);
	}
	
	@Override
	public boolean bulkUpdateSTReference(Document document, User user) throws Exception {
		
		InputStream inputStream = null;
		boolean success = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			logger.info("BULK-UPLOAD-SERVICE : finalUR is :  {}", finalURL);
			
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("ST_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			
			try {
				success = bulkUploadDao.bulkUpdateSTReference(criteria);
				logger.debug("BULK-UPLOAD-SERVICE : bulkUpdateSTReference status :  {}", success);
			} catch (final Exception e) {
				e.printStackTrace();
			}
		} catch (final Exception e) {
			logger.error("BULK-UPLOAD-SERVICE : Error in  bulkUpdateSTReference ", e.getMessage());
			e.printStackTrace();
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (final Exception ignore) {
			}
		}
		logger.info("BULK-UPLOAD-SERVICE : returning from  {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		
		return success;
	}

	@Override
	public boolean bulkSitetrakerSyncFuzeToST(Document document, User user) throws Exception {
	
		InputStream inputStream = null;
		boolean success = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			logger.info("BULK-UPLOAD-SERVICE : finalUR is :  {}", finalURL);
			inputStream = new URL(finalURL).openStream();
			
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("ST_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			
			try {
				success = bulkUploadDao.bulkSitetrakerSyncFuzeToST(criteria);
				logger.debug("BULK-UPLOAD-SERVICE : bulkSitetrakerSyncFuzeToST status :  {}", success);
			} catch (final Exception e) {
				e.printStackTrace();
			}
		} catch (final Exception e) {
			logger.error("BULK-UPLOAD-SERVICE : Error in  bulkSyncUpdate ", e.getMessage());
			e.printStackTrace();
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (final Exception ignore) {
			}
		}
		logger.info("BULK-UPLOAD-SERVICE : returning from  {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		return success;
	}
	
	@Override
	public boolean bulkSitetrakerSyncSTToFuze(Document document, User user) throws Exception {
	
		InputStream inputStream = null;
		boolean success = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			logger.info("BULK-UPLOAD-SERVICE : finalUR is :  {}", finalURL);
			inputStream = new URL(finalURL).openStream();
			
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("ST_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			
			try {
				success = bulkUploadDao.bulkSitetrakerSyncSTToFuze(criteria);
				logger.debug("BULK-UPLOAD-SERVICE : bulkSitetrakerSyncSTToFuze status :  {}", success);
			} catch (final Exception e) {
				e.printStackTrace();
			}
		} catch (final Exception e) {
			logger.error("BULK-UPLOAD-SERVICE : Error in  bulkSitetrakerSyncSTToFuze ", e.getMessage());
			e.printStackTrace();
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (final Exception ignore) {
			}
		}
		logger.info("BULK-UPLOAD-SERVICE : returning from  {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		return success;
	}

	@Override
	public boolean bulkSarfUpdate(Document document, User user) throws Exception {
		
		InputStream inputStream = null;
		boolean success = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			logger.info("BULK-UPLOAD-SERVICE : finalUR is :  {}", finalURL);
			inputStream = new URL(finalURL).openStream();
			
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("SARF_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			
			try {
				success = bulkUploadDao.bulkSarfUpdate(criteria);
				logger.debug("BULK-UPLOAD-SERVICE : bulkSarfUpdate status :  {}", success);
			} catch (final Exception e) {
				e.printStackTrace();
			}
		} catch (final Exception e) {
			logger.error("BULK-UPLOAD-SERVICE : Error in  bulkSarfUpdate ", e.getMessage());
			e.printStackTrace();
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (final Exception ignore) {
			}
		}
		logger.info("BULK-UPLOAD-SERVICE : returning from  {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		return success ;
	}
	
	@Override
	public boolean bulkProjectStatusUpdate(Document document, User user) throws Exception {
		
		logger.info("BULK-UPLOAD-SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		InputStream inputStream = null;
		boolean success = false;
		
		try {
			
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();

			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteria);
			success = bulkUploadDao.bulkProjectStatusUpdate(criteria);
			
		} catch (final Exception e) {
			
			logger.error("BULK-UPLOAD-SERVICE : Exception {} in {}", e.getMessage(), Thread.currentThread().getStackTrace()[1].getMethodName());
			e.printStackTrace();
			throw e;
			
		} finally {
			
			try {
				inputStream.close();
			} catch (final Exception e) {
				logger.error("BULK-UPLOAD-SERVICE : Exception {} in {}", e.getMessage(), Thread.currentThread().getStackTrace()[1].getMethodName());
				e.printStackTrace();
				throw e;
			}
		}
		logger.info("BULK-UPLOAD-SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		return success ;
	}

	@Override
	public boolean bulkSiteTrakerCreate(Document document, User user) throws Exception {
		
		logger.info("BULK-UPLOAD-SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		InputStream inputStream = null;
		boolean success = false;
		
		try {
			
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();

			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteria);
			success = bulkUploadDao.bulkSiteTrakerCreate(criteria);
			
		} catch (final Exception e) {
			
			logger.error("BULK-UPLOAD-SERVICE : Exception {} in {}", e.getMessage(), Thread.currentThread().getStackTrace()[1].getMethodName());
			e.printStackTrace();
			throw e;
			
		} finally {
			
			try {
				inputStream.close();
			} catch (final Exception e) {
				logger.error("BULK-UPLOAD-SERVICE : Exception {} in {}", e.getMessage(), Thread.currentThread().getStackTrace()[1].getMethodName());
				e.printStackTrace();
				throw e;
			}
		}
		logger.info("BULK-UPLOAD-SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		return success ;
	}

	@Override
	public boolean bulkTaskUpdate(Document document, User user) throws Exception {
		logger.info("BULK-UPLOAD-SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());

		InputStream inputStream = null;
		boolean success = false;

		try {

			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();

			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);

			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteria);
			success = bulkUploadDao.bulkTaskUpdate(criteria);

		} catch (final Exception e) {

			logger.error("BULK-UPLOAD-SERVICE : Exception {} in {}", e.getMessage(), Thread.currentThread().getStackTrace()[1].getMethodName());
			e.printStackTrace();
			throw e;

		} finally {

			try {
				inputStream.close();
			} catch (final Exception e) {
				logger.error("BULK-UPLOAD-SERVICE : Exception {} in {}", e.getMessage(), Thread.currentThread().getStackTrace()[1].getMethodName());
				e.printStackTrace();
				throw e;
			}
		}
		logger.info("BULK-UPLOAD-SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		return success ;
	}
	
	@Override
	public boolean bulkProjPlscUpload(User user,Document document) throws Exception {
		logger.info("BULK-UPLOAD-SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		boolean uploadStatus = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);

			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			logger.debug("BULK-UPLOAD-SERVICE : criteriaDetailsList is :  {}", criteria);
			uploadStatus = bulkUploadDao.bulkProjPlscUpload(criteria);

		} catch (final Exception e) {
			logger.error("BULK-UPLOAD-SERVICE : Exception {} in {}", e, Thread.currentThread().getStackTrace()[1].getMethodName());
			throw e;

		} finally {
			try {
				inputStream.close();
			} catch (final Exception e) {
				logger.error("BULK-UPLOAD-SERVICE : Exception {} in {}", e, Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULK-UPLOAD-SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), uploadStatus);
		return uploadStatus ;
	}
	
	@Override
	public boolean bulkUploadE911(User user, Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		boolean uploadStatus = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			uploadStatus = bulkUploadDao.bulkUploadE911(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulkUploadE911 ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), uploadStatus);
		return uploadStatus;
	}
	
	@Override
	public boolean bulkUploadCQ(User user, Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		boolean uploadStatus = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			uploadStatus = bulkUploadDao.bulkUploadCQ(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulkUploadE911 ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), uploadStatus);
		return uploadStatus;
	}
	
	@Override
	public boolean bulkUploadSiteTrackerSiteInfoId(User user, Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		boolean uploadStatus = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			uploadStatus = bulkUploadDao.bulkUploadSiteTrackerSiteInfoId(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulkUploadSiteTrackerSiteInfoId ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), uploadStatus);
		return uploadStatus;
	}

	@Override
	public Map<String, List<AuditFileUploadCommon>> bulkUpdateSiteUpdate(User user, Document document) throws Exception {
		
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		InputStream inputStream = null;
		Map<String, List<AuditFileUploadCommon>> resultList;
		
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("SITE_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			resultList = bulkUploadDao.bulkUpdateSiteUpdate(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulkUpdateSiteUpdate ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), resultList);
		return resultList;

	}
	
	@Override
	public boolean bulkUploadCranFinalAndCurrentHubs(User user, Document document) throws Exception {
		
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		InputStream inputStream = null;
		boolean success = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			logger.info("BULKUPLOAD_SERVICE : finalUR is :  {}", finalURL);
			inputStream = new URL(finalURL).openStream();
			
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("CRAN_BULK_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			
			try {
				success = bulkUploadDao.bulkUploadCranFinalAndCurrentHubs(criteria);
				logger.debug("BULKUPLOAD_SERVICE : bulkUploadCranFinalAndCurrentHubs status :  {}", success);
			} catch (final Exception e) {
				e.printStackTrace();
			}
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in  bulkUploadCranFinalAndCurrentHubs ", e.getMessage());
			e.printStackTrace();
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (final Exception ignore) {
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning from  {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		return success;
	}

	@Override
	public boolean bulkUploadCranHubInfo(User user, Document document) throws Exception {
		InputStream inputStream = null;
		boolean success = false;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			logger.info("BULKUPLOAD_SERVICE : finalUR is :  {}", finalURL);
			inputStream = new URL(finalURL).openStream();
			
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("CRAN_BULK_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			
			try {
				success = bulkUploadDao.bulkUploadCranHubInfo(criteria);
				logger.debug("BULKUPLOAD_SERVICE : bulkUploadCranHubInfo status :  {}", success);
			} catch (final Exception e) {
				e.printStackTrace();
			}
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in  bulkUploadCranHubInfo ", e.getMessage());
			e.printStackTrace();
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (final Exception ignore) {
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning from  {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		return success;
	}

	@Override
	public boolean bulkTrackerDataUpdate(User user, Document document) throws Exception {
        
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		List<Map<String,String>> failedList = new ArrayList<Map<String,String>>();

		InputStream inputStream = null;
		boolean success = true;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			logger.info("BULKUPLOAD_SERVICE : finalUR is :  {}", finalURL);
			inputStream = new URL(finalURL).openStream();
			
			final XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			long numWorkbooks = workbook.getNumberOfSheets() - 1;
			
			for (int i = 0; i < numWorkbooks; i++) {
				String sheetName = workbook.getSheetName(i);
				final XSSFSheet sheet = workbook.getSheetAt(i);
				if("Transport Vendor Update".equalsIgnoreCase(sheetName)) {
					final List<DataSourceCriteria> criteriaDetailsList = ParseExcelUtils.getCriteriaBasedOnSheet(sheet);
					logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

					LocalDateTime localDateAndTime = LocalDateTime.now();
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
					String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
					
					DataSourceCriteria criteria = new DataSourceCriteria();
					criteria.put("_SQL_LOOPING_", true);
					criteria.put("PROJ_DATA", criteriaDetailsList);
					criteria.put(User.COL_USER_ID, user.getUserId());
					criteria.put("TRANS_ID", uid);
					logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
					
					try {
						List<Map<String,String>> failedProjectId = bulkUploadDao.transportFieldUpdatesOneFOnBoarding(criteria);
						if(!failedProjectId.isEmpty()) {
							failedList.addAll(failedProjectId); 
						}
					} catch (final Exception e) {
						e.printStackTrace();
					}
					
					
				}else {
					final List<JSONObject> dataList = ParseExcelUtils.parseExcelTemplateForJson(sheet);
					logger.debug("BULKUPLOAD_SERVICE : dataList is :  {}", dataList);
						
					dataList.stream().forEach(data -> {
						DataSourceCriteria criteria = new DataSourceCriteria();				
						criteria.put("BULK_DATA", data.toString());
						criteria.put(User.COL_USER_ID, user.getUserId());
						criteria.put("MILESTONE", sheetName);
					
						try {
							Map<String,String> failedProjectId = bulkUploadDao.bulkTrackerDataUpdate(criteria);
							if(!failedProjectId.isEmpty()) {
								failedList.add(failedProjectId); 
							}
						} catch (final Exception e) {
							e.printStackTrace();
						}
					});
				}
			}
			if(failedList.size() > 0) {
				success = false;
			}
			sendEmailForTrackerUpdate(document,user,success,failedList);
			logger.debug("BULKUPLOAD_SERVICE : bulkTrackerUpdate status :  {}", success);
			
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in  bulkTrackerUpdate ", e.getMessage());
			e.printStackTrace();
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (final Exception ignore) {
			}
		}	
			
		logger.info("BULKUPLOAD_SERVICE : returning from  {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), success);
		return success;
	}
    
	private void sendEmailForTrackerUpdate(Document document,User user,boolean success,List<Map<String, String>> failedList) throws Exception {
		EmailQueue emailQueue = new EmailQueue();

		emailQueue.setEmailType("TEXT");
		emailQueue.setRefType("SYSTEM_NOTIFICATION");
		emailQueue.setRefSubType("BULK_TRACKER_UPDATE");
		emailQueue.setRefNum(document.getDocumentID());
		
		JSONObject refData =  new JSONObject();
		refData.put("SUCCESS",success ? "true" : "false");
		refData.put("PROJECT_IDS", failedList);
		refData.put("DOCUMENT_PATH", document.getPath());
		refData.put("TO_LIST", user.getEmail());
		refData.put("CC_LIST", "FUZE-SITENProjects@one.verizon.com");
		
		emailQueue.setRefData(refData.toString());
		
		logger.info("BULKUPLOAD_SERVICE : returning from  {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), emailQueue);
		
		emailServiceClient.mergeEmailQueue(emailQueue, user);
	}
	
	@Override
	public Boolean bulkActionItemEventCreation(Document document) throws Exception {
		
		logger.debug("BULK-UPLOAD-SERVICE: Inside {}.", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		final String finalURL = document.getPath().replaceAll(" ", "%20");
		final String scriptNameAndCommand = "sh /apps/opt/fuze/scripts/real-estate/bulk-upload-action-item-create.sh "+finalURL;
	    logger.info("BULK-UPLOAD-SERVICE: Finished File Upload; Starting Script Execution");
	    return executeJSch(scriptNameAndCommand  , finalURL);
	}
	
	@Override
	public Map<String, List<AuditFileUploadCommon>> bulkSiteTrackerAttrUpdate(User user, Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		Map<String, List<AuditFileUploadCommon>> resultList;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			resultList = bulkUploadDao.bulkSiteTrackerAttrUpdate(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulSiteTrackerAttrUpdate ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), resultList);
		return resultList;
	}
	
	@Override
	public Map<String, List<AuditFileUploadCommon>> bulkPslcUpdate(User user, Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		Map<String, List<AuditFileUploadCommon>> resultList;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			resultList = bulkUploadDao.bulkPslcUpdate(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulSiteTrackerAttrUpdate ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), resultList);
		return resultList;
	}
	
	@Override
	public Map<String, List<AuditFileUploadCommon>> bulkLocationCreation(User user, Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		Map<String, List<AuditFileUploadCommon>> resultList;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			resultList = bulkUploadDao.bulkLocationCreation(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulSiteTrackerAttrUpdate ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), resultList);
		return resultList;
	}
	
	@Override
	public Map<String, List<AuditFileUploadCommon>> bulkUploadSpmToGranite(User user, Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		Map<String, List<AuditFileUploadCommon>> resultList;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			resultList = bulkUploadDao.bulkUploadSpmToGranite(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulSiteTrackerAttrUpdate ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), resultList);
		return resultList;
	}

	@Override
	public List<EnvBulkUpload> bulkEnvUpdate(User user, Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		List<EnvBulkUpload> resultList = new ArrayList<EnvBulkUpload>();
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final DataSourceCriteria criteria = ParseExcelUtils.parseExcelTemplateWithMultipleSheets(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteria is :  {}", criteria);

			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			criteria.put("_SQL_LOOPING_", true);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			resultList = bulkUploadDao.bulkEnvUpdate(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulkEnvUpdate ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), resultList);
		return resultList;
	}
	
	@Override 
	public List<Map<String,String>> transportFieldUpdatesOneFOnBoarding(User user, Document document) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		InputStream inputStream = null;
		List<Map<String,String>> resultList;
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);

			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("PROJ_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			resultList = bulkUploadDao.transportFieldUpdatesOneFOnBoarding(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in transportFieldUpdatesOneFOnBoarding ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), resultList);
		return resultList;
	}

	@Override
	public List<AuditFileUploadCommon> searchBulkUploads(AuditFileUploadCommon auditFileUploadCommon, User user) throws Exception {
		return bulkUploadDao.searchBulkUploads(auditFileUploadCommon);
	}

	@Override
	public Map<String, List<AuditFileUploadCommon>> bulkOnefiberOrderCreation(User user, Document document) throws Exception {
		
		logger.info("BULKUPLOAD_SERVICE : entering", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		InputStream inputStream = null;
		Map<String, List<AuditFileUploadCommon>> resultList;
		
		try {
			final String finalURL = document.getPath().replaceAll(" ", "%20");
			inputStream = new URL(finalURL).openStream();
			final List<DataSourceCriteria> criteriaDetailsList = CommonUtils.parseExcelTemplate(inputStream, user);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteriaDetailsList);
			
			LocalDateTime localDateAndTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
			String uid = user.getUserId() + "_" + localDateAndTime.format(formatter);
			String apiURI ="http://localhost:9058/order-processing/createOneFiberOrder";
			JSONObject JsonObject = new JSONObject();
			if (CollectionUtils.isNotEmpty(criteriaDetailsList)) {
				for (DataSourceCriteria criteria : criteriaDetailsList) {
					ResponseEntity<String> response = null;
					final ObjectMapper mapper = new ObjectMapper();
					HttpHeaders headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_JSON);
					String userJson = mapper.writeValueAsString(user);
					JsonObject.put("requestType", criteria.get("request_type"));
					JsonObject.put("region", criteria.get("region"));
					JsonObject.put("technologyType", criteria.get("technology_type"));
					//JsonObject.put("region", criteria.get("action"));
					JsonObject.put("projectId", criteria.get("project_id"));
					JsonObject.put("requestedDate", criteria.get("requested_date"));
					JsonObject.put("mustHaveDate", criteria.get("must_have_date"));
					JsonObject.put("bandWidth", criteria.get("bandwidth"));
					JsonObject.put("strands", criteria.get("no_of_strands"));
					JsonObject.put("siteA", criteria.get("a-loc_granite_site_name"));
					JsonObject.put("siteZ", criteria.get("z-loc_granite_site_name"));
					JsonObject.put("comments", criteria.get("comments"));
					JsonObject.put("name", criteria.get("contact_name"));
					JsonObject.put("phone", criteria.get("contact_phone"));
					JsonObject.put("userEmail", criteria.get("contact_email"));
					headers.add("user", userJson);
					String encodedURL = apiURI;
					HttpEntity<Object> request = new HttpEntity<Object>(JsonObject, headers);
					logger.info("Execute POST Request API with url : {}   \n Request {} \n headers {}  ", encodedURL,
							request, headers);
					response = restTemplate.exchange(new URI(encodedURL), HttpMethod.POST, request, String.class);
					if (response != null && response.getStatusCode().equals("200")) {
						logger.info("****", response.getBody());
					} else {
						criteria.put("Reason", response.toString());
					}
				}
			}
			DataSourceCriteria criteria = new DataSourceCriteria();
			criteria.put("_SQL_LOOPING_", true);
			criteria.put("ONEFIBER_ORDER_DATA", criteriaDetailsList);
			criteria.put(User.COL_USER_ID, user.getUserId());
			criteria.put("TRANS_ID", uid);
			logger.debug("BULKUPLOAD_SERVICE : criteriaDetailsList is :  {}", criteria);
			resultList = bulkUploadDao.bulkOnefiberOrderCreation(criteria);

		} catch (Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Exception in bulkUpdateSiteUpdate ", e);
			throw e;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				logger.error("BULKUPLOAD_SERVICE : Exception {} in {}", e,Thread.currentThread().getStackTrace()[1].getMethodName());
				throw e;
			}
		}
		logger.info("BULKUPLOAD_SERVICE : returning {} with status {}", Thread.currentThread().getStackTrace()[1].getMethodName(), resultList);
		return resultList;

	}
}