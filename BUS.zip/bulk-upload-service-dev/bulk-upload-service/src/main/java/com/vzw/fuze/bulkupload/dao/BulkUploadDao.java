
package com.vzw.fuze.bulkupload.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.verizon.webkit.util.Transformers;
import com.vzw.fuze.bulkupload.model.AuditFileUploadCommon;
import com.vzw.fuze.bulkupload.model.EnvBulkUpload;
import com.vzw.fuze.bulkupload.utils.DataCloudServices;

@Component
public class BulkUploadDao {

	private final static Logger logger = LoggerFactory.getLogger(BulkUploadDao.class.getName());
	
	public Map<String, List<AuditFileUploadCommon>> bulkUploadResultList(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );

			List<AuditFileUploadCommon> successList = new ArrayList<AuditFileUploadCommon>();
			List<AuditFileUploadCommon> failedList = new ArrayList<AuditFileUploadCommon>();
			Map<String, List<AuditFileUploadCommon>> resultList = new LinkedHashMap<String, List<AuditFileUploadCommon>>();
			
			try {
				DataSourceResultSet successResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkUpdateSuccess, criteria); 
				if(successResult.getRowCount()>0){
					successResult.getRows().stream().forEach( ds -> {
						try {
							successList.add(Transformers.getPojoFromDataSourceResult(AuditFileUploadCommon.class, ds));
						} catch (Exception e) {
							e.printStackTrace();
						}
					});
				}
				resultList.put("successList", successList);
				
				DataSourceResultSet failedResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkUpdateFailed, criteria);
				if(failedResult.getRowCount()>0){
					failedResult.getRows().stream().forEach( ds -> {
						try {
							failedList.add(Transformers.getPojoFromDataSourceResult(AuditFileUploadCommon.class, ds));
						} catch (Exception e) {
							e.printStackTrace();
						}
					});
				}
				resultList.put("failedList", failedList);
			} catch (Exception e) {
				logger.error("BULK_UPLOAD_SERVICE : Error in bulkUploadResultList Dao {}", e.getMessage());
				e.printStackTrace();
				throw e;
			}
		
		return resultList;
	}
	
	public boolean bulkUpdateSTReference(DataSourceCriteria criteria) throws Exception {
		boolean success;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkUpdateSTReference, criteria);
			success = wsResult.getRowCount() > 0;
			
		} catch (final Exception e) {
			logger.error("PROJECTS_SERVICE : Error in bulkUpdateSTReference Dao {}", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return success;

	}
	
	public boolean bulkSitetrakerSyncFuzeToST(DataSourceCriteria criteria) throws Exception {
		boolean success;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkSitetrakerSyncFuzeToST,criteria);
			success = wsResult.getRowCount() > 0;
		} catch (final Exception e) {
			logger.error("PROJECTS_SERVICE : Error in bulkSitetrakerSyncFuzeToST Dao {}", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return success;

	}
	
	public boolean bulkSitetrakerSyncSTToFuze(DataSourceCriteria criteria) throws Exception {
		boolean success;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkSitetrakerSyncSTtoFuze,criteria);
			success = wsResult.getRowCount() > 0;
		} catch (final Exception e) {
			logger.error("PROJECTS_SERVICE : Error in bulkSitetrakerSyncSTToFuze Dao {}", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return success;

	}
	
	public boolean bulkSarfUpdate(DataSourceCriteria criteria) throws Exception {
		boolean success;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkSarfUpdate, criteria);
			success = wsResult.getRowCount() > 0;
		} catch (final Exception e) {
			logger.error("PROJECTS_SERVICE : Error in bulkSarfUpdate Dao {}", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return success;

	}
	public boolean bulkProjectStatusUpdate(DataSourceCriteria criteria) throws Exception {
		
		logger.info("PROJECTS_SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());
		
		boolean success;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkProjectStatusUpdate, criteria);
			success = wsResult.getRowCount() > 0;
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return success;

	}
	public boolean bulkSiteTrakerCreate(DataSourceCriteria criteria) throws Exception {

		logger.info("PROJECTS_SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());

		boolean success;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkSiteTrakerCreate, criteria);
			success = wsResult.getRowCount() > 0;
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return success;

	}
	public boolean bulkTaskUpdate(DataSourceCriteria criteria) throws Exception {

		logger.info("PROJECTS_SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());

		boolean success;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkTaskUpdate, criteria);
			success = wsResult.getRowCount() > 0;
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return success;

	}
	
	public boolean bulkProjPlscUpload(DataSourceCriteria criteria) throws Exception {
		logger.info("PROJECTS_SERVICE : entering {}", Thread.currentThread().getStackTrace()[1].getMethodName());
		boolean uploadStatus=false;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkProjPlscUpload, criteria);
			uploadStatus = wsResult.getRowCount() > 0;
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return uploadStatus;
	}
	
	public boolean bulkUploadE911(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		boolean uploadStatus = false;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkUploadE911, criteria);
			uploadStatus = wsResult.getUpdateCount() > 0;
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return uploadStatus;
	}
	
	public boolean bulkUploadCQ(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		boolean uploadStatus = false;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkUploadCQ, criteria);
			uploadStatus = wsResult.getUpdateCount() > 0;
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return uploadStatus;
	}  
	
	public boolean bulkUploadSiteTrackerSiteInfoId(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		boolean uploadStatus = false;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkUploadSiteTrackerSiteInfoId, criteria); 
			uploadStatus = wsResult.getUpdateCount() > 0;
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return uploadStatus;
	}

	public Map<String, List<AuditFileUploadCommon>> bulkUpdateSiteUpdate(DataSourceCriteria criteria) throws Exception{
		
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );

		try {
			DataCloud.perform(DataCloudServices.SITE.bulkUpdateSiteUpdate, criteria); 
			DataCloud.perform(DataCloudServices.SITE.bulkUpdateSiteUpdateOracle, criteria); 
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return bulkUploadResultList(criteria);
	}
	
	public boolean bulkUploadCranFinalAndCurrentHubs(DataSourceCriteria criteria) throws Exception{
		boolean success;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.CRAN.bulkUploadCranHubs,criteria);
			success = wsResult.getUpdateCount() > 0;
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in bulkUploadCranFinalAndCurrentHubs Dao {}", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return success;
	}
	
	public boolean bulkUploadCranHubInfo(DataSourceCriteria criteria) throws Exception{
		boolean success;
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.CRAN.bulkUploadCranHubInfo,criteria);
			success = wsResult.getUpdateCount() > 0;
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in bulkUploadCranHubInfo Dao {}", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return success;
	}
	
	public Map<String,String> bulkTrackerDataUpdate(DataSourceCriteria criteria) throws Exception {
		
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		Map<String,String> result = new HashMap<String,String>();
		
		try {
			DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkTrackerDataUpdate,criteria);
			if(!"".equalsIgnoreCase(Optional.ofNullable(wsResult.getFirst().getString("RESULT_SET")).orElse(""))) {
				result.put("PROJECT_ID", wsResult.getFirst().getString("RESULT_SET"));
			}
			
			logger.info("BULKUPLOAD_SERVICE : Results in bulkTrackerDataUpdate Dao {}", result);
			
		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in bulkTrackerDataUpdate Dao {}", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return result;
	}

	public Map<String, List<AuditFileUploadCommon>> bulkSiteTrackerAttrUpdate(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		
		try {
			DataCloud.perform(DataCloudServices.PROJECTS.bulkSiteTrackerAttrUpdate, criteria); 
			
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return bulkUploadResultList(criteria);
	}
	
	public Map<String, List<AuditFileUploadCommon>> bulkPslcUpdate(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		
		try {
			DataCloud.perform(DataCloudServices.PROJECTS.bulkPslcUpdate, criteria); 
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return bulkUploadResultList(criteria);
	}
	public Map<String, List<AuditFileUploadCommon>> bulkLocationCreation(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		try {
			DataCloud.perform(DataCloudServices.PROJECTS.bulkLocationCreation, criteria); 
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return bulkUploadResultList(criteria);
	}
	
	public Map<String, List<AuditFileUploadCommon>> bulkUploadSpmToGranite(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		try {
			DataCloud.perform(DataCloudServices.PROJECTS.bulkUploadSpmToGranite, criteria); 
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return bulkUploadResultList(criteria);
	}
	
	public List<Map<String,String>> transportFieldUpdatesOneFOnBoarding(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		try {
			DataCloud.perform(DataCloudServices.PROJECTS.transportFieldUpdatesOneFOnBoarding, criteria); 
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return transportFieldUpdatesOneFOnBoardingResultList(criteria);
	}
	
	
	
	
	public List<AuditFileUploadCommon> searchBulkUploads(AuditFileUploadCommon auditFileUploadCommon) throws Exception {
		logger.debug("BULKUPLOAD_SERVICE : Inside {}. Parameter :  {}",
				Thread.currentThread().getStackTrace()[1].getMethodName(), auditFileUploadCommon);

		final List<AuditFileUploadCommon> bulkUploadList = new ArrayList<AuditFileUploadCommon>();

		final DataSourceCriteria criteria = Transformers.getCriteriaFromPoJo(auditFileUploadCommon);
		try {

			final DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.searchBulkUploads, 	
					criteria);
			
			if(wsResult.getRowCount()>0){
				wsResult.getRows().stream().forEach( ds -> {
					try {
						bulkUploadList.add(Transformers.getPojoFromDataSourceResult(AuditFileUploadCommon.class, ds));
					} catch (Exception e) {
						e.printStackTrace();
					}
				});
			}

		} catch (final Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in searchBulkUploads {}", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		logger.debug("BULKUPLOAD_SERVICE : Returning from {}. Return Parameter :  {}",
				Thread.currentThread().getStackTrace()[1].getMethodName(), bulkUploadList);
		return bulkUploadList;
	}

	public List<EnvBulkUpload> bulkEnvUpdate(DataSourceCriteria criteria) throws Exception {
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );
		
		final List<EnvBulkUpload> bulkUploadList = new ArrayList<EnvBulkUpload>();

		try {
			final DataSourceResultSet wsResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkEnvUpdate, criteria); 
			wsResult.getRows().stream().forEach( ds -> {
				try {
					bulkUploadList.add(Transformers.getPojoFromDataSourceResult(EnvBulkUpload.class, ds));
				} catch (Exception e) {
					e.printStackTrace();
				}
			});
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		logger.debug("BULKUPLOAD_SERVICE : Returning from {}. Return Parameter :  {}",Thread.currentThread().getStackTrace()[1].getMethodName(), bulkUploadList);
		return bulkUploadList;
		
	}
	
	public List<Map<String,String>> transportFieldUpdatesOneFOnBoardingResultList(DataSourceCriteria criteria) throws Exception{
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );

		List<Map<String,String>> failedList = new ArrayList<Map<String,String>>();
					
		try {
			DataSourceResultSet failedResult = DataCloud.perform(DataCloudServices.PROJECTS.bulkUpdateFailed, criteria);
			if(failedResult.getRowCount()>0){
				failedResult.getRows().stream().forEach( ds -> {
					try {
						//failed.put(String.valueOf(ds.getInt("ID")),ds.getString("REJECT_REASON"));
						Map<String,String> failed = new HashMap<String,String>();
						failed.put("PROJECT_ID", String.valueOf(ds.getInt("ID")) + '-' + ds.getString("REJECT_REASON"));
						failedList.add(failed);
					} catch (Exception e) {
						e.printStackTrace();
					}
				});
			}
		} catch (Exception e) {
			logger.error("BULK_UPLOAD_SERVICE : Error in bulkUploadResultList Dao {}", e.getMessage());
			e.printStackTrace();
			throw e;
		}
		return failedList;
	}

	
	public Map<String, List<AuditFileUploadCommon>> bulkOnefiberOrderCreation(DataSourceCriteria criteria) throws Exception{
		
		logger.info("BULKUPLOAD_SERVICE : entering{}",Thread.currentThread().getStackTrace()[1].getMethodName() );

		try {
			DataCloud.perform(DataCloudServices.ONEFIBER.bulkOneFiberOrderCreation, criteria); 
			DataCloud.perform(DataCloudServices.ONEFIBER.bulkOneFiberOrderCreationOracle, criteria); 
		}catch(Exception e) {
			logger.error("BULKUPLOAD_SERVICE : Error in {}  with {}",Thread.currentThread().getStackTrace()[1].getMethodName(),e);
			throw e;
		}
		return bulkUploadResultList(criteria);
	}
}
