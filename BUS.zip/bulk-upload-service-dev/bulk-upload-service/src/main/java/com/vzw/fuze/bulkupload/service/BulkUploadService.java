package com.vzw.fuze.bulkupload.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.vzw.fuze.bulkupload.model.AuditFileUploadCommon;
import com.vzw.fuze.bulkupload.model.EnvBulkUpload;
import com.vzw.fuze.common.model.Document;
import com.vzw.fuze.common.model.User;

@Service("bulkUploadService")
public interface BulkUploadService {

	public Boolean bulkCrownVCAUpload(Document document) throws Exception ;

	public Boolean bulkUpdateCRANOnefiber() throws Exception ;
	
	public Boolean bulkAbstraction(Document document,String userJSON) throws Exception;
	
	boolean bulkUpdateSTReference(Document document, User user) throws Exception;
	
	boolean bulkSitetrakerSyncFuzeToST(Document document, User user) throws Exception;
	
	boolean bulkSitetrakerSyncSTToFuze(Document document, User user) throws Exception;
	
	boolean bulkSarfUpdate(Document document, User user) throws Exception;
	
	boolean bulkProjectStatusUpdate(Document document, User user) throws Exception;
	
	boolean bulkSiteTrakerCreate(Document document, User user) throws Exception;

	boolean bulkTaskUpdate(Document document, User user) throws Exception;
	
	boolean bulkProjPlscUpload(User user, Document document) throws Exception;
	
	boolean bulkUploadE911(User user, Document document) throws Exception;
	
	boolean bulkUploadCQ(User user, Document document) throws Exception;
	
	boolean bulkUploadSiteTrackerSiteInfoId(User user, Document document) throws Exception;

	public Map<String, List<AuditFileUploadCommon>> bulkUpdateSiteUpdate(User user, Document document) throws Exception;
	
	boolean bulkUploadCranFinalAndCurrentHubs(User user, Document document)throws Exception;
	
	boolean bulkUploadCranHubInfo(User user, Document document)throws Exception;

	boolean bulkTrackerDataUpdate(User user, Document document)throws Exception;

	Boolean bulkActionItemEventCreation(Document document) throws Exception;
	
	public Map<String, List<AuditFileUploadCommon>> bulkSiteTrackerAttrUpdate(User user, Document document) throws Exception;
	
	public Map<String, List<AuditFileUploadCommon>> bulkPslcUpdate(User user, Document document) throws Exception;

    public Map<String, List<AuditFileUploadCommon>> bulkLocationCreation(User user, Document document) throws Exception;
    
    public Map<String, List<AuditFileUploadCommon>> bulkUploadSpmToGranite(User user, Document document) throws Exception;
    
    public List<Map<String,String>> transportFieldUpdatesOneFOnBoarding(User user, Document document) throws Exception;
    
    List<AuditFileUploadCommon> searchBulkUploads(AuditFileUploadCommon auditFileUploadCommon, User user) throws Exception;

	public List<EnvBulkUpload> bulkEnvUpdate(User user, Document document) throws Exception;
	
	boolean bulkContractNbrInsert(Map<String, Object> command) throws Exception;

	Map<String, List<AuditFileUploadCommon>> bulkOnefiberOrderCreation(User user, Document document) throws Exception;

}
