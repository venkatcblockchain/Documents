package com.vzw.fuze.bulkupload.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
 
@Configuration
public class AppConfig {

	@Autowired
	RequestFilter requestFilter;
	
	@Bean
	public FilterRegistrationBean filterRegistrationBean() {
		final FilterRegistrationBean registrationBean = new FilterRegistrationBean();
		registrationBean.setFilter(requestFilter);
		registrationBean.addUrlPatterns("/bulk-upload-service/*");
		return registrationBean;
	}
	
	@LoadBalanced
		@Bean
		RestTemplate loadBalanced() {
			return new RestTemplate();
		}

	@Bean

	public ObjectMapper objectMapper() {

		final ObjectMapper objectMapper = new ObjectMapper();

		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);

		return objectMapper;

	}

	/*  @Bean
	public User user(){
		return new User();
	}*/
	  
}
