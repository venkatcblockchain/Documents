package com.vzw.fuze.bulkupload.dao;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vzw.fuze.bulkupload.service.AppConstants;
import com.vzw.fuze.common.dao.EnumReferenceDao;

@Component
public class CachedResultsDao {


	private final static Logger logger = LoggerFactory.getLogger(CachedResultsDao.class.getName());

	private static String maxIntialTerms = null;

	public static Logger getLogger() {
		return logger;
	}

	@Autowired
	EnumReferenceDao enumReferenceDao;

	private String defaultDateFormat = "";

	private String defaultTimeFormat = "";

	/**  Default is set to false inside DAO */
	private Boolean securedAPI = new Boolean(true);

	private boolean devMode = false;
	//private boolean reportsEnabled = false;
	private String currEnv = "";
	
	private boolean isBuploadEnabled = false;
	private boolean isCandidateBuploadEnabled = false;
	private boolean isErrorMessageEnabled = false;
	

	/**  API Credentials in Key/Value Map */
	private Map<String, String> restApiCredentials = null;

	/** Default Equip Setting in Key/Value Map**/
	//private final Map<String, String> equipSetting = null;

	/**  API Credentials in Key/Value Map */

	/** Proxy Details */
	private Map<String, String> proxySettings = null;


	/** Maximum projects searches in a given search, to avoid DOS */
	private String maxProjectSearchResults;

	/**  Default is set to true inside DAO */
	private Boolean proxyEnabled = new Boolean(true);


	private Map<String, String> allowedExtn;


	private Map<String, String> featureAccess;
	
	private Map<String, String> sectionNotes;
	
	private Map<String, String> templateUpdatedDates;
	
	private String errorEmailToList;

	private String errorEmailCcList;


	private String guiTimeout;

	private String guiBlockTimeout;

	private String maxNotifications;

	private String serviceSleepTime;


	private String buildVersion;
	

	private Map<String, String> documentTypes;

	private List<String> commonAllowedFileExtn;


	/** Proxy Details */
	private Map<String, String> guiFilesList;


	/*
	 *  This will cache all the SQLss inside this method
	 *  Only getter is provided which will fetch the cached results
	 *  If you want to recache the results please call datacloud/refresh
	 */


	private CachedResultsDao(){
	}



	public void cachedQueries() throws Exception {

		logger.debug("BULKUPLOAD_SERVICE : Entering {} ", Thread.currentThread().getStackTrace()[1].getMethodName());

		defaultDateFormat = enumReferenceDao.getDefaultDateFormat();
		defaultTimeFormat =  enumReferenceDao.getDefaultTimeFormat();

		securedAPI = enumReferenceDao.isApiSecured();
		final String devModeStr = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.SETTINGS.name(), "IS_DEV_MODE");
		devMode = Boolean.parseBoolean(Optional.ofNullable(devModeStr).orElse("false"));

		currEnv = Optional.ofNullable(enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.APP_CONFIG.name(), AppConstants.SUB_TYPE.SETTINGS.name(), "CURRENT_ENVIRONMENT")).orElse("DEV");


		String bulkUpload = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.SETTINGS.name(), "BULK_UPLOAD_ENABLED");
		isBuploadEnabled = Boolean.parseBoolean(Optional.ofNullable(bulkUpload).orElse("false"));

		bulkUpload = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.SETTINGS.name(), "CANDIDATE_BULK_UPLOAD_ENABLED");
		isCandidateBuploadEnabled = Boolean.parseBoolean(Optional.ofNullable(bulkUpload).orElse("false"));

		final String errorMessage = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.SETTINGS.name(), "ERROR_MESSAGE_ENABLED");
		isErrorMessageEnabled = Boolean.parseBoolean(Optional.ofNullable(errorMessage).orElse("false"));

		restApiCredentials = enumReferenceDao.getRestApiCredentials();

		proxyEnabled = enumReferenceDao.isProxyEnabled();
		buildVersion = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.SETTINGS.name(), "BUILD_VERSION");
		
		guiTimeout = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.SETTINGS.name(), "GUI_TIMEOUT");
		final String guiBlockTimeoutStr = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.SETTINGS.name(), "GUI_BLOCK_TIMEOUT");
		guiBlockTimeout = Optional.ofNullable(guiBlockTimeoutStr).orElse("6000");

		final String serviceSleepTimeStr = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.SETTINGS.name(), "SERVICE_SLEEP_TIME");
		serviceSleepTime = Optional.ofNullable(serviceSleepTimeStr).orElse("1000");


		featureAccess = enumReferenceDao.fetchMap(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants
				.SUB_TYPE.FEATURE_ACCESS.name());

		sectionNotes = enumReferenceDao.fetchMap(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.SECTION_NOTES.name());
		templateUpdatedDates = enumReferenceDao.fetchMap(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.TEMPLATE_UPDATED_NOTES.name());
		

		documentTypes = enumReferenceDao.fetchMap(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.PROJ_DOC_TYPES.name());

		commonAllowedFileExtn = enumReferenceDao.fetchList(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(),AppConstants.SUB_TYPE.COMMON_DOC_TYPES.name(),AppConstants.SUB_TYPE.COMMON_DOC_TYPES.name());

		errorEmailToList = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.BULK_EMAIL_SETTINGS.name(), "ERROR_EMAIL_TO_LIST");
		errorEmailCcList = enumReferenceDao.fetchValue(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.BULK_EMAIL_SETTINGS.name(), "ERROR_EMAIL_CC_LIST");


		guiFilesList = enumReferenceDao.fetchMap(AppConstants.GROUP_NAME.PROJECTS_SETTINGS.name(), AppConstants.SUB_TYPE.GUI_FILES_LIST.name());

		
	}



	public Map<String, String> getAllowedExtn() {
		return allowedExtn;
	}


	public List<String> getCommonAllowedFileExtn() {
		return commonAllowedFileExtn;
	}


	public String getCurrEnv() {
		return currEnv;
	}



	public String getDefaultDateFormat() {
		return defaultDateFormat;
	}

	public String getDefaultTimeFormat() {
		return defaultTimeFormat;
	}

	public Map<String, String> getDocumentTypes() {
		return documentTypes;
	}
	

	public EnumReferenceDao getEnumReferenceDao() {
		return enumReferenceDao;
	}


	public String getErrorEmailCcList() {
		return errorEmailCcList;
	}

	public String getErrorEmailToList() {
		return errorEmailToList;
	}


	public Map<String, String> getFeatureAccess() {
		return featureAccess; 
	}

	public String getGuiBlockTimeout() {
		return guiBlockTimeout;
	}

	public Map<String, String> getGuiFilesList() {
		return guiFilesList;
	}

	public String getGuiTimeout() {
		return guiTimeout;
	}

	

	public String getMaxNotifications() {
		return maxNotifications;
	}


	public String getMaxProjectSearchResults() {
		return maxProjectSearchResults;
	}


	public Boolean getProxyEnabled() {
		return proxyEnabled;
	}

	public Map<String, String> getProxySettings() {
		return proxySettings;
	}


	public Map<String, String> getRestApiCredentials() {
		return restApiCredentials;
	}
	public Map<String, String> getSectionNotes() {
		return sectionNotes;
	}
	public Boolean getSecuredAPI() {
		return securedAPI;
	}

	public String getServiceSleepTime() {
		return serviceSleepTime;
	}


	public Map<String, String> getTemplateUpdatedNotes() {
		return templateUpdatedDates;
	}



	/*public Map<String, String> getUnitType() {
		return unitType;
	}*/
	

	public Boolean isApiSecured() {
		return securedAPI;
	}

	public boolean isBuploadEnabled(){
		return isBuploadEnabled;
	}

	public boolean isCandidateBuploadEnabled() {
		return isCandidateBuploadEnabled;
	}

	public boolean isDevMode() {
		return devMode;
	}
	
	public boolean isErrorMessageEnabled() {
		return isErrorMessageEnabled;
	}
	public Boolean isProxyEnabled() {
		return proxyEnabled;
	}
	public void setErrorEmailCcList(String errorEmailCcList) {
		this.errorEmailCcList = errorEmailCcList;
	}
	public void setErrorEmailToList(String errorEmailToList) {
		this.errorEmailToList = errorEmailToList;
	}
	public void setExternalNotificationSettings(Map<String, String> externalNotificationSettings) {
	}
	public void setFeatureAccess(Map<String, String> featureAccess) { this.featureAccess = featureAccess; }

	
	public void setGuiFilesList(Map<String, String> guiFilesList) {
		this.guiFilesList = guiFilesList;
	}


}