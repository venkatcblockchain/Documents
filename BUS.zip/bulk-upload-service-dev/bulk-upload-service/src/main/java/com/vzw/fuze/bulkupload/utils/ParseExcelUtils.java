package com.vzw.fuze.bulkupload.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.vzw.fuze.common.model.User;

public class ParseExcelUtils {
		
	/** excel with multiple sheets **/
	public static DataSourceCriteria parseExcelTemplateWithMultipleSheets(InputStream inputStream, User user) throws IOException, JSONException {
	        
		final DataSourceCriteria finalCriteria = new DataSourceCriteria();
		//final DataFormatter formatter = new DataFormatter();
		final XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			
		for (int i = 0; i < workbook.getNumberOfSheets() -1; i++) {
			List<DataSourceCriteria> criteriaDetailsList = new ArrayList<>();
			String name = workbook.getSheetName(i);
			final XSSFSheet sheet = workbook.getSheetAt(i);
			
			criteriaDetailsList = getCriteriaBasedOnSheet(sheet);
				
			/*final Iterator<Row> iterator = sheet.iterator();
			final HashMap<Integer, String> columnHeadingMap = new HashMap<>();
			String currentColumnHeading = "";
				
			while (iterator.hasNext()) {
				final Row currentRow = iterator.next();
				final int rowNum = currentRow.getRowNum();
				
				// get all the column headings into a Map
				if (rowNum == 1) {
					final Iterator<Cell> cellIterator = currentRow.cellIterator();
					while (cellIterator.hasNext()) {
						final Cell cell = cellIterator.next();
						if (null != cell.getStringCellValue()
								&& !cell.getStringCellValue().replaceAll("\\s+", "").equals("")) {
							columnHeadingMap.put(cell.getColumnIndex(), cell.getStringCellValue());
						}
					}
				}
				// excel has data
				if (rowNum > 1) {
					final DataSourceCriteria criteria = new DataSourceCriteria();
					// Iterate all the cells in current row
					final Iterator<Cell> cellIterator = currentRow.cellIterator();
					criteria.put("ROW_INDEX", rowNum);

					while (cellIterator.hasNext()) {
						final Cell cell = cellIterator.next();
						final int columnIndex = cell.getColumnIndex();
						currentColumnHeading = columnHeadingMap.get(columnIndex);

						String formattedString = StringUtils.trim(formatter.formatCellValue(cell));
						formattedString = Optional.ofNullable(formattedString).orElse("");
						formattedString = StringEscapeUtils.escapeSql(formattedString);
						formattedString = formattedString.replaceAll("[^a-zA-Z0-9|^_|^.|^&|^/|^\"|^\'-|^#^ |^@|^$|^,|^(|^)|^\\[|^\\]]", "");
							
						*//** Do some columns have the null heading ?, will verify *//*
						if(currentColumnHeading != null && !"".equalsIgnoreCase(currentColumnHeading) && !"".equalsIgnoreCase(formattedString)) {
							criteria.put(currentColumnHeading, formattedString);	
						}						

					}
					criteriaDetailsList.add(criteria);
				}
			}*/
			finalCriteria.put(name.replaceAll("\\s+", "_").toUpperCase(),criteriaDetailsList);
	    
	    }
		return finalCriteria;
	} 
	
	public static List<DataSourceCriteria> getCriteriaBasedOnSheet(XSSFSheet sheet){
		
		final List<DataSourceCriteria> criteriaDetailsList = new ArrayList<>();
		final DataFormatter formatter = new DataFormatter();		
		final HashMap<Integer, String> columnHeadingMap = new HashMap<>();
		String currentColumnHeading = "";
		
		final Iterator<Row> iterator = sheet.iterator();
			
		while (iterator.hasNext()) {
			final Row currentRow = iterator.next();
			final int rowNum = currentRow.getRowNum();
			
			// get all the column headings into a Map
			if (rowNum == 1) {
				final Iterator<Cell> cellIterator = currentRow.cellIterator();
				while (cellIterator.hasNext()) {
					final Cell cell = cellIterator.next();
					if (null != cell.getStringCellValue()
							&& !cell.getStringCellValue().replaceAll("\\s+", "").equals("")) {
						columnHeadingMap.put(cell.getColumnIndex(), cell.getStringCellValue());
					}
				}
			}
			// excel has data
			if (rowNum > 1) {
				final DataSourceCriteria criteria = new DataSourceCriteria();
				// Iterate all the cells in current row
				final Iterator<Cell> cellIterator = currentRow.cellIterator();
				criteria.put("ROW_INDEX", rowNum);

				while (cellIterator.hasNext()) {
					final Cell cell = cellIterator.next();
					final int columnIndex = cell.getColumnIndex();
					currentColumnHeading = columnHeadingMap.get(columnIndex);

					String formattedString = StringUtils.trim(formatter.formatCellValue(cell));
					formattedString = Optional.ofNullable(formattedString).orElse("");
					formattedString = StringEscapeUtils.escapeSql(formattedString);
					formattedString = formattedString.replaceAll("[^a-zA-Z0-9|^_|^.|^&|^/|^\"|^\'-|^#^ |^@|^$|^,|^(|^)|^\\[|^\\]]", "");
						
					/** Do some columns have the null heading ?, will verify */
					if(currentColumnHeading != null && !"".equalsIgnoreCase(currentColumnHeading) && !"".equalsIgnoreCase(formattedString)) {
						criteria.put(currentColumnHeading, formattedString);	
					}						

				}
				criteriaDetailsList.add(criteria);
			}
		}
		return criteriaDetailsList;
	}
	
	/** tracker update needs a json object so not using common method **/
	public static List<JSONObject> parseExcelTemplateForJson(XSSFSheet sheet) throws IOException, JSONException {

		final List<JSONObject> dataList = new ArrayList<>();
		final DataFormatter formatter = new DataFormatter();
		final Iterator<Row> iterator = sheet.iterator();
		final HashMap<Integer, String> columnHeadingMap = new HashMap<>();
		String currentColumnHeading = "";
			
		while (iterator.hasNext()) {
			final Row currentRow = iterator.next();
			final int rowNum = currentRow.getRowNum();

			// get all the column headings into a Map
			if (rowNum == 1) {
				final Iterator<Cell> cellIterator = currentRow.cellIterator();
				while (cellIterator.hasNext()) {
					final Cell cell = cellIterator.next();
					if (null != cell.getStringCellValue()
							&& !cell.getStringCellValue().replaceAll("\\s+", "").equals("")) {
						columnHeadingMap.put(cell.getColumnIndex(), cell.getStringCellValue());
					}
				}
			}
			
			// excel has data
			if (rowNum > 1) {
				final JSONObject data = new JSONObject();
				// Iterate all the cells in current row
				final Iterator<Cell> cellIterator = currentRow.cellIterator();

				while (cellIterator.hasNext()) {
					final Cell cell = cellIterator.next();
					final int columnIndex = cell.getColumnIndex();
					currentColumnHeading = columnHeadingMap.get(columnIndex);

					String formattedString = StringUtils.trim(formatter.formatCellValue(cell));
					formattedString = Optional.ofNullable(formattedString).orElse("");
					formattedString = StringEscapeUtils.escapeSql(formattedString);
					formattedString = formattedString.replaceAll("[^a-zA-Z0-9|^_|^.|^&|^/|^\"|^\'-|^#^ |^@|^$|^,|^(|^)|^\\[|^\\]]", "");
						
					/** Do some columns have the null heading ?, will verify */
					if(currentColumnHeading != null && !"".equalsIgnoreCase(currentColumnHeading) && !"".equalsIgnoreCase(formattedString)) {
						data.put(currentColumnHeading, formattedString);	
					}
						
				}	
				if(data.length() > 0) {
					dataList.add(data);
				}
			}
    
        }
		return dataList;
	}
}