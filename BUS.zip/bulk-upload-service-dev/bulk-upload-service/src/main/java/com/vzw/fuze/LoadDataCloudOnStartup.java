package com.vzw.fuze;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 * 
 * This start up class will be executed when application started
 *  
 **/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

import com.verizon.webkit.datacloud.DataServiceRegistry;
import com.verizon.webkit.datacloud.sql.DBConnector;
import com.vzw.fuze.bulkupload.dao.BulkUploadDao;
import com.vzw.fuze.bulkupload.dao.CachedResultsDao;;




 
@Component
@PropertySources({
    @PropertySource("file:/apps/opt/fuze/properties/mpt-profile.properties"),
    @PropertySource("file:/apps/opt/fuze/properties/fuze-db-oracle.properties")
})
public class LoadDataCloudOnStartup implements ApplicationListener<ApplicationReadyEvent> {
	
	@Autowired
	CachedResultsDao cachedResultsDao;

	@Autowired
	BulkUploadDao bulkUploadDao;

	
	
	@Value("${mpt_username}")
	private String username;

	@Value("${mpt_password}")
	private String password;

	@Value("${connection}")
	private String connection;
	
	@Value("${fuze_oracle_driver}")
	private String fuze_oracle_driver;
	
	@Value("${fuze_oracle_connection_url}")
	private String fuze_oracle_connection_url;

	@Value("${fuze_oracle_user}")
	private String fuze_oracle_user;
	
	@Value("${fuze_oracle_password}")
	private String fuze_oracle_password;
	
	
	/*
	DataServiceAdapterType=oracle
	# DB properties
			
			boot_datasource_pool_driver_class=oracle.jdbc.driver.OracleDriver
			# Change to your db connection string.
			boot_datasource_pool_url=jdbc:oracle:thin:@//txslofuzedd1v.nss.vzwnet.com:1521/fuzedev.nss.vzwnet.com
			# Change to appropriate user & password
			boot_datasource_pool_user=fuze
			boot_datasource_pool_passwd=M1gration#
	*/		
	
	@Override
	public void onApplicationEvent(ApplicationReadyEvent arg0) {
		
		
		try {
			
			/** Failure on One Data Source Registry should not impact others */
			try {
				Class.forName(fuze_oracle_driver);
				Connection fuzeOracle = DriverManager.getConnection(fuze_oracle_connection_url, fuze_oracle_user, fuze_oracle_password);
				if (fuzeOracle.isValid(0)) {
					DBConnector.createDS("jdbc/fuze_oracle_ds", fuze_oracle_driver, fuze_oracle_connection_url, fuze_oracle_user, fuze_oracle_password,"null");
				}
			}catch(Exception ignore) {
				ignore.printStackTrace();
				
			}

			/** Only for SPM, Ignore */
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				Connection conn = DriverManager.getConnection(connection, username, password);
				if (conn.isValid(0)) {
					DBConnector.createDS("ds/mpt", "com.microsoft.sqlserver.jdbc.SQLServerDriver", connection, username,
							password, "null");
				} 
			} catch (Exception ignore) {
				ignore.printStackTrace();
			}


			
		} catch (final Exception e) {
			e.printStackTrace();
		} finally {
			DataServiceRegistry.intialize();
			try {
				cachedResultsDao.cachedQueries();
				
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}
	}

}

