package com.vzw.fuze.bulkupload.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.vzw.fuze.bulkupload.service.BulkUploadService;
import com.vzw.fuze.common.model.Document;
import com.vzw.fuze.common.service.UserInfoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**@author peacja7 **/


@RestController
@RequestMapping("/bulk-upload-service/upload")
@Api(value = "Bulk Upload Services")
public class BulkUploadControllerv2 {
	
	private static Logger logger = LoggerFactory.getLogger(BulkUploadControllerv2.class.getName());

	@Autowired
	BulkUploadService bulkUploadService; 
	
	@Autowired
	UserInfoService userInfoService;
	
	@Autowired
	public BulkUploadControllerv2(UserInfoService pUserInfoService) {
	      this.userInfoService = pUserInfoService;
	}
	 	

	@RequestMapping(value = "/bulkCrownVCAUpload", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "Returns output details", notes = "Update Crown VCA Data from excell doc", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service", response = Boolean.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Boolean bulkCrownVCAUpload(@RequestHeader("user") String userJSON,@RequestBody Document document) throws Exception {
		logger.info("RELM-SERVICE : bulkCrownVCAUpload is called for by {} ",  userInfoService.getUserInfo());
		return bulkUploadService.bulkCrownVCAUpload(document);
	}
	
	
	@RequestMapping(value = "/bulkActionItemEventCreation", method = RequestMethod.POST, produces = "application/json")
	@ApiOperation(value = "Returns output details", notes = "Update Crown VCA Data from excell doc", response = Boolean.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful retrieval service", response = Boolean.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Data does not exist"), })
	@ResponseStatus(value = HttpStatus.OK)
	public Boolean bulkActionItemEventCreation(@RequestHeader("user") String userJSON,@RequestBody Document document) throws Exception {
		logger.info("RELM-SERVICE : bulkActionItemEventCreation is called for by {} ",  userInfoService.getUserInfo());
		return bulkUploadService.bulkActionItemEventCreation(document);
	}

	
	

}
