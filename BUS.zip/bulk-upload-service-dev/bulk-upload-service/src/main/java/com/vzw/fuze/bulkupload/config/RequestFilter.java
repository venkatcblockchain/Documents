package com.vzw.fuze.bulkupload.config;

import java.io.IOException;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.fuze.bulkupload.dao.CachedResultsDao;
import com.vzw.fuze.bulkupload.service.AppConstants;
import com.vzw.fuze.common.model.User;
import com.vzw.fuze.common.service.UserInfoService;
import com.vzw.fuze.common.util.CommonUtils;
 
@Component
public class RequestFilter implements Filter {

	private static Logger logger = LoggerFactory.getLogger(RequestFilter.class.getName());
	

	@Autowired
	private CachedResultsDao cachedResultsDao; 
	
	@Autowired
	private UserInfoService userInfoService;

	
	@Override
	public void destroy() {
	}
	

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		
		final HttpServletRequest request = (HttpServletRequest) req;
		final HttpServletResponse response = (HttpServletResponse) res;
		final String uri = request.getRequestURI();

		logger.info("BULK-UPLOAD-SERVICE : Intercepted the URI : {} ", uri);
		logger.info("BULK-UPLOAD-SERVICE : Intercepted the URI : {} ", request.getHeader(User.HEADER_KEY));
		
		final ObjectMapper objectMapper = new ObjectMapper();
		if(request.getHeader(User.HEADER_KEY) != null ){
		final User user = objectMapper.readValue(request.getHeader(User.HEADER_KEY), User.class);
			userInfoService.setUserInfo(user);
		}
		
		String userId = userInfoService.getUserInfo() != null  && !"null".equalsIgnoreCase(userInfoService.getUserInfo().getUserId()) ? userInfoService.getUserInfo().getUserId() : "bulk-upload-service";
		String mdcData = String.format("[%s | %s] ", userId, requestId());

        MDC.put("transaction", mdcData); //Variable 'transaction' is referenced in Spring Boot's logging.pattern.level /Logback xml property

		
		/** ping call is not intercepted */
		if(!Optional.ofNullable(uri).filter(filtered -> uri.contains("ping")).isPresent()){

			final Boolean isApiSecured = cachedResultsDao.isApiSecured();
			if(isApiSecured){

				final String clientAuthKey = request.getHeader(HttpHeaders.AUTHORIZATION);
				
				final Map<String, String> restApiCredentials = cachedResultsDao.getRestApiCredentials();
				final String userName = restApiCredentials.get(AppConstants.NAME.API_USERNAME.name());
				final String password = restApiCredentials.get(AppConstants.NAME.API_PASSWORD.name());
				
				final String serverAuthKey = CommonUtils.getServerAuthKey(userName, password);

				logger.info("BULK-UPLOAD-SERVICE : Client Auth Key |{}| and Server Auth Key |{}|", clientAuthKey, serverAuthKey);
				
				if(!Optional.ofNullable(serverAuthKey).filter(s -> s.equals(clientAuthKey)).isPresent()){
					response.setStatus(HttpStatus.UNAUTHORIZED.value());
					response.getWriter().write("Username / Password not matching..");
					return;
				}
			}
		}
		chain.doFilter(req, res);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}
	
	private String requestId() {
	     return UUID.randomUUID().toString();
	}

}