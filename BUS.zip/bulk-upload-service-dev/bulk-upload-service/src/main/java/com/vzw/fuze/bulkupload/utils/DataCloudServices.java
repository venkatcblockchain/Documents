
package com.vzw.fuze.bulkupload.utils;

public interface DataCloudServices {

	interface APIQUEUE{
			String insertAPIQueue = "apiqueue.insertAPIQueue";
	   }

	interface ENUM {

		String getEnumValue = "enum.getEnumValue";
		String getEnumList = "enum.getEnumList";
		String getEnumMap = "enum.getEnumMap";
		String getEnumReferences = "enum.getEnumReferences";
		String updateEnumRecord = "enum.updateEnumRecord";
	}

	interface PROJECTS {
		
		String bulkUpdateSTReference = "projects.bulkUpdateSTReference";
		String bulkSitetrakerSyncFuzeToST = "projects.bulkSitetrakerSyncFuzeToST";
		String bulkSitetrakerSyncSTtoFuze = "projects.bulkSitetrakerSyncSTtoFuze";
		String bulkSarfUpdate = "projects.bulkSarfUpdate";
		String bulkProjectStatusUpdate = "projects.bulkProjectStatusUpdate";
		String bulkSiteTrackerAttrUpdate = "projects.bulkSiteTrackerAttrUpdate";
		String bulkPslcUpdate = "projects.bulkPslcUpdate";
		String bulkUpdateSuccess = "projects.bulkUpdateSuccess";
		String bulkUpdateFailed = "projects.bulkUpdateFailed";
		String bulkLocationCreation = "projects.bulkLocationCreation";
		String bulkUploadSpmToGranite = "projects.bulkUploadSpmToGranite";
		String transportFieldUpdatesOneFOnBoarding = "projects.transportFieldUpdatesOneFOnBoarding";
		String searchBulkUploads = "projects.searchBulkUploads";
		String bulkSiteTrakerCreate = "projects.bulkSiteTrakerCreate";
		String bulkTaskUpdate = "projects.bulkTaskUpdate";
		String bulkProjPlscUpload = "projects.bulkProjPlscUpload";
		String bulkUploadE911 = "projects.bulkUploadE911";
		String bulkUploadCQ = "projects.bulkUploadCQ";
		String bulkUploadSiteTrackerSiteInfoId = "projects.bulkUploadSiteTrackerSiteInfoId";
		String bulkTrackerDataUpdate = "projects.bulkTrackerDataUpdate";
		String bulkEnvUpdate = "projects.bulkEnvUpdate";
		
	}
	interface SITE {
		
		String bulkUpdateSiteUpdate = "site.bulkUpdateSiteUpdate";
		String bulkUpdateSiteUpdateOracle = "site.bulkUpdateSiteUpdateOracle";
	}
	
	interface CRAN {
		
		String bulkUploadCranHubs = "cran.bulkUploadCranHubs";
	    String bulkUploadCranHubInfo = "cran.bulkUploadCranHubInfo";
	}
	
	interface ONEFIBER {
		
		String bulkOneFiberOrderCreation = "onefiber.bulkOneFiberOrderCreation";
		String bulkOneFiberOrderCreationOracle = "onefiber.bulkOneFiberOrderCreationOracle";
	}
}
