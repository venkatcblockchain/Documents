package com.vzw.fuze.bulkupload.model;

import com.verizon.webkit.annotations.ColumnMap;
import com.verizon.webkit.util.DBDataTypes;

public class EnvBulkUpload {

	@ColumnMap(columnName = "TRANS_ID", dbDataType = DBDataTypes.VARCHAR)
	private String transId;
		
	@ColumnMap(columnName = "SITE_PROJECTS_ID", dbDataType = DBDataTypes.INTEGER)
	private int siteProjectsId;
	
	@ColumnMap(columnName = "STATUS", dbDataType = DBDataTypes.VARCHAR)
	private String status;
		
	@ColumnMap(columnName = "MESSAGE", dbDataType = DBDataTypes.VARCHAR)
	private String message;
	
	@ColumnMap(columnName = "LAST_MODIFIED_BY", dbDataType = DBDataTypes.VARCHAR)
	private String lastModifiedBy;
	
	@ColumnMap(columnName = "LAST_MODIFIED_DATE", dbDataType = DBDataTypes.DATE)
	private String lastModifiedDate;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EnvBulkUpload [transId=");
		builder.append(transId);
		builder.append(", siteProjectsId=");
		builder.append(siteProjectsId);
		builder.append(", status=");
		builder.append(status);
		builder.append(", message=");
		builder.append(message);
		builder.append(", lastModifiedBy=");
		builder.append(lastModifiedBy);
		builder.append(", lastModifiedDate=");
		builder.append(lastModifiedDate);
		builder.append("]");
		return builder.toString();
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public int getSiteProjectsId() {
		return siteProjectsId;
	}

	public void setSiteProjectsId(int siteProjectsId) {
		this.siteProjectsId = siteProjectsId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
}
