package com.vzw.fuze.bulkupload.controller;

import javax.ws.rs.core.MediaType;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.webkit.datacloud.DataServiceRegistry;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.vzw.fuze.bulkupload.dao.CachedResultsDao;
import com.vzw.fuze.common.dao.GenericDao;
import com.vzw.fuze.common.util.CommonUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
 

@RestController
@RequestMapping("/bulk-upload-service/datacloud")
@Api(value = "Data Cloud Service")
public class DataCloudController {
	private static Logger logger = LoggerFactory.getLogger(DataCloudController.class.getName()); 
	
	@Autowired
	private CachedResultsDao cachedResultsDao;

	@Autowired
	GenericDao genericDao;

	
	@RequestMapping(value = "/refresh", method = RequestMethod.GET )
	@ApiOperation(value = "Refreshes DataService Registry", notes = "Project", response = String.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Refreshed DataService Registry", response = String.class),
			@ApiResponse(code = 401, message = "Unauthorized"), })
			@ResponseStatus(value = HttpStatus.OK)
			
	public String refresh() throws Exception {
		
		DataServiceRegistry.intialize();
		cachedResultsDao.cachedQueries();
		
		logger.info( "Refreshing the data cloud");
		return "DataCloud Refreshed.";
	}
	
	@RequestMapping(value = "/pingOracle", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(value = HttpStatus.OK)
	public String  pingOracle() throws Exception {
		logger.info("Pinging Oracle {} ");
		return String.valueOf(genericDao.getGenericMap("oracle.pingOracle", new DataSourceCriteria()));
	}

	@RequestMapping(value = "/refreshEnum", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(value = HttpStatus.OK)
	public boolean refreshEnum() throws Exception {
		logger.info("Refreshing Enum References ");
		cachedResultsDao.cachedQueries();
		return true;
	}	
	
	@RequestMapping(value = "/pingMysql", method = RequestMethod.GET, produces = MediaType.TEXT_HTML)
	@ResponseStatus(value = HttpStatus.OK)
	public String  pingMysql() throws Exception {
	logger.info("Pinging Mysql {} ");
	return new ObjectMapper().writeValueAsString(genericDao.getGenericMap("mysql.pingMysql", new DataSourceCriteria()));
	}
	
	@RequestMapping(value = "/getDataBaseThreadDump", method = RequestMethod.GET, produces = "application/json")
	@ResponseStatus(value = HttpStatus.OK)
	public Object getDataBaseThreadDump() throws Exception {
		return new CommonUtils().getDataBaseThreadDump();
	}
}
