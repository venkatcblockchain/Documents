package com.vzw.orm.wflw.util;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanUtils;
import org.jbpm.process.instance.command.UpdateTimerCommand;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.manager.RuntimeEngine;
import org.kie.api.runtime.manager.RuntimeManager;
import org.kie.api.runtime.process.ProcessContext;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.internal.runtime.manager.RuntimeManagerRegistry;
import org.kie.internal.runtime.manager.context.ProcessInstanceIdContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.common.core.util.DateTimeUtils;
import com.vzw.common.core.util.StringUtils;
import com.vzw.orm.bpmi.domain.objects.consumer.ConsumerWorkflowRequest;
import com.vzw.orm.bpmi.domain.objects.consumer.WorkFlowRequest;

/**
 * This class is used to perform basic validations and utility operations
 * 
 * @author Rahul Kumar Agarwal
 *
 */
public class ConsumerUtil implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerUtil.class);

	/**
	 * This method is used to set all the variable values required to call MTAS
	 * in Consumer Workflow
	 * 
	 * @param kcontext
	 * @throws Exception
	 */
	public void initiateConsumerRequest(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering initiateConsumerRequest() method ...");
		try {
			WorkFlowRequest workFlowRequest = (WorkFlowRequest) kcontext.getVariable(BPMConstants.WORKFLOW_REQ);

			boolean prodParallelFlag = false;
			if ("Y".equalsIgnoreCase(workFlowRequest.getProductionParallelInd())) {
				prodParallelFlag = true;
			}
			kcontext.setVariable("productionParallelInd", prodParallelFlag);
			kcontext.setVariable("orderKey",
					"orderId," + workFlowRequest.getOrderId() + ",mtn," + workFlowRequest.getMtn());

			boolean is911 = false;
			if (workFlowRequest.getDeviceTechnology() != null
					&& "9".equalsIgnoreCase(workFlowRequest.getDeviceTechnology())) {
				is911 = true;
			}
			kcontext.setVariable("is911", is911);
			LOGGER.info("is911 line-->" + kcontext.getVariable("is911"));
			boolean is911sParent = false;
			if (workFlowRequest.getE911LineItemNumber() != null && !workFlowRequest.getE911LineItemNumber().isEmpty()) {
				is911sParent = true;
			}
			kcontext.setVariable("is911sParent", is911sParent);
			LOGGER.info("is911sParent-->" + kcontext.getVariable("is911sParent"));
			LOGGER.info("LineItemNo: " + workFlowRequest.getLineItemNumber() + " has is911 -->" + is911);
			kcontext.setVariable("callLoanCreation",
					"true".equalsIgnoreCase(workFlowRequest.getInstallmentLoan()) ? true : false);

			LOGGER.info("callLoanCreation:" + kcontext.getVariable("callLoanCreation"));

			if (is911sParent) {
				kcontext.setVariable("workflowRequestMain", workFlowRequest);
				WorkFlowRequest wfr = new WorkFlowRequest();
				BeanUtils.copyProperties(wfr, workFlowRequest);
				wfr.setDeviceTechnology("9");
				wfr.setLineItemNumber(workFlowRequest.getE911LineItemNumber());
				wfr.setE911LineItemNumber("");
				kcontext.setVariable("workflowRequest911", wfr);
			}
			LOGGER.info("OrderID:" + workFlowRequest.getOrderId() + " ProcessInstanceId:"
					+ kcontext.getProcessInstance().getId() + " ParentProcessInstanceId:"
					+ kcontext.getProcessInstance().getParentProcessInstanceId() + " ProductionParallelInd:"
					+ prodParallelFlag);

			kcontext.setVariable(BPMConstants.BUCKET_DT, DateTimeUtils.formatCurrentTsBasedOnFormat("yyyy-MM-dd"));

			kcontext.setVariable("pid", String.valueOf(kcontext.getProcessInstance().getParentProcessInstanceId()));
			kcontext.setVariable("ocSignalPid",
					String.valueOf(kcontext.getProcessInstance().getParentProcessInstanceId()));
			LOGGER.info("ocSignalPid:" + kcontext.getVariable("ocSignalPid"));
			kcontext.setVariable("cpid", String.valueOf(kcontext.getProcessInstance().getId()));
			kcontext.setVariable("portIn", workFlowRequest.getPortIn());
			kcontext.setVariable("isPortIn",
					("PI".equalsIgnoreCase(workFlowRequest.getPortIn())
							|| "PR".equalsIgnoreCase(workFlowRequest.getPortIn())
							|| "FV".equalsIgnoreCase(workFlowRequest.getPortIn())) ? true : false);
			kcontext.setVariable("isLNStatusUpdate", ("FV".equalsIgnoreCase(workFlowRequest.getPortIn())
					|| "PR".equalsIgnoreCase(workFlowRequest.getPortIn())) ? true : false);
			kcontext.setVariable("isVisibleMigration",
					"FV".equalsIgnoreCase(workFlowRequest.getPortIn()) ? true : false);
			kcontext.setVariable("is5gHome",
					"5GF".equalsIgnoreCase(workFlowRequest.getDeviceTechnology()) ? true : false);
			LOGGER.info("IS CASE MANAGEMENT REQUIRED:" + kcontext.getVariable("is5gHome"));
			boolean trackMtasNC = PropertyFile.getProjectProperties().get("TRACK_NON_CRITICAL_ELEMENTS") != null
					? Boolean.parseBoolean(
							PropertyFile.getProjectProperties().get("TRACK_NON_CRITICAL_ELEMENTS").toString())
					: false;
			LOGGER.info("trackMtasNC:" + trackMtasNC);
			kcontext.setVariable("enableNC", trackMtasNC);

			kcontext.setVariable("isFutureDated", false);
			SimpleDateFormat dateFormat = workFlowRequest.getOrderDueDate().length() > 10
					? new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS") : new SimpleDateFormat("yyyy-MM-dd");
			if (dateFormat.parse(workFlowRequest.getOrderDueDate())
					.compareTo(dateFormat.parse(workFlowRequest.getOrderDateTime())) > 0) {
				kcontext.setVariable("isFutureDated", true);
			}
			LOGGER.info("isFutureDated:" + kcontext.getVariable("isFutureDated"));
		} catch (Exception e) {
			LOGGER.error("Error in initiateConsumerRequest method. Exception : " + e);
			throw new Exception(e);
		}
	}

	public void getWorkflowRequestList(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering getWorkflowRequestList() method ...");
		try {
			ConsumerWorkflowRequest consumerWFRequest = (ConsumerWorkflowRequest) kcontext
					.getVariable("consumerWorkflowRequest");
			LOGGER.debug("consumerWFRequest before--> " + consumerWFRequest);

			String ppid = String.valueOf(kcontext.getProcessInstance().getId());

			consumerWFRequest.getLstOfWorkflowRequest().forEach(wrkflw -> wrkflw.setParentProcessInstanceId(ppid));
			LOGGER.debug("consumerWFRequest after ppid added--> " + consumerWFRequest);
			kcontext.setVariable("consumerWorkflowRequest", consumerWFRequest);

			ConsumerWorkflowRequest consumerWFRequestUpdated = new ConsumerWorkflowRequest();

			List<WorkFlowRequest> lstOfWorkflowRequestTemp = new ArrayList<WorkFlowRequest>();
			List<WorkFlowRequest> lstOfWorkflowRequestUpdated = new ArrayList<WorkFlowRequest>();
			List<WorkFlowRequest> lstOfWorkflowRequestForLineLevel = new ArrayList<WorkFlowRequest>();
			List<WorkFlowRequest> filteredListForAccountLevel = new ArrayList<WorkFlowRequest>();
			List<WorkFlowRequest> lstOfE911ParentWorkflowRequest = new ArrayList<WorkFlowRequest>();
			List<WorkFlowRequest> lstOfworkflowBranchForLineLevel = new ArrayList<WorkFlowRequest>();

			lstOfWorkflowRequestTemp = consumerWFRequest.getLstOfWorkflowRequest();
			for (WorkFlowRequest workflowRequest : lstOfWorkflowRequestTemp) {
				LOGGER.debug("adding line -->" + workflowRequest.getLineItemNumber());
				if (Integer.parseInt(workflowRequest.getLineItemNumber()) < 101) {
					lstOfWorkflowRequestForLineLevel.add(workflowRequest);
				} else {
					filteredListForAccountLevel.add(workflowRequest);
				}
			}
			LOGGER.debug("lstOfWorkflowRequestForLineLevel before-->" + lstOfWorkflowRequestForLineLevel);
			LOGGER.debug("filteredListForAccountLevel -->" + filteredListForAccountLevel);

			lstOfWorkflowRequestUpdated.addAll(filteredListForAccountLevel);

			Map<String, String> mtnLnItmCombo = new HashMap<String, String>();
			Set<String> e911MtnList = new HashSet<String>();
			for (WorkFlowRequest wfr : consumerWFRequest.getLstOfWorkflowRequest()) {
				if ("9".equalsIgnoreCase(wfr.getDeviceTechnology())) {
					mtnLnItmCombo.put(wfr.getMtn(), wfr.getLineItemNumber());
					e911MtnList.add(wfr.getMtn());
					lstOfWorkflowRequestForLineLevel.remove(wfr);
				}
			}

			LOGGER.info("mtnLnItmCombo:" + mtnLnItmCombo);
			kcontext.setVariable("mtnLnItmCombo", mtnLnItmCombo);
			kcontext.setVariable("e911MtnList", e911MtnList);
			LOGGER.info("e911MtnList-->" + e911MtnList);
			LOGGER.debug("lstOfWorkflowRequestForLineLevel after 911 removal-->" + lstOfWorkflowRequestForLineLevel);
			for (String mtn : e911MtnList) {
				for (WorkFlowRequest wfr : consumerWFRequest.getLstOfWorkflowRequest()) {
					if (mtn.equalsIgnoreCase(wfr.getMtn()) && !"9".equalsIgnoreCase(wfr.getDeviceTechnology())) {
						WorkFlowRequest wfr911 = wfr;
						wfr911.setE911LineItemNumber(mtnLnItmCombo.get(mtn).toString());
						lstOfE911ParentWorkflowRequest.add(wfr911);
						lstOfWorkflowRequestForLineLevel.remove(wfr);
					}
				}
			}
			LOGGER.debug("lstOfE911ParentWorkflowRequest ->" + lstOfE911ParentWorkflowRequest);
			lstOfWorkflowRequestForLineLevel.addAll(lstOfE911ParentWorkflowRequest);
			LOGGER.debug("lstOfWorkflowRequestForLineLevel after major dependent lines removal->"
					+ lstOfWorkflowRequestForLineLevel);

			kcontext.setVariable("filteredLstOfWorkflow", lstOfWorkflowRequestForLineLevel);
			if (kcontext.getVariable(BPMConstants.WORKFLOW_REQ) == null) {
				kcontext.setVariable(BPMConstants.WORKFLOW_REQ, lstOfWorkflowRequestForLineLevel.get(0));
			}
			if (consumerWFRequest.isOrderLevel()) {
				kcontext.setVariable("lstOfAccLevelLines", filteredListForAccountLevel);
			}

			kcontext.setVariable("lstOfWorkflowRequest", lstOfWorkflowRequestTemp);

			List<WorkFlowRequest> lstOfWorkflowRequestForLineLevelFinal = new ArrayList<WorkFlowRequest>();
			for (WorkFlowRequest wfReq : lstOfWorkflowRequestForLineLevel) {
				lstOfWorkflowRequestForLineLevelFinal.add(wfReq);
			}

			LOGGER.debug("lstOfWorkflowRequestForLineLevelFinal before-->" + lstOfWorkflowRequestForLineLevelFinal);
			for (WorkFlowRequest wfReq : lstOfWorkflowRequestForLineLevel) {
				if (wfReq != null && "4GI".equalsIgnoreCase(wfReq.getDeviceTechnology())) {
					kcontext.setVariable("isFiveGICL", true);
					WorkFlowRequest fourgBackupWFReq = new WorkFlowRequest();
					BeanUtils.copyProperties(fourgBackupWFReq, wfReq);
					kcontext.setVariable("workflowRequest4G", fourgBackupWFReq);
					lstOfWorkflowRequestForLineLevelFinal.remove(wfReq);
				}
			}

			LOGGER.info("isFiveGICL-->" + kcontext.getVariable("isFiveGICL"));
			LOGGER.debug("lstOfWorkflowRequestForLineLevelFinal after-->" + lstOfWorkflowRequestForLineLevelFinal);

			Set<String> filteredMtnList = new HashSet<>();
			for (WorkFlowRequest wfr : lstOfWorkflowRequestForLineLevelFinal) {
				filteredMtnList.add(wfr.getMtn());
			}

			LOGGER.info("filteredMtnList-->" + filteredMtnList);
			kcontext.setVariable("filteredMtnList", filteredMtnList);

			kcontext.setVariable("filteredLstOfWorkflow", lstOfWorkflowRequestForLineLevelFinal);

			lstOfWorkflowRequestUpdated.addAll(lstOfWorkflowRequestForLineLevelFinal);
			LOGGER.debug("lstOfWorkflowRequestUpdated-->" + lstOfWorkflowRequestUpdated);

			boolean accVPFlag = false;
			if (PropertyFile.getProjectProperties().get("ACC_LEVEL_VP_REQ") != null) {
				accVPFlag = Boolean
						.parseBoolean(PropertyFile.getProjectProperties().get("ACC_LEVEL_VP_REQ").toString());
			}
			LOGGER.info("Account Level VP Flag-->" + accVPFlag);
			boolean isQuartzTimerEnable = true;
			if (PropertyFile.getProjectProperties().get("IS_QUARTZ_TIMER_FLOW_ENABLE") != null) {
				isQuartzTimerEnable = Boolean.parseBoolean(
						PropertyFile.getProjectProperties().get("IS_QUARTZ_TIMER_FLOW_ENABLE").toString());
			}
			kcontext.setVariable("isQuartzTimerEnable", isQuartzTimerEnable);
			LOGGER.info("isQuartzTimerEnable  Flag--> {} ", isQuartzTimerEnable);

			boolean prodParallelFlag = false;
			boolean triggerALVP = false;

			for (WorkFlowRequest workFlowReqTemp : consumerWFRequest.getLstOfWorkflowRequest()) {
				if ("Y".equalsIgnoreCase(workFlowReqTemp.getProductionParallelInd())) {
					prodParallelFlag = true;
					if (accVPFlag && Integer.parseInt(workFlowReqTemp.getLineItemNumber()) > 100) {
						kcontext.setVariable("workflowRequestALVP", workFlowReqTemp);
						triggerALVP = true;
						break;
					}
				}
			}
			LOGGER.info("triggerALVP-->" + triggerALVP);
			kcontext.setVariable("triggerALVP", triggerALVP);
			kcontext.setVariable("productionParallelInd", prodParallelFlag);

			LOGGER.info("Checking if Subscription Manager to be invoked");
			boolean smRequired = false;
			for (WorkFlowRequest wfr : consumerWFRequest.getLstOfWorkflowRequest()) {
				if (wfr.getSpoCategoryCodes() != null && wfr.getSpoCategoryCodes().length > 0) {
					smRequired = true;
					LOGGER.info("Subscription Manager needs to be invoked");
					break;
				}
			}
			kcontext.setVariable("callSubsManager", smRequired);

			LOGGER.info("OrderID:" + consumerWFRequest.getLstOfWorkflowRequest().get(0).getOrderId()
					+ " ProcessInstanceId:" + kcontext.getProcessInstance().getId() + " ParentProcessInstanceId:"
					+ kcontext.getProcessInstance().getParentProcessInstanceId() + " ProductionParallelInd:"
					+ prodParallelFlag);

			kcontext.setVariable("orderLevel", consumerWFRequest.isOrderLevel());
			kcontext.setVariable("correlationId",
					consumerWFRequest.getLstOfWorkflowRequest().get(0).getCorrelationId());
			if (kcontext.getVariable("orderKey") == null) {
				kcontext.setVariable("orderKey",
						"orderId," + consumerWFRequest.getLstOfWorkflowRequest().get(0).getOrderId());
			}
			LOGGER.info("Request type orderLevel:" + kcontext.getVariable("orderLevel"));
			// UPDATING PARENT WF REQUEST OBJECT
			BeanUtils.copyProperties(consumerWFRequestUpdated, consumerWFRequest);
			consumerWFRequestUpdated.setLstOfWorkflowRequest(null);
			consumerWFRequestUpdated.setLstOfWorkflowRequest(lstOfWorkflowRequestUpdated);
			LOGGER.info("consumerWFRequestUpdated-->" + consumerWFRequestUpdated);
			kcontext.setVariable("consumerWorkflowRequest", consumerWFRequestUpdated);

			kcontext.setVariable("pid", String.valueOf(kcontext.getProcessInstance().getId()));
			kcontext.setVariable(BPMConstants.BUCKET_DT, DateTimeUtils.formatCurrentTsBasedOnFormat("yyyy-MM-dd"));

			kcontext.setVariable("ocSignalLaunched", false);
			kcontext.setVariable("is911SignalLaunched", false);
			kcontext.setVariable("vroAccTriggered", false);
			kcontext.setVariable("alvpAlreadyTriggered", false);
			kcontext.setVariable("smTriggered", false);
			kcontext.setVariable("orderDelete", false);
			kcontext.setVariable("allReceived", false);
			kcontext.setVariable("orderCompleted", false);

			// Due Date Calculation Here
			calculateDueDate(kcontext);

		} catch (Exception e) {
			LOGGER.error("Error in getWorkflowRequestList method. Exception : " + e);
			e.printStackTrace();
			throw new Exception(e);
		}
	}

	public void signalOrderCompletion(ProcessContext kcontext, String signalId, long processInstanceId) {
		LOGGER.info("Entering signalAccountOrLineForVRO() method to signal: " + signalId + " for processInstanceId:"
				+ processInstanceId);
		try {
			WorkFlowRequest workFlowRequest = (WorkFlowRequest) kcontext.getVariable(BPMConstants.WORKFLOW_REQ);

			RuntimeManager rm = (RuntimeManager) kcontext.getKieRuntime().getEnvironment().get("RuntimeManager");
			RuntimeEngine runtime = rm.getRuntimeEngine(ProcessInstanceIdContext.get(Long.valueOf(processInstanceId)));
			KieSession ksession = runtime.getKieSession();
			ProcessInstance processInstance = ksession.getProcessInstance(Long.valueOf(processInstanceId), true);

			// creating runtime manager and runtime engine for parent process
			rm = RuntimeManagerRegistry.get()
					.getManager(runtime.getAuditService().findProcessInstance(processInstance.getId()).getExternalId());
			runtime = rm.getRuntimeEngine(ProcessInstanceIdContext.get(processInstance.getId()));

			runtime.getKieSession().getProcessInstance(processInstance.getId(), true).signalEvent(signalId,
					workFlowRequest);

			LOGGER.info("Signalled to the process : " + processInstance.getProcessName()
					+ " with process instance id : " + processInstance.getId() + " and signal name is : " + signalId);

		} catch (Exception e) {
			LOGGER.error("Exception while signalling " + signalId + ": " + e.getMessage());
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void calculateDueDate(ProcessContext kcontext) {
		LOGGER.info("Inside calculateDueDate() method.....");
		kcontext.setVariable("isOrderDue", false);
		kcontext.setVariable("isCancel", false);

		// kcontext.setVariable("releasedEarlyInd", false);
		// kcontext.setVariable("firstLineInd", false);

		try {
			ConsumerWorkflowRequest consumerWFRequest = (ConsumerWorkflowRequest) kcontext
					.getVariable("consumerWorkflowRequest");
			kcontext.setVariable("lstOfWorkflowRequest", consumerWFRequest.getLstOfWorkflowRequest());
			String orderDateTime = consumerWFRequest.getLstOfWorkflowRequest().get(0).getOrderDateTime();
			String orderDueDate = consumerWFRequest.getLstOfWorkflowRequest().get(0).getOrderDueDate();
			kcontext.setVariable("dueDate", orderDueDate);
			SimpleDateFormat dateFormat = orderDueDate.length() > 10 ? new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
					: new SimpleDateFormat("yyyy-MM-dd");
			Date cd = dateFormat.parse(orderDateTime);
			Date dd = dateFormat.parse(orderDueDate);
			int value = dd.compareTo(cd);
			if (value == 0) {
				LOGGER.info("Due Date is equal to Order Date");
			} else if (value > 0) {
				LOGGER.info("Due Date is greater than Order Date");
				kcontext.setVariable("isOrderDue", true);
				// kcontext.setVariable("firstLineInd", true);

				// Below code is for Testing env-start

				Date dueDate = dateFormat.parse(orderDueDate);
				LOGGER.info("dueDate after parsing-->" + dueDate);
				SimpleDateFormat dateToFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
				String duedate = dateToFormat.format(dueDate);
				LOGGER.info("duedate after formatting-->" + duedate);
				LocalDateTime dueLocalDateTime = LocalDateTime.parse(duedate).withHour(0).withMinute(0).withSecond(0);
				// end

				// add the below 2 lines to test in local and comment above
				// lines
				/*
				 * DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
				 * "yyyy-MM-dd HH:mm:ss.SSSSSS"); LocalDateTime dueLocalDateTime
				 * = LocalDateTime.parse(orderDueDate, formatter);
				 */
				// end
				LOGGER.info("dueLocalDateTime-->" + dueLocalDateTime);
				LocalDateTime currentDate = null;
				String billingInstance = consumerWFRequest.getLstOfWorkflowRequest().get(0).getBillingInstance();
				if (billingInstance != null) {
					if ("E".equalsIgnoreCase(billingInstance) || "N".equalsIgnoreCase(billingInstance)) {
						LOGGER.info("Eastern Timezone as billingInstance is " + billingInstance);
						currentDate = LocalDateTime.now(ZoneId.of("America/New_York"));
					} else if ("W".equalsIgnoreCase(billingInstance) || "B".equalsIgnoreCase(billingInstance)) {
						currentDate = LocalDateTime.now(ZoneId.of("America/Los_Angeles"));
						LOGGER.info("Pacific Timezone as billingInstance is " + billingInstance);
					} else {
						LOGGER.info("Considering the default Timezone as billingInstance is " + billingInstance);
						currentDate = LocalDateTime.now(ZoneId.systemDefault());
					}
				} else {
					currentDate = LocalDateTime.now(ZoneId.systemDefault());
				}
				LOGGER.info("currentDate-->" + currentDate);
				Duration duration = Duration.between(currentDate, dueLocalDateTime);
				LOGGER.info("duration-->" + duration);
				LOGGER.info("duration in seconds-->" + duration.getSeconds());
				kcontext.setVariable("orderDueDate", String.valueOf(duration.getSeconds()) + "s");

				// kcontext.setVariable("orderDueDate", String.valueOf(due) +
				// "s");

				/*
				 * List<WorkFlowRequest> wfrList = new ArrayList<>(); wfrList =
				 * (List<WorkFlowRequest>)
				 * kcontext.getVariable("filteredLstOfWorkflow"); for
				 * (WorkFlowRequest wfr : wfrList) {
				 * wfr.setReleasedEarlyInd("false"); }
				 * kcontext.setVariable("filteredLstOfWorkflow",wfrList);
				 */

			} else {
				LOGGER.info("Due Date is less than Order Date");
			}
		} catch (Exception e) {
			LOGGER.error("Exception while calculating due date" + e);
		}
	}
	
	private long recalculateDueDate(ConsumerWorkflowRequest consumerWFRequest) {
		LOGGER.info("Inside re-calculateDueDate() method.....");
		long reCalTimer = 1;
		try {

			String orderDueDate = consumerWFRequest.getLstOfWorkflowRequest().get(0).getOrderDueDate();
			SimpleDateFormat dateFormat = orderDueDate.length() > 10 ? new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
					: new SimpleDateFormat("yyyy-MM-dd");

			// Below code is for Testing env-start
			Date dueDate = dateFormat.parse(orderDueDate);
			LOGGER.info("dueDate after parsing-->" + dueDate);
			SimpleDateFormat dateToFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
			String duedate = dateToFormat.format(dueDate);
			LOGGER.info("duedate after formatting-->" + duedate);
			LocalDateTime dueLocalDateTime = LocalDateTime.parse(duedate).withHour(0).withMinute(0).withSecond(0);
			// end

			// add the below 2 lines to test in local and comment above
			// lines
			/*
			 * DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
			 * "yyyy-MM-dd HH:mm:ss.SSSSSS"); LocalDateTime dueLocalDateTime =
			 * LocalDateTime.parse(orderDueDate, formatter);
			 */
			// end
			LOGGER.info("dueLocalDateTime-->" + dueLocalDateTime);
			LocalDateTime currentDate = null;
			String billingInstance = consumerWFRequest.getLstOfWorkflowRequest().get(0).getBillingInstance();
			if (billingInstance != null) {
				if ("E".equalsIgnoreCase(billingInstance) || "N".equalsIgnoreCase(billingInstance)) {
					LOGGER.info("Eastern Timezone as billingInstance is " + billingInstance);
					currentDate = LocalDateTime.now(ZoneId.of("America/New_York"));
				} else if ("W".equalsIgnoreCase(billingInstance) || "B".equalsIgnoreCase(billingInstance)) {
					currentDate = LocalDateTime.now(ZoneId.of("America/Los_Angeles"));
					LOGGER.info("Pacific Timezone as billingInstance is " + billingInstance);
				} else {
					LOGGER.info("Considering the default Timezone as billingInstance is " + billingInstance);
					currentDate = LocalDateTime.now(ZoneId.systemDefault());
				}
			} else {
				currentDate = LocalDateTime.now(ZoneId.systemDefault());
			}
			LOGGER.info("recal -currentDate -->" + currentDate);
			Duration duration = Duration.between(currentDate, dueLocalDateTime);
			LOGGER.info("recal - duration -->" + duration);
			LOGGER.info("recal - duration in seconds -->" + duration.getSeconds());
			reCalTimer = duration.getSeconds();
		

		} catch (Exception e) {
			LOGGER.error("Exception while calculating due date" + e);
		}

		return reCalTimer;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void validateSignalAndUpdateTimer(String timerName, long timerValue, ProcessContext kcontext) {
		LOGGER.info("Entering validateSignalAndUpdateTimer() method for processInstanceId:"
				+ kcontext.getProcessInstance().getId());
		try {

			Map<String, Object> resp = (Map<String, Object>) kcontext.getVariable("result");
			LOGGER.info("Signal Data for UPDATE ORDER signal is:" + resp);
			if (resp != null && resp.size() > 0) {
				if (resp.get("action") != null) {
					ConsumerWorkflowRequest consumerWFRequest = (ConsumerWorkflowRequest) kcontext
							.getVariable("consumerWorkflowRequest");
					// Boolean firsLineInd =
					// (Boolean)kcontext.getVariable("firstLineInd");
					if ("RELEASE".equalsIgnoreCase(resp.get("action").toString())) {
						kcontext.setVariable("isCancel", false);
						kcontext.setVariable("orderDueDate", "1ms");
						timerValue = 1;
						List<WorkFlowRequest> wfrList = new ArrayList<>();
						Set<String> releasedMtnsFromBpmi = new HashSet<String>();
						if (resp.get("mtn") != null) {
							for (WorkFlowRequest wfr : consumerWFRequest.getLstOfWorkflowRequest()) {
								if (resp.get("mtn").toString().contains(wfr.getMtn())) {
									LOGGER.info("About to release lineItmNo [" + wfr.getLineItemNumber()
											+ "] in order :" + wfr.getOrderId());
									/*
									 * if (firsLineInd != null) {
									 * wfr.setFirstLineInd(firsLineInd.toString(
									 * )); } else { wfr.setFirstLineInd("true");
									 * } wfr.setReleasedEarlyInd("true");
									 */
									wfrList.add(wfr);
									releasedMtnsFromBpmi.add(wfr.getMtn());
								}
							}

							kcontext.setVariable("firstLineInd", false);
							if (kcontext.getVariable("releaseMtnList") != null) {
								Set<String> releaseMtnList = (Set<String>) kcontext.getVariable("releaseMtnList");
								releaseMtnList.addAll(releasedMtnsFromBpmi);
							} else {
								Set<String> releaseMtnList = new HashSet<String>();
								releaseMtnList.addAll(releasedMtnsFromBpmi);
								kcontext.setVariable("releaseMtnList", releaseMtnList);
							}

							LOGGER.info("releaseMtnList-->" + kcontext.getVariable("releaseMtnList"));

							kcontext.setVariable("filteredLstOfWorkflow", wfrList);

							LOGGER.info("filteredLstOfWorkflow -->" + kcontext.getVariable("filteredLstOfWorkflow"));

						} else {
							LOGGER.info("Release all MTNs");
							List<WorkFlowRequest> filteredList = consumerWFRequest.getLstOfWorkflowRequest().stream()
									.filter(wrkflw -> Integer.parseInt((wrkflw.getLineItemNumber())) < 101)
									.collect(Collectors.toList());

							Set<String> mtnsListFromReq = filteredList.stream().map(WorkFlowRequest::getMtn)
									.collect(Collectors.toSet());
							if (kcontext.getVariable("releaseMtnList") != null) {
								Set<String> releaseMtnList = (Set<String>) kcontext.getVariable("releaseMtnList");
								releaseMtnList.addAll(mtnsListFromReq);
							} else {
								Set<String> releaseMtnList = new HashSet<String>();
								releaseMtnList.addAll(mtnsListFromReq);
								kcontext.setVariable("releaseMtnList", releaseMtnList);
							}
							/*
							 * List<WorkFlowRequest> wfrListUpd =
							 * (ArrayList<WorkFlowRequest>)
							 * kcontext.getVariable("filteredLstOfWorkflow");
							 * for (WorkFlowRequest wfr : wfrListUpd) { if
							 * (firsLineInd != null) {
							 * wfr.setFirstLineInd(firsLineInd.toString()); }
							 * else { wfr.setFirstLineInd("true"); }
							 * wfr.setReleasedEarlyInd("true");
							 * wfrList.add(wfr); }
							 * kcontext.setVariable("firstLineInd", false);
							 * kcontext.setVariable("filteredLstOfWorkflow",
							 * wfrList);
							 */

							LOGGER.info("releaseMtnList-->" + kcontext.getVariable("releaseMtnList"));
							LOGGER.info("filteredLstOfWorkflow -->" + kcontext.getVariable("filteredLstOfWorkflow"));

						}

					} else if ("CANCEL".equalsIgnoreCase(resp.get("action").toString())) {
						kcontext.setVariable("isCancel", true);
						kcontext.setVariable("orderDueDate", "1ms");

						WorkFlowRequest releaseWfr = new WorkFlowRequest();
						if (resp.get("mtn") != null) {
							for (WorkFlowRequest wfr : consumerWFRequest.getLstOfWorkflowRequest()) {
								if (wfr.getMtn().equalsIgnoreCase(resp.get("mtn").toString())) {
									LOGGER.info("About to cancel lineItmNo [" + wfr.getLineItemNumber() + "] in order :"
											+ wfr.getOrderId());
									releaseWfr = wfr;
									break;
								}
							}
						}
						kcontext.setVariable(BPMConstants.WORKFLOW_REQ, releaseWfr);
						Set<String> mtnList = (Set<String>) kcontext.getVariable("filteredMtnList");
						mtnList.remove(resp.get("mtn").toString());
						kcontext.setVariable("filteredMtnList", mtnList);
						LOGGER.info("mtnList after removing cancelled lines-->" + kcontext.getVariable("mtnList"));
						if (mtnList != null && mtnList.size() == 0) {
							LOGGER.info(
									"mtnList is null. Proceeding to delete the order as all lines received cancel.");
							kcontext.setVariable("orderDelete", true);
							kcontext.setVariable("allReceived", true);
						}

						if (kcontext.getVariable("cancelMtnList") != null) {
							Set<String> cancelMtnList = (Set) kcontext.getVariable("cancelMtnList");
							cancelMtnList.add(resp.get("mtn").toString());
						} else {
							Set<String> cancelMtnList = new HashSet<>();
							cancelMtnList.add(resp.get("mtn").toString());
							kcontext.setVariable("cancelMtnList", cancelMtnList);
						}
						LOGGER.info("cancelMtnList-->" + kcontext.getVariable("cancelMtnList"));

						/*
						 * List<WorkFlowRequest> wfrList = new
						 * ArrayList<WorkFlowRequest>();
						 * wfrList.add(releaseWfr);
						 * kcontext.setVariable("filteredLstOfWorkflow",
						 * wfrList); LOGGER.info("filteredLstOfWorkflow -->"
						 * +kcontext.getVariable("filteredLstOfWorkflow"));
						 */

						timerValue = 1;
					}
					else if ("MODIFYPENDINGORDER".equalsIgnoreCase(resp.get("action").toString())) {
						
						ConsumerWorkflowRequest consumerWorkflowRequest = (ConsumerWorkflowRequest) resp
								.get("consumerWorkflowRequest");
						kcontext.setVariable("consumerWorkflowRequest", consumerWorkflowRequest);
						LOGGER.info("DYMER is: " + timerValue);
						timerValue = recalculateDueDate(consumerWorkflowRequest);
						
						kcontext.setVariable("isModifyPending", true);
						LOGGER.info("timerValue when we recieve modify/pending order -->" + timerValue);
						RuntimeManager rm = (RuntimeManager) kcontext.getKieRuntime().getEnvironment()
								.get("RuntimeManager");
						RuntimeEngine runtime = rm
								.getRuntimeEngine(ProcessInstanceIdContext.get(kcontext.getProcessInstance().getId()));
						KieSession ksession = runtime.getKieSession();
						ksession.execute(
								new UpdateTimerCommand(kcontext.getProcessInstance().getId(), timerName, timerValue));
						LOGGER.info("DYMER value has been updated");
						
						LOGGER.info("Modify Pending Order Flag-->" + kcontext.getVariable("isModifyPending"));

					} else {
						LOGGER.info("Received invalid action for Signal");
					}

					// if((Integer)kcontext.getVariable("noOfLines") == )

					/*
					 * LOGGER.info("timerValue-->" + timerValue); RuntimeManager
					 * rm = (RuntimeManager)
					 * kcontext.getKieRuntime().getEnvironment()
					 * .get("RuntimeManager"); RuntimeEngine runtime = rm
					 * .getRuntimeEngine(ProcessInstanceIdContext.get(kcontext.
					 * getProcessInstance().getId())); KieSession ksession =
					 * runtime.getKieSession(); ksession.execute( new
					 * UpdateTimerCommand(kcontext.getProcessInstance().getId(),
					 * timerName, timerValue)); LOGGER.info(
					 * "DYMER value has been updated");
					 * rm.disposeRuntimeEngine(runtime);
					 */

				} else {
					LOGGER.info("No need to update DYMER as there's no action defined in the payload");
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception inside validateSignalAndUpdateTimer method: " + e.getMessage());
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void verifyOCForLastCancel(ProcessContext kcontext) {
		LOGGER.info("Entering verifyOCForLastCancel() method..");
		try {
			Set<String> mtnList = (Set) kcontext.getVariable("filteredMtnList");
			LOGGER.info("filteredMtnList inside verifyOCForLastCancel:" + mtnList);
			if (kcontext.getVariable("receivedMtnList") != null) {
				Set<String> completedMtns = (Set) kcontext.getVariable("receivedMtnList");
				LOGGER.info("completedMtns inside verifyOCForLastCancel:" + completedMtns);
				if (mtnList != null && mtnList.size() > 0 && completedMtns != null && completedMtns.size() > 0
						&& mtnList.containsAll(completedMtns)) {
					LOGGER.info(completedMtns.size() + " lines already LC and other lines got LD. Proceeding to OC.");
					kcontext.setVariable("orderCompleted", true);
					ConsumerWorkflowRequest consumerWFRequest = (ConsumerWorkflowRequest) kcontext
							.getVariable("consumerWorkflowRequest");
					for (WorkFlowRequest wfreq : consumerWFRequest.getLstOfWorkflowRequest()) {
						if (mtnList.contains(wfreq.getMtn())) {
							kcontext.setVariable(BPMConstants.WORKFLOW_REQ, wfreq);
							break;
						}
					}
				} else {
					LOGGER.info("Other lines yet to be released/provisioned");
				}
			}

		} catch (Exception e) {
			LOGGER.info("Exception inside verifyOCForLastCancel method: " + e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public void closeUpdateOrderSignal(ProcessContext kcontext, String signalKey) {
		LOGGER.info("Entering closeUpdateOrderSignal() method after DYMER expiration...");
		try {

			ConsumerWorkflowRequest consumerWFRequest = (ConsumerWorkflowRequest) kcontext
					.getVariable("consumerWorkflowRequest");
			kcontext.setVariable("isCancel", false);
			LOGGER.info("filteredMtnList:" + kcontext.getVariable("filteredMtnList"));
			LOGGER.info("releaseMtnList:" + kcontext.getVariable("releaseMtnList"));
			LOGGER.info("cancelMtnList:" + kcontext.getVariable("cancelMtnList"));
			List<WorkFlowRequest> wfrListToLineLevel = new ArrayList<WorkFlowRequest>();
			List<WorkFlowRequest> filteredList = consumerWFRequest.getLstOfWorkflowRequest().stream()
					.filter(wrkflw -> Integer.parseInt((wrkflw.getLineItemNumber())) < 101)
					.collect(Collectors.toList());
			Set<String> allMtns = new HashSet<String>();

			Set<String> releaseMtnList = (Set<String>) kcontext.getVariable("releaseMtnList");
			if (releaseMtnList != null && releaseMtnList.size() > 0) {
				allMtns.addAll(releaseMtnList);
			}

			Set<String> cancelMtnList = (Set<String>) kcontext.getVariable("cancelMtnList");
			if (cancelMtnList != null && cancelMtnList.size() > 0) {
				allMtns.addAll(cancelMtnList);
			}

			LOGGER.info("allMtns that are already released/canceled-->" + allMtns);
			/*
			 * Set<String> mtns = (Set<String>)kcontext.getVariable("mtnList");
			 * mtns.removeAll(allMtns); LOGGER.info(
			 * "mtnList to be provisioned after removing release/cancel mtns-->"
			 * +mtns);
			 */

			if (allMtns != null && allMtns.size() > 0) {
				for (WorkFlowRequest wfr : filteredList) {
					if (!allMtns.contains(wfr.getMtn())) {
						wfrListToLineLevel.add(wfr);
					}
				}
				LOGGER.info("wfrListToLineLevel after removing release/canceled lines-->" + wfrListToLineLevel);
				kcontext.setVariable("filteredLstOfWorkflow", wfrListToLineLevel);
				if (wfrListToLineLevel.size() == 0) {
					kcontext.setVariable("allReceived", true);
					LOGGER.info("All Lines Received Release/Cancel. Proceeding to End :"
							+ kcontext.getVariable("allReceived"));
				}
			} else {
				kcontext.setVariable("filteredLstOfWorkflow", filteredList);
			}
			LOGGER.info("mtnList:" + kcontext.getVariable("filteredMtnList"));
			LOGGER.info("filteredLstOfWorkflow-->" + kcontext.getVariable("filteredLstOfWorkflow"));

			LOGGER.info("De-activating safe point of signalKey : " + signalKey + " and signalId : "
					+ kcontext.getVariable(signalKey));

			if (signalKey != null && kcontext.getVariable(signalKey) != null) {
				kcontext.getKieRuntime().getWorkItemManager()
						.completeWorkItem(Long.parseLong(String.valueOf(kcontext.getVariable(signalKey))), null);
			}

		} catch (Exception e) {
			LOGGER.error("Exception inside closeUpdateOrderSignal method. Exception : " + e);
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void checkLineCompletion(ProcessContext kcontext) {

		LOGGER.info("Entering checkLineCompletion() method..");
		kcontext.setVariable("allLinesCompleted", false);
		try {
			WorkFlowRequest workflowRequest = (WorkFlowRequest) kcontext.getVariable("workflowRequest");
			LOGGER.info("workFlowRequest signal for MTN -->" + workflowRequest.getMtn());

			Set<String> mtnList = (Set<String>) kcontext.getVariable("mtnList");
			LOGGER.info("mtnList :" + mtnList);

			Set<String> completedMtnList = null;
			Set<String> completedMtnListDummy = new HashSet<String>();
			if (kcontext.getVariable("receivedMtnList") != null) {
				completedMtnList = (Set<String>) kcontext.getVariable("receivedMtnList");
			} else {
				completedMtnList = new HashSet<String>();
			}

			LOGGER.info("completedMtnList before-->" + completedMtnList);
			completedMtnList.add(workflowRequest.getMtn());
			for (String mtn : completedMtnList) {
				completedMtnListDummy.add(mtn);
			}
			LOGGER.info("completedMtnList after-->" + completedMtnList);
			LOGGER.info("completedMtnListDummy-->" + completedMtnListDummy);
			kcontext.setVariable("receivedMtnList", completedMtnListDummy);
			LOGGER.info("kcontext.getVariable(\"receivedMtnList\")-->" + kcontext.getVariable("receivedMtnList"));

			if (mtnList.size() == completedMtnListDummy.size()) {

				if (StringUtils.isEmpty(String.valueOf(kcontext.getVariable("isBranchLinePending"))) || (!StringUtils
						.isEmpty(String.valueOf(kcontext.getVariable("isBranchLinePending")))
						&& !Boolean.parseBoolean(String.valueOf(kcontext.getVariable("isBranchLinePending"))))) {
					// set true if branch line is not pending
					kcontext.setVariable("allLinesCompleted", true);
					LOGGER.info("All Lines Completed Successfully");
				}
				{
					kcontext.setVariable("isBranchLineProcessStart", true);
					kcontext.setVariable("receivedMtnList", null);
					LOGGER.info("All  trunk lines are completed Successfully , Branch lines will start processing");
				}

			}
			/*
			 * Boolean isFiveGICL = (Boolean)
			 * kcontext.getVariable("isFiveGICL"); if (isFiveGICL != null &&
			 * isFiveGICL) { if
			 * ("5GI".equalsIgnoreCase(workflowRequest.getDeviceTechnology())) {
			 * kcontext.setVariable("allLinesCompleted", null); } }
			 */
		} catch (Exception e) {
			LOGGER.error("Exception inside checkLineCompletion() method :" + e.getMessage());
		}
	}

	public void signalParentProcess(ProcessContext kcontext, String ocPid) throws Exception {
		LOGGER.info("Entering into signalParentProcess() method..");
		try {
			WorkFlowRequest workFlowRequest = (WorkFlowRequest) kcontext.getVariable(BPMConstants.WORKFLOW_REQ);
			LOGGER.info("OrderID:" + workFlowRequest.getOrderId() + " ProcessInstanceId:"
					+ kcontext.getProcessInstance().getId() + " ParentProcessInstanceId:"
					+ kcontext.getProcessInstance().getParentProcessInstanceId());

			ServiceProvider bpmUtil = new ServiceProvider();
			String URL = bpmUtil.getServiceURL(PropertyFile.PROP_CONST.KIE_SERVER_BASE_URL.toString(),
					BPMConstants.SERVICE_ID_BPM);

			String depId = (String) kcontext.getKieRuntime().getEnvironment().get(BPMConstants.DEPLOYMENT_ID);
			URL = URL + "/" + depId + "/processes/instances/" + workFlowRequest.getParentProcessInstanceId()
					+ "/signal/OC_SIGNAL";
			LOGGER.info("OC_SIGNAL URL : " + URL);

			kcontext.setVariable("url", URL);
			kcontext.setVariable("bpmAccessKey",
					PropertyFile.getProjectProperties().get(BPMConstants.KIE_SERVER_INVOKE_ID));
			kcontext.setVariable("bpmAccessCode",
					PropertyFile.getProjectProperties().get(BPMConstants.KIE_SERVER_INVOKE_TOKEN));
			kcontext.setVariable(BPMConstants.CONNECTION_TIME_OUT, PropertyFile.getInstance().getConnectionTimeOut());
			kcontext.setVariable(BPMConstants.READ_TIME_OUT, PropertyFile.getInstance().getReadTimeOut());
			ObjectMapper mapper = new ObjectMapper();
			String request = "{\"com.vzw.orm.bpmi.domain.objects.consumer.WorkFlowRequest\": "
					+ mapper.writeValueAsString(workFlowRequest) + "}";
			kcontext.setVariable(BPMConstants.CONTENT, request);
			LOGGER.info("OC SIGNAL Content is:" + request);

		} catch (Exception e) {
			LOGGER.error("Exception while signaling OC_SINGAL" + e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public void signalChildProcess(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering into signalChildProcess() method..");
		try {
			WorkFlowRequest workFlowRequest = (WorkFlowRequest) kcontext.getVariable(BPMConstants.WORKFLOW_REQ);
			LOGGER.info("OrderID:" + workFlowRequest.getOrderId() + " ProcessInstanceId:"
					+ kcontext.getProcessInstance().getId() + " ParentProcessInstanceId:"
					+ kcontext.getProcessInstance().getParentProcessInstanceId());

			ServiceProvider bpmUtil = new ServiceProvider();
			String URL = bpmUtil.getServiceURL(PropertyFile.PROP_CONST.KIE_SERVER_BASE_URL.toString(),
					BPMConstants.SERVICE_ID_BPM);

			CloseOutProcessUtil cop = new CloseOutProcessUtil();
			cop.getChildProcessesToAbort(kcontext, "parent");

			List<String> pidList = (List<String>) kcontext.getVariable("pidList");
			String pid = pidList.get(0);

			String depId = (String) kcontext.getKieRuntime().getEnvironment().get(BPMConstants.DEPLOYMENT_ID);
			URL = URL + "/" + depId + "/processes/instances/" + pid + "/signal/LCD_SIGNAL";
			LOGGER.info("LCD_SIGNAL URL : " + URL);

			kcontext.setVariable("url", URL);
			kcontext.setVariable("bpmAccessKey",
					PropertyFile.getProjectProperties().get(BPMConstants.KIE_SERVER_INVOKE_ID));
			kcontext.setVariable("bpmAccessCode",
					PropertyFile.getProjectProperties().get(BPMConstants.KIE_SERVER_INVOKE_TOKEN));
			kcontext.setVariable(BPMConstants.CONNECTION_TIME_OUT, PropertyFile.getInstance().getConnectionTimeOut());
			kcontext.setVariable(BPMConstants.READ_TIME_OUT, PropertyFile.getInstance().getReadTimeOut());
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> request = new HashMap<String, Object>();
			request.put("action", "CLOSE");
			request.put("mtn", workFlowRequest.getMtn());
			LOGGER.info("LCD_SIGNAL Content is:" + mapper.writeValueAsString(request));
			kcontext.setVariable(BPMConstants.CONTENT, mapper.writeValueAsString(request));

		} catch (Exception e) {
			LOGGER.error("Exception while signaling:" + e.getMessage());
		}
	}

	public void checkForFiveGLines(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering checkForFiveGLines() method ...");
		try {
			ConsumerWorkflowRequest consumerWFRequest = (ConsumerWorkflowRequest) kcontext
					.getVariable("consumerWorkflowRequest");
			kcontext.setVariable("consumerWorkflowRequestMain", consumerWFRequest);
			boolean fivegFlag = false;
			Set<String> collectedMtns = new HashSet<String>();
			for (WorkFlowRequest wfr : consumerWFRequest.getLstOfWorkflowRequest()) {
				if (Integer.parseInt(wfr.getLineItemNumber()) < 101) {
					collectedMtns.add(wfr.getMtn());
				}
				if (wfr.getDeviceTechnology() != null && "5".equalsIgnoreCase(wfr.getDeviceTechnology())
						&& !fivegFlag) {
					fivegFlag = true;
					LOGGER.info("5G line exists. BPM Data Update MS needs to be invoked to update device Technology");
				}
			}
			LOGGER.info("collectedMtns -->" + collectedMtns);
			kcontext.setVariable("mtnList", collectedMtns);
			LOGGER.info("fivegFlag -->" + fivegFlag);
			kcontext.setVariable("fivegFlag", fivegFlag);
		} catch (Exception e) {
			LOGGER.error("Error in getWorkflowRequestList method. Exception : " + e);
			throw new Exception(e);
		}
	}

	/*
	 * @SuppressWarnings("unchecked") public void
	 * release911Parent(ProcessContext kcontext) throws Exception { LOGGER.info(
	 * "inside release911Parent() method"); List<WorkFlowRequest> filteredList =
	 * new ArrayList<WorkFlowRequest>(); try{ ConsumerWorkflowRequest
	 * consumerWFRequest = (ConsumerWorkflowRequest) kcontext
	 * .getVariable("consumerWorkflowRequest");
	 * 
	 * Map<String, Object> resp = (Map<String, Object>)
	 * kcontext.getVariable("result"); String e911MtnLc =
	 * (String)resp.get("mtnLC"); LOGGER.info("e911MtnLc-->"+e911MtnLc);
	 * kcontext.setVariable("e911Status", resp.get("statusType").toString());
	 * if("LC".equalsIgnoreCase(resp.get("statusType").toString())){
	 * for(WorkFlowRequest wfr : consumerWFRequest.getLstOfWorkflowRequest()) {
	 * if(e911MtnLc.equalsIgnoreCase(wfr.getMtn()) &&
	 * !"9".equalsIgnoreCase(wfr.getDeviceTechnology())){ WorkFlowRequest
	 * wfrToRelease = new WorkFlowRequest(); Map<String,String> map =
	 * (HashMap<String,String>)kcontext.getVariable("mtnLnItmCombo");
	 * LOGGER.info("LineItem to release-->" +wfr.getLineItemNumber() +
	 * " and corresponding e911LineItmNo:"+map.get(wfr.getMtn()));
	 * BeanUtils.copyProperties(wfr, wfrToRelease);
	 * wfrToRelease.setE911LineItemNumber(map.get(wfr.getMtn()));
	 * filteredList.add(wfrToRelease); break; } } }else{ LOGGER.info(
	 * "Not initating parent as the line is already "+resp.get("statusType")); }
	 * LOGGER.info("filteredList to release-->"+filteredList); }catch(Exception
	 * e){ LOGGER.error("Exception while release911Parent " +e.getMessage()); }
	 * kcontext.setVariable("filteredLstOfWorkflow", filteredList);
	 * 
	 * }
	 * 
	 * public void e911CompletionParams(ProcessContext kcontext, String type)
	 * throws Exception { LOGGER.info("inside e911CompletionParams() method");
	 * try{ ObjectMapper mapper = new ObjectMapper(); WorkFlowRequest wfr =
	 * (WorkFlowRequest) kcontext.getVariable("workflowRequest"); Map<String,
	 * Object> resp = new HashMap<String, Object>(); resp.put("statusType",
	 * type); resp.put("mtnLC", wfr.getMtn());
	 * kcontext.setVariable("e911SignalResp", resp);
	 * LOGGER.info("e911SignalResp:" +mapper.writeValueAsString(resp));
	 * }catch(Exception e){ LOGGER.error("Exception while e911CompletionParams "
	 * +e.getMessage()); } }
	 */

	public void signalProcess(ProcessContext kcontext, String pid, String sid, Object payload) throws Exception {
		LOGGER.info("Entering into signalProcess() method..");
		try {
			WorkFlowRequest workFlowRequest = (WorkFlowRequest) kcontext.getVariable(BPMConstants.WORKFLOW_REQ);
			LOGGER.info("OrderID:" + workFlowRequest.getOrderId() + " ProcessInstanceId:"
					+ kcontext.getProcessInstance().getId() + " ParentProcessInstanceId:"
					+ kcontext.getProcessInstance().getParentProcessInstanceId());

			ServiceProvider bpmUtil = new ServiceProvider();
			String URL = bpmUtil.getServiceURL(PropertyFile.PROP_CONST.KIE_SERVER_BASE_URL.toString(),
					BPMConstants.SERVICE_ID_BPM);

			String depId = (String) kcontext.getKieRuntime().getEnvironment().get(BPMConstants.DEPLOYMENT_ID);
			URL = URL + "/" + depId + "/processes/instances/" + pid + "/signal/" + sid;
			LOGGER.info(sid + " SIGNAL URL : " + URL);

			kcontext.setVariable("url", URL);
			kcontext.setVariable("bpmAccessKey",
					PropertyFile.getProjectProperties().get(BPMConstants.KIE_SERVER_INVOKE_ID));
			kcontext.setVariable("bpmAccessCode",
					PropertyFile.getProjectProperties().get(BPMConstants.KIE_SERVER_INVOKE_TOKEN));
			kcontext.setVariable(BPMConstants.CONNECTION_TIME_OUT, PropertyFile.getInstance().getConnectionTimeOut());
			kcontext.setVariable(BPMConstants.READ_TIME_OUT, PropertyFile.getInstance().getReadTimeOut());

			ObjectMapper mapper = new ObjectMapper();
			LOGGER.info(sid + " SIGNAL Content is:" + mapper.writeValueAsString(payload));
			kcontext.setVariable(BPMConstants.CONTENT, mapper.writeValueAsString(payload));

		} catch (Exception e) {
			LOGGER.error("Exception while signaling:" + e.getMessage());
		}
	}

	public void initiateConsumerAddLineProcess(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering into initiateConsumerAddLineProcess() method..");
		try {
			WorkFlowRequest workFlowRequest = (WorkFlowRequest) kcontext.getVariable(BPMConstants.WORKFLOW_REQ);
			LOGGER.info("OrderID:" + workFlowRequest.getOrderId() + " ProcessInstanceId:"
					+ kcontext.getProcessInstance().getId() + " ParentProcessInstanceId:"
					+ kcontext.getProcessInstance().getParentProcessInstanceId());

			ServiceProvider bpmUtil = new ServiceProvider();
			String URL = bpmUtil.getServiceURL(PropertyFile.PROP_CONST.KIE_SERVER_BASE_URL.toString(),
					BPMConstants.SERVICE_ID_BPM);

			String deplomentId = (String) kcontext.getKieRuntime().getEnvironment().get(BPMConstants.DEPLOYMENT_ID);
			String processId = "ConsumerAddLine.ConsumerAddLine";
			URL = URL + "/" + deplomentId + "/processes/" + processId + "/instances";
			LOGGER.info("ConsumerAddLine Process Initiation URL : " + URL);

			kcontext.setVariable("url", URL);
			kcontext.setVariable(BPMConstants.CONNECTION_TIME_OUT,
					PropertyFile.getProjectProperties().get(BPMConstants.CAL_CONNECTIONTIMEOUT));
			kcontext.setVariable(BPMConstants.READ_TIME_OUT,
					PropertyFile.getProjectProperties().get(BPMConstants.CAL_READTIMEOUT));
			kcontext.setVariable("bpmAccessKey",
					PropertyFile.getProjectProperties().get(BPMConstants.KIE_SERVER_INVOKE_ID));
			kcontext.setVariable("bpmAccessCode",
					PropertyFile.getProjectProperties().get(BPMConstants.KIE_SERVER_INVOKE_TOKEN));
			/*
			 * KieRequestObject kieReqObj = new KieRequestObject();
			 * kieReqObj.setWorkflowRequest(workFlowRequest);
			 */

			ObjectMapper obj = new ObjectMapper();
			String request = "{\"workflowRequest\":{\"com.vzw.orm.bpmi.domain.objects.consumer.WorkFlowRequest\": "
					+ obj.writeValueAsString(workFlowRequest) + "}}";
			kcontext.setVariable(BPMConstants.CONTENT, request);
			LOGGER.info("ConsumerAddLine Content is : " + request);

		} catch (Exception e) {
			LOGGER.error("Exception while intiating ConsumerAddLine Process. Exception:" + e);
			e.printStackTrace();
			throw new Exception(e);
		}
	}

	public void validateConsumerAddLineResponse(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering into validateConsumerAddLineResponse() method..");
		kcontext.setVariable("flag", false);
		try {
			String processinsatnceid = (String) kcontext.getVariable("result");
			if (processinsatnceid != null) {
				LOGGER.info("ConsumerAddLine Process Instance id ->" + processinsatnceid);
				kcontext.setVariable("flag", true);
			} else {
				LOGGER.info("Unable to initiate ConsumerAddLine process");
				throw new Exception("Unable to initiate ConsumerAddLine process");
			}

		} catch (Exception e) {
			LOGGER.error("Exceptiom inside validateConsumerAddLineResponse() method.." + e.getMessage());
			throw new Exception("Exceptiom inside validateConsumerAddLineResponse() method.." + e.getMessage());
		}
	}

	public void updateParentProcessInstanceId(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering updateParentProcessInstanceId() method..");
		boolean flag = false;
		try {
			String pid = (String) kcontext.getVariable("processInstanceId");
			String ppid = (String) kcontext.getVariable("parentProcessInstanceId");
			LOGGER.info("PPID:" + ppid);
			LOGGER.info("PID:" + pid);
			/*
			 * if(connection == null){ String url =
			 * PropertyFile.getProjectProperties().get(
			 * "resource.ds1.driverProperties.url") .toString(); connection =
			 * DriverManager.getConnection(url,
			 * projectProps.get("resource.ds1.driverProperties.accessid").
			 * toString(),
			 * projectProps.get("resource.ds1.driverProperties.accesscode").
			 * toString()); }
			 */
			String query = "update processinstancelog set parentprocessinstanceid = ? where processinstanceid = ?";

			PreparedStatement preparedStmt = PropertyFile.getInstance().getPostgresConnection().prepareStatement(query);

			preparedStmt.setLong(1, Long.parseLong(ppid));
			preparedStmt.setLong(2, Long.parseLong(pid));

			preparedStmt.executeUpdate();
			LOGGER.info("ParentProcessInstanceId had been updated for " + pid);
			flag = true;
		} catch (Exception e) {
			LOGGER.error("Exception inside updateParentProcessInstanceId() method. Exception:" + e);
			e.printStackTrace();
		}
		kcontext.setVariable("flag", flag);
	}

	public static void main(String[] args) throws JsonProcessingException {
		ObjectMapper obj = new ObjectMapper();
		Map<String, Object> request = new HashMap<String, Object>();
		ConsumerWorkflowRequest cwfr = new ConsumerWorkflowRequest();
		List<WorkFlowRequest> list = new ArrayList<>();
		WorkFlowRequest wfr = new WorkFlowRequest();
		wfr.setOrderDateTime("348959345");
		wfr.setOrderId("348534895");
		wfr.setCorrelationId("5646");
		LOGGER.info("wfr obj-->" + obj.writeValueAsString(wfr));

		String payload2 = "{\"workflowRequest\":{\"com.vzw.orm.bpmi.domain.objects.consumer.WorkFlowRequest\": "
				+ obj.writeValueAsString(wfr) + "}}";
		request.put("payload", "PAYLOAD");
		String requestBefore = obj.writeValueAsString(request);
		LOGGER.info("requestAfter-->" + requestBefore.replace("\"PAYLOAD\"", payload2));
		list.add(wfr);
		cwfr.setLstOfWorkflowRequest(list);
		LOGGER.info("cwfr obj-->" + obj.writeValueAsString(cwfr));
		String payload = "{\"consumerWorkflowRequest\": " + obj.writeValueAsString(cwfr) + "}";
		LOGGER.info("payload-->" + payload);
		request.put("payload", "PAYLOAD");
		request.put("deploymentId", "com.vzw");
		request.put("parentprocessinstanceid", "COP");
		String st = obj.writeValueAsString(request);
		LOGGER.info("st-->" + st);
		LOGGER.info("obj-->" + st.replace("\"PAYLOAD\"", payload));
	}
}
