package com.vzw.orm.wflw.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.kie.api.runtime.process.ProcessContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.common.core.util.StringUtils;
import com.vzw.orm.billing.datacontract.VisionSaveRecordResponse;
import com.vzw.orm.billing.datacontract.VisionSyncRequest;
import com.vzw.orm.billing.domain.BillingBPMWorkFlow;
import com.vzw.orm.billing.domain.BillingWorkFlowRequest;
import com.vzw.orm.bpmi.domain.objects.consumer.ConsumerWorkflowRequest;
import com.vzw.orm.bpmi.domain.objects.consumer.KeyValueObject;
import com.vzw.orm.bpmi.domain.objects.consumer.WorkFlowRequest;
import com.vzw.orm.provisioning.domain.common.MtasConsumerRequest;
import com.vzw.orm.provisioning.domain.common.MtasProducerRequest;
import com.vzw.orm.provisioning.domain.common.MtasProducerResponse;
import com.vzw.orm.provisioning.domain.common.ProvisioningBPMWorkFlow;
import com.vzw.orm.provisioning.domain.common.ProvisioningWorkFlowRequest;

public class NumberShareUtil implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final Logger LOGGER = LoggerFactory.getLogger(NumberShareUtil.class);

	public void splitBranchlines(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering splitBranchlines() method ...");
		try {
			LOGGER.info("isNSContainsBranch -->" + kcontext.getVariable("isNSContainsBranch"));
			Set<String> filteredMtnListBranch = new HashSet<String>();
			List<WorkFlowRequest> lstOfWorkflowRequestForLineLevelFinalBranch = new ArrayList<>();
			Set<String> filteredMtnListtAll = (Set<String>) kcontext.getVariable("filteredMtnList");
			List<WorkFlowRequest> lstOfWorkflowRequestForLineLevelFinalAll = (List<WorkFlowRequest>) kcontext
					.getVariable("filteredLstOfWorkflow");
			Set<String> collectedMtnsAll = (Set<String>) kcontext.getVariable("mtnList");
			// Number shared - remove branch lines from work flow request line
			// level and add into branch list
			if (StringUtils.isEmpty(String.valueOf(kcontext.getVariable("isBranchLinePending")))) {
				for (WorkFlowRequest wfrtemp : lstOfWorkflowRequestForLineLevelFinalAll) {
					if (wfrtemp.getLineLevelInfo().stream()
							.filter(keyValueObject -> keyValueObject.getKey().equalsIgnoreCase("isBranchLine"))
							.anyMatch(keyValueObject -> Boolean.parseBoolean(keyValueObject.getValue().toString()))) {
						lstOfWorkflowRequestForLineLevelFinalBranch.add(wfrtemp);
						lstOfWorkflowRequestForLineLevelFinalAll.remove(wfrtemp);
					}
				}
				for (WorkFlowRequest wfr : lstOfWorkflowRequestForLineLevelFinalBranch) {
					filteredMtnListtAll.remove(wfr.getMtn());
					filteredMtnListBranch.add(wfr.getMtn());

				}
				kcontext.setVariable("filteredBranchMtnList", filteredMtnListBranch);
				kcontext.setVariable("filteredBranchLstOfWorkflow", lstOfWorkflowRequestForLineLevelFinalBranch);
				kcontext.setVariable("mtnList", filteredMtnListtAll);
				kcontext.setVariable("isBranchLinePending", true);
			} else if (Boolean.parseBoolean(String.valueOf(kcontext.getVariable("isBranchLinePending")))) {

				kcontext.setVariable("filteredMtnList", kcontext.getVariable("filteredBranchMtnList"));
				kcontext.setVariable("filteredLstOfWorkflow", kcontext.getVariable("filteredBranchLstOfWorkflow"));
				kcontext.setVariable("mtnList", kcontext.getVariable("filteredBranchMtnList"));
				kcontext.setVariable("isBranchLinePending", false);

			}

		} catch (Exception e) {
			LOGGER.info("Exception in Number Share Util --> splitBranchlines()" + e);
		}
	}

	public void checkNumberShare(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering checkNumberShare() method ...");
		try {
			ConsumerWorkflowRequest consumerWFRequest = (ConsumerWorkflowRequest) kcontext
					.getVariable("consumerWorkflowRequest");
			kcontext.setVariable("consumerWorkflowRequestMain", consumerWFRequest);
			kcontext.setVariable("isNSTrunkPending", false);
			kcontext.setVariable("isNSUngraftRequire", false);
			kcontext.setVariable("isNSBranchContain", false);
			if (consumerWFRequest.getLstOfWorkflowRequest().size() > 0) {

				WorkFlowRequest wfr = consumerWFRequest.getLstOfWorkflowRequest().get(0);
				String orderSource = wfr.getOrderSource();
				List<KeyValueObject> lstKeyObject = wfr.getLineLevelInfo();
				if (lstKeyObject.size() > 0) {
					for (KeyValueObject keyValueObject : lstKeyObject) {
						// find trunk pending
						if (keyValueObject.getKey().equalsIgnoreCase("isNSTrunkPending")
								&& Boolean.getBoolean(keyValueObject.getValue().toString())) {
							kcontext.setVariable("isNSTrunkPending", true);
							LOGGER.info("isNSTrunkPending --> {}", true);
						} else if (keyValueObject.getKey().equalsIgnoreCase("numberShareIndicator")
								&& !StringUtils.isEmpty(keyValueObject.getValue())
								&& orderSource.equalsIgnoreCase("modify")) {
							kcontext.setVariable("isNSUngraftRequire", true);

						}
					}

				}

				/*
				 * kcontext.setVariable("isNSUngraftRequire",
				 * consumerWFRequest.getLstOfWorkflowRequest().stream()
				 * .filter(workFlowRequest ->
				 * workFlowRequest.getLineLevelInfo().stream()
				 * .filter(keyValueObject -> keyValueObject.getKey()
				 * .equalsIgnoreCase("numberShareIndicator"))
				 * .anyMatch(keyValueObject ->
				 * !StringUtils.isEmpty(keyValueObject.getValue())))
				 * .anyMatch(workFlowRequest -> workFlowRequest.getOrderSource()
				 * .equalsIgnoreCase("modify")));
				 */

				kcontext.setVariable("isNSBranchContain", consumerWFRequest.getLstOfWorkflowRequest().stream()
						.filter(workFlowRequest -> workFlowRequest.getLineLevelInfo().stream()
								.filter(keyValueObject -> keyValueObject.getKey().equalsIgnoreCase("isBranchLine"))
								.anyMatch(keyValueObject -> Boolean.parseBoolean(keyValueObject.getValue().toString())))
						.anyMatch(workFlowRequest -> workFlowRequest.getOrderType().equalsIgnoreCase("NumberShare")));
				LOGGER.info("isNSBranchContain -->" + kcontext.getVariable("isNSBranchContain"));
			}
		} catch (Exception e) {
			LOGGER.error("Error in checkNumberShare method. Exception : " + e);
			throw new Exception(e);
		}
	}

	/**
	 * This method is used to set all the variable values required to update for
	 * Ungrafting Vision Seeding Data
	 * 
	 * @param kcontext
	 * @throws Exception
	 */
	public void updateUngraftingStatustoVision(ProcessContext kcontext, String status) throws Exception {
		LOGGER.info("Entering updateUngraftingStatustoVision() method");
		try {
			ConsumerWorkflowRequest consumerWFRequest = (ConsumerWorkflowRequest) kcontext
					.getVariable(BPMConstants.CONSUMERWFLREQUEST);
			LOGGER.info("OrderID:" + consumerWFRequest.getLstOfWorkflowRequest().get(0).getOrderId()
					+ " ProcessInstanceId:" + kcontext.getProcessInstance().getId() + " ParentProcessInstanceId:"
					+ kcontext.getProcessInstance().getParentProcessInstanceId());

			WorkFlowRequest workFlowRequest = new WorkFlowRequest();
			BeanUtils.copyProperties(workFlowRequest, consumerWFRequest.getLstOfWorkflowRequest().get(0));
			long parentProcessInstanceId = kcontext.getProcessInstance().getParentProcessInstanceId();
			long processInstanceId = kcontext.getProcessInstance().getId();
			LOGGER.info("OrderID:" + workFlowRequest.getOrderId() + " ProcessInstanceId:" + processInstanceId
					+ " ParentProcessInstanceId:" + parentProcessInstanceId);
			ServiceProvider bpmUtil = new ServiceProvider();
			String visionSeedDataUrl = bpmUtil.getServiceURL(
					PropertyFile.PROP_CONST.VISION_UNGRAFT_STAT_UPDT_URL.toString(), BPMConstants.SERVICE_ID_BILLING);

			LOGGER.info("Ungrafting Data URL is : " + visionSeedDataUrl);
			kcontext.setVariable(BPMConstants.URL, visionSeedDataUrl);
			kcontext.setVariable(BPMConstants.MS_ACCESS_ID, PropertyFile.getInstance().getMSAccessId());
			kcontext.setVariable(BPMConstants.MS_ACCESS_CODE, PropertyFile.getInstance().getMSAccessCode());
			kcontext.setVariable(BPMConstants.CONNECTION_TIME_OUT, PropertyFile.getInstance().getConnectionTimeOut());
			kcontext.setVariable(BPMConstants.READ_TIME_OUT, PropertyFile.getInstance().getReadTimeOut());

			KeyValueObject keyvalue = new KeyValueObject();
			keyvalue.setKey("ungraftStatus");
			keyvalue.setValue(status);
			workFlowRequest.getLineLevelInfo().add(keyvalue);
			BillingBPMWorkFlow bpmWorkflow = new BillingBPMWorkFlow();
			bpmWorkflow.setProcessInstanceId(String.valueOf(processInstanceId));
			bpmWorkflow.setProcessWorkFlowId(kcontext.getProcessInstance().getProcessId());
			// 
			bpmWorkflow.setDeploymentId(
					(String) kcontext.getKieRuntime().getEnvironment().get(BPMConstants.DEPLOYMENT_ID));
			if (PropertyFile.getInstance().isConsumerClustered()) {
				bpmWorkflow.setSite(
						PropertyFile.getInstance().getClusterId() + "-" + PropertyFile.getInstance().getDataCenter());
			} else {
				bpmWorkflow.setSite(PropertyFile.getInstance().getDataCenter());
			}

			VisionSyncRequest visionSyncRequest = new VisionSyncRequest();

			BillingWorkFlowRequest billingWorkFlowRequest = new BillingWorkFlowRequest();
			BeanUtils.copyProperties(billingWorkFlowRequest, workFlowRequest);

			List<BillingWorkFlowRequest> wfList = new ArrayList<BillingWorkFlowRequest>();
			wfList.add(billingWorkFlowRequest);
			visionSyncRequest.setWorkFlowRequestObject(wfList);

			visionSyncRequest.setBpmWorkFlowObject(bpmWorkflow);
			kcontext.setVariable(BPMConstants.CONTENT, visionSyncRequest);

			ObjectMapper obj = new ObjectMapper();
			LOGGER.info("Vision Seed Data Request Content is : " + obj.writeValueAsString(visionSyncRequest));
		} catch (Exception e) {
			LOGGER.error("Error in initiate Ungrafting Vision Seed Data Request method. Exception : " + e);
			throw new Exception(e);
		}
	}

	/**
	 * This method is used to validate the response received from Billing for
	 * Ungrafting Vision Seed Data Request
	 * 
	 * @param kcontext
	 * @throws Exception
	 */
	public void validateUngraftingResponse(ProcessContext kcontext) throws Exception {
		LOGGER.debug("Entering validateUngraftingResponse() method ");
		kcontext.setVariable("flag", false);
		try {
			VisionSaveRecordResponse visionSeedDataResponse = (VisionSaveRecordResponse) (kcontext
					.getVariable(BPMConstants.RESULT));

			if (null != visionSeedDataResponse) {
				LOGGER.info("validateUngraftingResponse is : " + visionSeedDataResponse + " for ProcessInstanceId: "
						+ kcontext.getProcessInstance().getId() + " and ParentProcessInstanceId: "
						+ kcontext.getProcessInstance().getParentProcessInstanceId());
				String status = visionSeedDataResponse.getStatus();
				if (BPMConstants.SUCCESS.equalsIgnoreCase(status)) {
					LOGGER.info("validateUngraftingResponse was successful");
					kcontext.setVariable("flag", true);
				} else {
					LOGGER.debug("ErrorCode : " + visionSeedDataResponse.getStatusCode()
							+ ", Error Source : VISION , Error Details : " + visionSeedDataResponse.getStatusDesc());
					CompensationUtil compUtil = new CompensationUtil();
					compUtil.setCompensationObject(kcontext, visionSeedDataResponse.getStatusCode(), "VISION",
							visionSeedDataResponse.getStatusDesc(), null, BPMConstants.COMP_COUNT);
				}
			} else {
				LOGGER.error(
						"Response object VisionSaveRecordResponse for Vision Seed Data request is NULL or unexpected");
				throw new Exception(
						"Response object VisionSaveRecordResponse for Vision Seed Data request is NULL or unexpected");
			}
		} catch (Exception e) {
			LOGGER.error(
					"Exception while validating response received for Ungrafting Vision request. Exception : "
							+ e);
			throw new Exception(e);
		}
	}

	public void initiateMTASRequest(ProcessContext kcontext, String status) throws Exception {
		LOGGER.info("Entering initiateMTASRequest() method for Ungraft");

		try {
			WorkFlowRequest workFlowRequest = (WorkFlowRequest) kcontext.getVariable(BPMConstants.WORKFLOW_REQ);
			ProvisioningWorkFlowRequest proWorkFlowRequest = new ProvisioningWorkFlowRequest();
			BeanUtils.copyProperties(proWorkFlowRequest, workFlowRequest);
			LOGGER.info("OrderID:" + workFlowRequest.getOrderId() + " ProcessInstanceId:"
					+ kcontext.getProcessInstance().getId() + " ParentProcessInstanceId:"
					+ kcontext.getProcessInstance().getParentProcessInstanceId());
			kcontext.setVariable(BPMConstants.FLAG, false);
			ServiceProvider bpmUtil = new ServiceProvider();
			String mtasUrlUngraft = bpmUtil.getServiceURL(PropertyFile.PROP_CONST.MTAS_URL_UNGRAFT.toString(),
					BPMConstants.SERVICE_ID_PROV);
			LOGGER.info("MTAS URL for Ungraft is : " + mtasUrlUngraft);
			kcontext.setVariable(BPMConstants.URL, mtasUrlUngraft);
			kcontext.setVariable(BPMConstants.MS_ACCESS_ID, PropertyFile.getInstance().getMSAccessId());
			kcontext.setVariable(BPMConstants.MS_ACCESS_CODE, PropertyFile.getInstance().getMSAccessCode());
			kcontext.setVariable(BPMConstants.CONNECTION_TIME_OUT, PropertyFile.getInstance().getConnectionTimeOut());
			kcontext.setVariable(BPMConstants.READ_TIME_OUT, PropertyFile.getInstance().getReadTimeOut());
			
			KeyValueObject keyvalue = new KeyValueObject();
			keyvalue.setKey("ungraftStatus");
			keyvalue.setValue(status);
			workFlowRequest.getLineLevelInfo().add(keyvalue);

			ProvisioningBPMWorkFlow bpmWorkflow = new ProvisioningBPMWorkFlow();
			bpmWorkflow.setProcessInstanceId(String.valueOf(kcontext.getProcessInstance().getId()));
			bpmWorkflow.setProcessWorkFlowId(kcontext.getProcessInstance().getProcessId());
			bpmWorkflow.setSignalEventId(BPMConstants.SIGNAL_UNGRAFT_DEVICE);

			LOGGER.info("deploymentId-->"
					+ (String) kcontext.getKieRuntime().getEnvironment().get(BPMConstants.DEPLOYMENT_ID));
			bpmWorkflow.setDeploymentId(
					(String) kcontext.getKieRuntime().getEnvironment().get(BPMConstants.DEPLOYMENT_ID));
			if (PropertyFile.getInstance().isConsumerClustered()) {
				bpmWorkflow.setSite(
						PropertyFile.getInstance().getClusterId() + "-" + PropertyFile.getInstance().getDataCenter());
			} else {
				bpmWorkflow.setSite(PropertyFile.getInstance().getDataCenter());
			}

			MtasProducerRequest mtasRequest = new MtasProducerRequest();

			mtasRequest.setBpmWorkFlowObject(bpmWorkflow);
			mtasRequest.setProvisioningRequestType("NS");
			mtasRequest.setWorkFlowRequestObject(proWorkFlowRequest);
			kcontext.setVariable(BPMConstants.CONTENT, mtasRequest);

			ObjectMapper obj = new ObjectMapper();
			LOGGER.info("MTAS Content for Ungraft is : " + obj.writeValueAsString(mtasRequest));
		} catch (Exception e) {
			LOGGER.error("Error in initiateMTASRequest method for Ungraft Exception : " + e);
			throw new Exception(e);
		}
	}

	public void validateMTASRequestsResponse(ProcessContext kcontext) throws Exception {

		LOGGER.info("Entering validateMTASRequestsResponse() method for Ungraft");
		try {
			if (null != kcontext.getVariable(BPMConstants.RESULT)) {
				MtasProducerResponse mtasProducerResp = (MtasProducerResponse) (kcontext
						.getVariable(BPMConstants.RESULT));
				LOGGER.info("MtasProducerResponse for Ungraft: " + mtasProducerResp + " for ProcessInstanceId: "
						+ kcontext.getProcessInstance().getId() + " and ParentProcessInstanceId: "
						+ kcontext.getProcessInstance().getParentProcessInstanceId());

				if (null != mtasProducerResp) {
					if (BPMConstants.SUCCESS.equalsIgnoreCase(mtasProducerResp.getStatus())) {
						kcontext.setVariable(BPMConstants.FLAG, true);
						kcontext.setVariable("features", mtasProducerResp.getFeatures());
						LOGGER.info("features list from MTAS :" + mtasProducerResp.getFeatures());
					} else {
						kcontext.setVariable(BPMConstants.FLAG, false);
						CompensationUtil compUtil = new CompensationUtil();
						if (mtasProducerResp.getExceptionInfo() != null) {
							compUtil.setCompensationObject(kcontext, mtasProducerResp.getExceptionInfo().getErrorCode(),
									mtasProducerResp.getExceptionInfo().getErrorSource(),
									mtasProducerResp.getExceptionInfo().getErrorDeatils(), "MTAS_RES", "compCount");
						} else {
							compUtil.setCompensationObject(kcontext, "BPMERR02", "BPM",
									"Response Object from Micro Service is either NULL or unexpected", "MTAS_RES",
									"compCount");
						}
					}
				} else {
					LOGGER.info("Mtas responded with NULL or Error response");
					kcontext.setVariable(BPMConstants.FLAG, false);
					CompensationUtil compUtil = new CompensationUtil();
					compUtil.setCompensationObject(kcontext, "BPMERR02", "BPM",
							"Response Object from Micro Service is either NULL or unexpected", "MTAS_RES", "compCount");
				}
			} else {
				LOGGER.error("Exception while Invoking MTAS Service");
				kcontext.setVariable(BPMConstants.FLAG, false);
				CompensationUtil compUtil = new CompensationUtil();
				compUtil.setCompensationObject(kcontext, "BPMERR02", "BPM", "Exception while Invoking Micro Service",
						"MTAS_RES", "compCount");
			}
		} catch (Exception e) {
			LOGGER.error("Error in validateMTASRequestsResponse method for Ungraft Exception : " + e);
			throw new Exception(e);
		}
	}

	public void validateMTASResponse(ProcessContext kcontext) throws Exception {
		LOGGER.info("Entering validateMTASResponse() method for Ungraft");

		boolean isUngraft = false;
		String type = "";

		try {
			kcontext.setVariable(BPMConstants.MTAS_SUCCESS, false);

			if (null != kcontext.getVariable(BPMConstants.RESULT)) {
				MtasConsumerRequest mtasRespData = (MtasConsumerRequest) (kcontext.getVariable(BPMConstants.RESULT));
				LOGGER.info("MtasConsumerRequest for Ungraft : " + mtasRespData);

				String status = mtasRespData.getStatus();
				if (null != status && !status.isEmpty() && BPMConstants.SUCCESS.equalsIgnoreCase(status)) {
					isUngraft = true;
					kcontext.setVariable(BPMConstants.MTAS_SUCCESS, true);
				} else {
					LOGGER.info("Error response received from MTAS for Ungraft with errorCode : ["
							+ mtasRespData.getStatusCode() + "] and errorDesc : [" + mtasRespData.getStatusDesc()
							+ "]");

				}
			} else {
				LOGGER.error(
						"Received NULL response from MTAS for Ungraft . Deactivating safe point and calling compensation.");
				discardLine(kcontext, BPMConstants.SIGNAL_UNGRAFT_DEVICE);
				CompensationUtil compUtil = new CompensationUtil();
				compUtil.setCompensationObject(kcontext, "BPMERR02", "BPM",
						"Response Object from Micro Service is NULL for " + type, null, BPMConstants.COMP_COUNT);
			}
			LOGGER.info("All Ungraft Items Received : " + isUngraft);
		} catch (Exception e) {
			LOGGER.error("Exception while validating response received from MTAS for Ungraft. Exception : " + e);
			discardLine(kcontext, BPMConstants.SIGNAL_UNGRAFT_DEVICE);
			CompensationUtil compUtil = new CompensationUtil();
			compUtil.setCompensationObject(kcontext, "BPMERR02", "BPM",
					"Exception while validating response received from MTAS for Ungraft " + type, null,
					BPMConstants.COMP_COUNT);
			kcontext.setVariable(BPMConstants.MTAS_SUCCESS, false);
		}
		kcontext.setVariable(BPMConstants.FLAG, isUngraft);
	}

	public void discardLine(ProcessContext kcontext, String signalKey) {
		LOGGER.info("Entering discardLine() method ...");
		try {
			kcontext.setVariable(BPMConstants.OPERATION_TYPE, "REFLOW");
			kcontext.setVariable(BPMConstants.COMP_COUNT, 0);
			LOGGER.info("De-activating safe point of signalKey : " + signalKey + " and signalId : "
					+ kcontext.getVariable(signalKey));

			if (signalKey != null && kcontext.getVariable(signalKey) != null) {
				kcontext.getKieRuntime().getWorkItemManager()
						.completeWorkItem(Long.parseLong(String.valueOf(kcontext.getVariable(signalKey))), null);
			}

		} catch (Exception e) {
			LOGGER.error("Exception while validating response received from Line Item Order Status Update. Exception : "
					+ e);
			e.printStackTrace();
		}

	}
}
